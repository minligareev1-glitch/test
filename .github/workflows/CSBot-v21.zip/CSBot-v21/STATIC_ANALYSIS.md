# Дополнение v19 — актуальное состояние бомбы и сущностей

client+12C010 — мигающий draw-флаг, не постоянное planted. В v19 planted = type16(+24)==1 и displayCounter32(+20)>0. Проверяется полный BombDrop/Pickup профиль; Engine entity/maxclients/clock профили и смещения проверены отдельно на PE. Детали и ограничения — AUTO_BOT_V19.md и VALIDATION.md. Старые описания ниже исторические.

# Статический анализ присланных DLL

DLL исследованы как данные. Ни одна не запускалась и не внедрялась.

## Идентификация

client.dll:
- SHA-256: b474ecfbb6f2fc6c4aa48fceb0b5735dfe2cb23ce06ba0a1008137cd228c714a
- PE32 / x86, preferred ImageBase=0x01900000, SizeOfImage=0x15B000.
- HUD_PlayerMove export RVA=0x44E20.
- HUD_PlayerMoveInit export RVA=0x44E00.

hw.dll:
- SHA-256: 319fd65a9151d42c451c9821a78a031d20da51fcc5db2f555de1651416469c3c
- PE32 / x86, preferred ImageBase=0x01D00000, SizeOfImage=0x1229A8E.
- Источник нового указателя найден в client.dll, а не путём угадывания полей hw.dll.

## Цепочка вызовов и глобальный указатель

HUD_PlayerMove (RVA 0x44E20) передаёт аргументы в функцию RVA 0x63710.
HUD_PlayerMoveInit (RVA 0x44E00) передаёт аргумент в функцию RVA 0x637E0.

Дизассемблирование по preferred ImageBase:

```asm
; RVA 0x63710, функция движения:
mov edx, [esp+8]
mov eax, [esp+4]
xor ecx, ecx
; RVA 0x6371A:
mov [0x01A329A8], eax
; далее проверяется аргумент server

; RVA 0x637E0, функция инициализации:
mov eax, [esp+4]
; RVA 0x637E4:
mov [0x01A329A8], eax
```

Обе функции сохраняют аргумент в одну глобальную переменную.

```text
0x01A329A8 - 0x01900000 = 0x1329A8
pmove = ReadUInt32(runtime_client_base + 0x1329A8)
```

Код первой функции (17 байтов):
8B 54 24 08 8B 44 24 04 33 C9 A3 [4-byte relocated address] 85 D2

Код второй функции (9 байтов):
8B 44 24 04 A3 [4-byte relocated address]

Наличие релокаций HIGHLOW у операндов по RVA 0x6371B и 0x637E5 проверено.
В v4 ожидаемый абсолютный адрес строится от ФАКТИЧЕСКОЙ базы модуля в процессе,
а не от preferred ImageBase. Ридер не вызывает эти функции, он только сравнивает
байты инструкций и читает сохранённый указатель.

## Структура

Порядок полей сопоставлен с Valve Half-Life SDK playermove_s (32-битный ABI).
Это основание для интерпретации, а не ещё одна проверка поведения в запущенной игре.
Дополнительное соответствие: код функции движения читает onground по +0xE0 и
обновляет flags по +0xB8, что совпадает с ожидаемой раскладкой.

Используемые смещения от pmove:

```text
+0x00 player_index (int)
+0x04 server (int / qboolean)
+0x08 multiplayer (int / qboolean)
+0x0C time (float)
+0x10 frametime (float)
+0x38 origin (3 float)
+0x44 angles (3 float)
+0x5C velocity (3 float)
+0x80 view_ofs (3 float)
+0xB8 flags (int)
+0xD0 dead (int / qboolean)
+0xD4 deadflag (int)
+0xD8 spectator (int)
+0xE0 onground (int: -1 означает отсутствие опоры, не булево значение)
```

origin — начало координат, используемое движением; не следует автоматически
считать его точкой ног. Камера также может иметь другой origin.

## Границы результата

Подтверждены статически: код, две записи указателя, RVA, наличие релокаций.
Обосновано SDK и отдельными обращениями в коде: ожидаемая раскладка полей.
Ещё НЕ подтверждены: актуальность указателя в разные моменты игры, поведение
origin/angles/velocity при действиях пользователя и пригодность для навигации.
Указатель может сохраняться вне активного матча, а данные могут устаревать.
Совпадение инструкций/файлового хеша не доказывает состояние спавна.

Исходные DLL в архив проекта не включены.


## v15 read-only world/HUD profile (experimental)

Supplied DLL preferred client image base 01900000; runtime RVAs relocated using actual module base. Main AUTO additionally requires exact supplied DLL file SHA256. No game function is called.

- Initialize export +44F10 copies 0x85 engine function pointers to client+121BA0. Official Valve HLSDK APIProxy.h / cdll_int.h define GetLevelName at index74 (offset128 hex). Reader loads this runtime callback pointer and supports only a bounded, in-hw.dll B8-immediate-C3 / A1-pointer-C3 return stub, with E9 forwarding. It reads the returned map text, does not execute the callback. Real runtime stub form needs preview confirmation; unsupported form waits without guessing map.
- HUD_GetPlayerTeam export +45350: signed word at client+12B2F4 + entityIndex*104; entityIndex=pmove.player_index+1. Runtime code signature checked. Team values 1=T, 2=CT; 0/3 do not enable missions.
- StatusIcon handler +65E90 / enable routine +66180: four entries at client+1212E0, stride52; name[24], sprite +24, flash +48. Active c4 icon is carrying evidence; flash=1 is proposed plant permission. Requires both actual BSP brush-zone membership and active weapon ID6 before attack. Flash semantics still need live correlation.
- CurWeapon +41B10: active pointer client+11D5D8, weapon-array client+11A6B8 stride328. ID derived only from aligned in-range pointer. C4 ID6, knife ID29; selecting slot5 alone never authorizes attack.
- BombDrop +50FB0 writes XYZ client+12C000, time +00C, active +010, planted short +018 (input byte==1). BombPickup +51050 clears active. This is client HUD evidence, NOT universal server bomb truth. CT message delivery/expiry and round reset timing unverified.
- Snapshot rereads map name, team, bomb, icon table and active-weapon pointer. A changing snapshot is rejected; this still is not an atomic game snapshot.

Official structure references inspected, not copied as implementation:
https://github.com/ValveSoftware/halflife/blob/master/engine/APIProxy.h
https://github.com/ValveSoftware/halflife/blob/master/engine/cdll_int.h

New state sensors and objective actions have synthetic tests but are not live-verified. Always compare world-state.log with actual HUD before execute. Original DLLs are not redistributed.


## v16: corrected GetLevelName for the reported runtime function

The user's prefix `FF1508C9AA04` at `04949950` corresponds to hw base `04930000`, function RVA `19950`. The supplied PE preferred base is `01D00000`. Exact disassembly:

```asm
; preferred-base VA, never executed by the reader
01D19950  call dword ptr [01E7C908]
01D19956  mov eax,[02D255C0]
01D1995B  cmp eax,3
01D1995E  mov eax,02ECF27C
01D19963  jge 01D1996A
01D19965  mov eax,01EABAF4
01D1996A  ret
```

Consequently the four rebased operands are hw+17C908, hw+10255C0, hw+11CF27C, hw+1ABAF4. The reader validates all 27 bytes at the verified RVA, reads the signed state and only reads the level buffer for state>=3. The indirect call is a recording/instrumentation-looking prefix; its target is not followed or invoked. Its purpose does not need to be assumed to determine the explicit return branches.

At preferred VA 01D29ABD..01D29ACA the DLL copies 0x27 bytes into 02ECF27C and writes a terminator at 02ECF2A3 (offset39). It accesses other fields from 02ECF2A4 onward. Thus the profile name read/reread is exactly 40 bytes, not the former generic 64 bytes; adjacent fields are excluded. The function pointer and connection state are reread at the end of the snapshot.

The log now supplies evidence for the runtime entry/prefix; the entire signature and buffer semantics are established statically and covered by synthetic/PE regressions. Actual in-game map text after the fix is not yet observed. The earlier v15 simple-stub-only restriction is superseded by this precise profile; arbitrary FF15 code is not emulated.


## v17: TeamInfo field differs from HUD_GetPlayerTeam

The v16 logs show map=de_dust2, hp=100, hasC4=True, weapon=17 and team=0; expected map asset pair loads. The code does not arm while team is unknown. The logs do not expose pmove index, so v17 now records it; no speculative index shift is made.

In supplied client.dll, HUD_GetPlayerTeam (+45350) really reads signed short at client+12B2F4 + entityIndex*104. However the actual message handler uses another field:

- TeamInfo registration at preferred VA 0194EE52..0194EE5C passes wrapper 0194E8D0 and string TeamInfo at 019E7E08.
- Wrapper calls viewport virtual slot +3C. The supplied vtable slot at RVA C9D3C points to client+290A0.
- At +290C7, handler sign-extends message index and multiplies it by 104. At +290D5 it addresses name client+12B31C + index*104 and reads/copies the TeamInfo string.
- At +290E7 compares CT literal (client+E4128); equal writes short2 to client+12B31A + index*104 at +290F9.
- At +29104 compares TERRORIST (client+E411C); equal writes short1 at +29116; otherwise writes short0 at +29121.
- Other current HUD consumers, e.g. +45CD0, likewise read +12B31A, not legacy +12B2F4.

v17 validates the whole 99-byte region +290C7..+29129 with six relocated address operands and fixed relative control flow. TeamInfo numeric/text snapshot is read twice; disagreement is rejected. Legacy getter signature is retained as profile evidence, but its value is diagnostic-only and may be zero/conflicting/unavailable. No inference from C4/spawn, no adjacent row selection and no forced team override.

This statically establishes where the actual handler writes and what it encodes. Live validity after this patch still needs preview correlation. Index remains pmove.player_index+1 according to the established 0-based movement layout; both indices are now logged so a remaining indexing issue would be visible rather than silently guessed.
