@echo off
setlocal
cd /d "%~dp0"
dotnet build CSBot.sln -c Release
set "result=%errorlevel%"
pause
exit /b %result%
