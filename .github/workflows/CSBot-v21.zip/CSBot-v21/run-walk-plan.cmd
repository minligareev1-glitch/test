@echo off
setlocal
cd /d "%~dp0"
if not exist "Maps\de_dust2.bsp" (
  echo Copy your de_dust2.bsp to Maps\de_dust2.bsp first.
  pause
  exit /b 2
)
where dotnet >nul 2>&1
if errorlevel 1 (
  echo Install .NET 8 SDK first.
  pause
  exit /b 2
)
dotnet run --project "CSBot\CSBot.csproj" -c Release -- --walk-plan "Navigation\de_dust2.graph" "Maps\de_dust2.bsp" -832 -704 164.031 a --team t --json "walk-t-a.json" > "walk-plan.log" 2>&1
if errorlevel 1 goto failed
dotnet run --project "CSBot\CSBot.csproj" -c Release -- --walk-plan "Navigation\de_dust2.graph" "Maps\de_dust2.bsp" -832 -704 164.031 b --team t --json "walk-t-b.json" >> "walk-plan.log" 2>&1
if errorlevel 1 goto failed
type "walk-plan.log"
pause
exit /b 0
:failed
type "walk-plan.log"
pause
exit /b 1
