@echo off
setlocal
cd /d "%~dp0"
set "SETTINGS=%~1"
if "%SETTINGS%"=="" set "SETTINGS=%~dp0config.txt"
dotnet run --project "CSBot\CSBot.csproj" -c Release -- --check-settings "%SETTINGS%"
set "RESULT=%errorlevel%"
pause
exit /b %RESULT%
