@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>&1
if errorlevel 1 (
  echo Install .NET 8 SDK first. See README.md.
  pause
  exit /b 1
)
dotnet run --project "CSBot\CSBot.csproj" -c Release -- --nav-info "Navigation\de_dust2.graph" > "nav-report.log" 2>&1
if errorlevel 1 goto failed
dotnet run --project "CSBot\CSBot.csproj" -c Release -- --nav-route "Navigation\de_dust2.graph" 0 66 --json "route.json" >> "nav-report.log" 2>&1
if errorlevel 1 goto failed
type "nav-report.log"
echo.
echo DRY RUN complete. No game input was sent.
pause
exit /b 0
:failed
type "nav-report.log"
pause
exit /b 1
