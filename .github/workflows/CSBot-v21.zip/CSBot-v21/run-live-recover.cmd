@echo off
setlocal
cd /d "%~dp0"
echo RECOVERY MODE v14: checked step landing pause, then guarded route replanning.
echo Continuous route recovery with pauses. Focus/read/death/F9 stops remain final.
call "%~dp0run-live-walk.cmd" "%~1" "%~2" "%~3" "%~4" replan
exit /b %errorlevel%
