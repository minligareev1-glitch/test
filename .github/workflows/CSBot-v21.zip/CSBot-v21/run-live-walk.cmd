@echo off
setlocal
cd /d "%~dp0"
if not exist "Maps\de_dust2.bsp" goto nomap
where dotnet >nul 2>&1
if errorlevel 1 goto nosdk
echo EXPERIMENTAL input controller. LOCAL CS 1.6 vs bots only.
echo Confirm de_dust2 is loaded, your team matches the option, and you are spawned.
echo Balanced mode combines mouse with movement; runs on checked clear straights.
echo Standard bindings required: W = +forward, Shift = +speed. Look near horizon.
echo First run run-live-preview.cmd and inspect live-plan.json.
echo F8 arms once while game focused. F9 stops. Focus loss, Esc or console stop.
echo Do not touch movement keys or mouse after arming. Safety stops never auto-resume.
echo.
set "CONFIRM="
set /p "CONFIRM=Type LOCAL-DUST2 to confirm the local map/session: "
if /i not "%CONFIRM%"=="LOCAL-DUST2" exit /b 2
echo Mouse settings are read from game config.cfg automatically.
set "SITE=%~1"
if "%SITE%"=="" set "SITE=a"
set "TEAM=%~2"
if "%TEAM%"=="" set "TEAM=t"
set "MOTIONARG="
if not "%~4"=="" set "MOTIONARG=--motion %~4"
set "RECOVERY=%~5"
if "%RECOVERY%"=="" set "RECOVERY=stop"
echo Motion: config.txt unless overridden by argument 4. Recovery: %RECOVERY%
if not "%~3"=="" goto explicitcfg
dotnet run --project "CSBot\CSBot.csproj" -c Release -- --live-nav "Navigation\de_dust2.graph" "Maps\de_dust2.bsp" --site "%SITE%" --team "%TEAM%" --settings "%~dp0config.txt" %MOTIONARG% --recovery "%RECOVERY%" --execute --confirm-local-dust2 --log "live-walk.log" --json "live-plan.json"
goto done
:explicitcfg
dotnet run --project "CSBot\CSBot.csproj" -c Release -- --live-nav "Navigation\de_dust2.graph" "Maps\de_dust2.bsp" --site "%SITE%" --team "%TEAM%" --settings "%~dp0config.txt" %MOTIONARG% --recovery "%RECOVERY%" --config "%~3" --execute --confirm-local-dust2 --log "live-walk.log" --json "live-plan.json"
:done
set "RESULT=%errorlevel%"
echo Controller finished. Exit code: %RESULT%. See the final STOP or ARRIVED line in live-walk.log.
echo Keys owned by the controller were released or a release was attempted.
pause
exit /b %RESULT%
:nomap
echo Copy your de_dust2.bsp to Maps\de_dust2.bsp first.
pause
exit /b 2
:nosdk
echo Install .NET 8 SDK first.
pause
exit /b 2
