# de_dust2.graph

- Author in graph header: $_Vladislav
- Database: YaPB Graph Database
- Source: https://github.com/yapb/graph/blob/master/graph/de_dust2.graph
- Download: https://raw.githubusercontent.com/yapb/graph/master/graph/de_dust2.graph
- Git blob SHA-1: 8669feb9f62174bd4b7dfd7ab644ed5513cb15c3
- File SHA-256: 215f7fa0a08c55c95ad68a74d4c17f92960960fab4315598db84482e65a49a18
- Changes: none to the .graph file.
- License: CC BY-SA 4.0, https://creativecommons.org/licenses/by-sa/4.0/
- Full text: ../Licenses/CC-BY-SA-4.0.txt
- Credits database: https://github.com/yapb/graph/blob/master/CREDITS.md

Examples/route-0-to-66.json contains a derived route using these coordinates,
created for this diagnostic project. That navigation-data example is also provided
under CC BY-SA 4.0. It is not a verified movement route in the user's game.

The map's BSP geometry is not included. The supplied BSP/graph pair has offline static checks in v15; this is not live traversability verification.
