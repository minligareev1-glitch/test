@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>&1
if errorlevel 1 exit /b 2
set "ASSETS=%~1"
if "%ASSETS%"=="" set "ASSETS=%~dp0."
echo Scan Maps/*.bsp and matching Navigation/*.graph. No game or input accessed.
dotnet run --project "CSBot\CSBot.csproj" -c Release -- --register-maps "%ASSETS%"
set "RESULT=%errorlevel%"
pause
exit /b %RESULT%
