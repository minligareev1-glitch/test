@echo off
setlocal
cd /d "%~dp0"
if "%~1"=="" (
  echo Usage: inspect-config.cmd "C:\Games\CS\cstrike\config.cfg"
  echo Or drag a config.cfg onto this script.
  pause
  exit /b 2
)
dotnet run --project "CSBot\CSBot.csproj" -c Release -- --inspect-config "%~1" > "config-report.log" 2>&1
type "config-report.log"
pause
