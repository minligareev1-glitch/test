@echo off
setlocal
cd /d "%~dp0"
if not exist "Maps\de_dust2.bsp" goto nomap
where dotnet >nul 2>&1
if errorlevel 1 goto nosdk
set "SITE=%~1"
if "%SITE%"=="" set "SITE=a"
set "TEAM=%~2"
if "%TEAM%"=="" set "TEAM=t"
echo READ-ONLY preview. Load local de_dust2, spawn and stand still first.
echo F9 or Ctrl+C stops. No keyboard/mouse commands will be sent.
set "MOTIONARG="
if not "%~4"=="" set "MOTIONARG=--motion %~4"
echo Motion: config.txt unless overridden by argument 4.
if not "%~3"=="" goto explicitcfg
dotnet run --project "CSBot\CSBot.csproj" -c Release -- --live-nav "Navigation\de_dust2.graph" "Maps\de_dust2.bsp" --site "%SITE%" --team "%TEAM%" --settings "%~dp0config.txt" %MOTIONARG% --log "live-preview.log" --json "live-plan.json"
goto done
:explicitcfg
dotnet run --project "CSBot\CSBot.csproj" -c Release -- --live-nav "Navigation\de_dust2.graph" "Maps\de_dust2.bsp" --site "%SITE%" --team "%TEAM%" --settings "%~dp0config.txt" %MOTIONARG% --config "%~3" --log "live-preview.log" --json "live-plan.json"
:done
pause
exit /b
:nomap
echo Copy your de_dust2.bsp to Maps\de_dust2.bsp first.
pause
exit /b 2
:nosdk
echo Install .NET 8 SDK first.
pause
exit /b 2
