@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>&1
if errorlevel 1 exit /b 2
set "GAMECFGARG="
if not "%~1"=="" set "GAMECFGARG=--config "%~1""
dotnet run --project "CSBot\CSBot.csproj" -c Release -- --auto-bot --settings "%~dp0config.txt" --assets "%~dp0." %GAMECFGARG% --log "world-state.log" --json "auto-plan.json"
set "RESULT=%errorlevel%"
pause
exit /b %RESULT%
