namespace CSBot;

internal static partial class ReaderTests
{
    private static int _passed;
    private static void Check(bool condition, string label)
    { if (!condition) throw new Exception("FAILED: " + label); }
    private static void Test(string name, Action action)
    { action(); Console.WriteLine("PASS " + name); _passed++; }

    private static byte[] MovementHeader()
    {
        var data = new byte[MovementProbe.HeaderSize];
        void F(int off, float value) => BitConverter.GetBytes(value).CopyTo(data, off);
        F(0x0C, 10); F(0x10, 0.01f);
        F(0x38, 100); F(0x3C, 200); F(0x40, 300); F(0x48, 90); F(0x88, 17);
        return data;
    }
    private static FakeMemory MovementMemory()
    {
        var mem = new FakeMemory();
        uint global = FakeMemory.Client + MovementProbe.PointerRva;
        mem.ByteBlocks[FakeMemory.Client + MovementProbe.MoveCodeRva] = MovementProbe.ExpectedMoveCode(global);
        mem.ByteBlocks[FakeMemory.Client + MovementProbe.InitCodeRva] = MovementProbe.ExpectedInitCode(global);
        mem.UInts[global] = 0x20000000;
        mem.ByteBlocks[0x20000000] = MovementHeader();
        return mem;
    }

    private static NavGraph SmallGraph(ushort edgeFlags = 0, int middleFlags = 0) => new()
    {
        Nodes = new List<NavNode>
        {
            new(0, 0, new(0,0,0), 0, new List<NavLink> { new(1, 1, edgeFlags, default) }),
            new(1, middleFlags, new(1,0,0), 0, new List<NavLink> { new(2, 1, 0, default) }),
            new(2, 0, new(2,0,0), 0, new List<NavLink>())
        }
    };

    private static byte[] SyntheticBsp()
    {
        var entities=System.Text.Encoding.ASCII.GetBytes("{\"classname\" \"worldspawn\"}\n{\"classname\" \"func_bomb_target\" \"model\" \"*1\" \"target\" \"tgt_a\"}\0");
        var parts=new Dictionary<int,byte[]> { [0]=entities,[1]=new byte[20],[5]=new byte[48],[10]=new byte[56],[14]=new byte[128] };
        void I(byte[] b,int o,int v)=>BitConverter.GetBytes(v).CopyTo(b,o);
        void F(byte[] b,int o,float v)=>BitConverter.GetBytes(v).CopyTo(b,o);
        void S(byte[] b,int o,short v)=>BitConverter.GetBytes(v).CopyTo(b,o);
        F(parts[1],0,1); // plane x=0
        S(parts[5],4,-2); S(parts[5],6,-1); // world x>=0 empty, x<0 solid
        S(parts[5],28,-1); S(parts[5],30,-2); // bomb brush x>=0 solid
        I(parts[10],0,-2); I(parts[10],28,-1);
        for(int m=0;m<2;m++)
        {
            int o=m*64;
            F(parts[14],o,m==0?-10:0); F(parts[14],o+4,-10); F(parts[14],o+8,-10);
            F(parts[14],o+12,10); F(parts[14],o+16,10); F(parts[14],o+20,10);
            I(parts[14],o+36,m);
        }
        var data=new byte[124+parts.Values.Sum(v=>v.Length)]; I(data,0,30); int cursor=124;
        foreach(var part in parts) { I(data,4+part.Key*8,cursor); I(data,8+part.Key*8,part.Value.Length); part.Value.CopyTo(data,cursor); cursor+=part.Value.Length; }
        return data;
    }
    private static void RejectBsp(Action<byte[]> mutate)
    {
        var data=SyntheticBsp(); mutate(data);
        try { BspMap.FromBytes(data); } catch(InvalidDataException) { return; }
        throw new Exception("Malformed BSP was accepted");
    }

    public static int Main(string[] args)
    {
        try
        {
            Test("direct fields ignore misleading positive armor", () =>
            {
                var mem = new FakeMemory();
                mem.Ints[0x0F9BD778] = 1; // Old false Armor +0x14C.
                var reader = new GameReader(mem, _ => { });
                Check(reader.DiscoverLocalPlayer(), "discover");
                Check(reader.TryReadState(out var s), "read");
                Check(s.Health == 100 && s.Money == 800 && s.Armor == 0, "100 / 800 / 0");
                Check(s.Status == GameStatus.Unknown, "must not infer spawn");
            });
            Test("zero HP and zero money remain valid reads", () =>
            {
                var mem = new FakeMemory();
                mem.Ints[FakeMemory.Client + GameOffsets.ClientHealthDirectRva] = 0;
                mem.Ints[FakeMemory.Client + GameOffsets.ClientMoneyDirectRva] = 0;
                var reader = new GameReader(mem, _ => { });
                Check(reader.DiscoverLocalPlayer() && reader.TryReadState(out _), "zero discovery");
                reader.TryReadState(out var s);
                Check(s.Health == 0 && s.Money == 0, "zero not replaced");
            });
            Test("missing HP is an error not a valid zero", () =>
            {
                var mem = new FakeMemory(); var reader = new GameReader(mem, _ => { });
                Check(reader.DiscoverLocalPlayer(), "discover");
                mem.Ints.Remove(FakeMemory.Client + GameOffsets.ClientHealthDirectRva);
                Check(!reader.TryReadState(out _), "HP read must fail");
                Check(reader.LastFailure.Contains("299"), "native error retained");
            });
            Test("missing money remains null", () =>
            {
                var mem = new FakeMemory(); var reader = new GameReader(mem, _ => { });
                Check(reader.DiscoverLocalPlayer(), "discover");
                mem.Ints.Remove(FakeMemory.Client + GameOffsets.ClientMoneyDirectRva);
                Check(reader.TryReadState(out var s) && s.Money == null && s.Armor == 0, "optional read");
            });
            Test("module can appear after startup", () =>
            {
                var mem = new FakeMemory(); mem.Modules.Remove("client.dll");
                var reader = new GameReader(mem, _ => { });
                Check(!reader.DiscoverLocalPlayer(), "not loaded yet");
                mem.Modules["client.dll"] = FakeMemory.Client;
                Check(reader.DiscoverLocalPlayer() && reader.TryReadState(out _), "loaded later");
            });
            Test("raw XYZ is opt-in and re-read without fallback", () =>
            {
                var mem = new FakeMemory(); var logs = new List<string>();
                var reader = new GameReader(mem, logs.Add);
                Check(reader.DiscoverLocalPlayer() && reader.TryReadState(out _), "read");
                Check(mem.VecReads == 0, "no automatic coordinate reads");
                reader.ProbeRawXyz = true;
                Check(reader.TryReadState(out _), "probe one");
                mem.Xyz = (1, 2, 3);
                Check(reader.TryReadState(out _), "probe two");
                Check(mem.VecReads == 2 && logs.Last().Contains("1.000, 2.000, 3.000"), "fresh raw values");
            });
            Test("out-of-range module RVAs are rejected", () =>
            {
                var mem = new FakeMemory(); mem.ModuleSizes["client.dll"] = 0x1000;
                Check(!new GameReader(mem, _ => { }).DiscoverLocalPlayer(), "must reject profile");
            });
            Test("client relocation invalidates selected profile", () =>
            {
                var mem = new FakeMemory(); var reader = new GameReader(mem, _ => { });
                Check(reader.DiscoverLocalPlayer(), "discover");
                mem.Modules["client.dll"] += 0x10000;
                Check(!reader.TryReadState(out _), "relocation rejected");
            });
            Test("48-byte view layout separates basis and origin", () =>
            {
                var data = new byte[ViewProbe.Size];
                float[] numbers = { 0, 0, 1, 1, 0, 0, 0, 1, 0, 100, 200, 300 };
                for (int i = 0; i < numbers.Length; i++) BitConverter.GetBytes(numbers[i]).CopyTo(data, i * 4);
                var frame = ViewProbe.Decode(data);
                Check(frame.Origin == new ProbeVector(100, 200, 300), "origin at offset 36");
                Check(ViewProbe.CheckBasis(frame).Plausible, "orthonormal basis");
            });
            Test("zero frame is not a camera basis", () =>
            {
                Check(!ViewProbe.CheckBasis(ViewProbe.Decode(new byte[48])).Plausible, "zero rejected");
            });
            Test("parallel unit vectors are not a camera basis", () =>
            {
                var vector = new ProbeVector(1, 0, 0);
                Check(!ViewProbe.CheckBasis(new ViewFrame(vector, vector, vector, default)).Plausible, "parallel rejected");
            });
            Test("nonfinite values are not a camera basis", () =>
            {
                var f = new ViewFrame(new(0, 0, 1), new(1, 0, 0), new(0, 1, 0), new(float.NaN, 0, 0));
                Check(!ViewProbe.CheckBasis(f).Plausible, "NaN origin rejected");
            });
            Test("movement profile matches relocated instructions", () =>
            {
                var mem = MovementMemory();
                Check(new MovementProbe(mem).TryRead(out var m, out _), "movement read");
                Check(m.Origin == new ProbeVector(100, 200, 300), "origin offset 0x38");
                Check(m.Angles == new ProbeVector(0, 90, 0) && m.OnGround == 0, "angles and ground");
            });
            Test("mismatched movement code is rejected", () =>
            {
                var mem = MovementMemory(); mem.ByteBlocks[FakeMemory.Client + MovementProbe.MoveCodeRva][0] = 0x90;
                Check(!new MovementProbe(mem).TryRead(out _, out var why) && why.Contains("инструкции"), "wrong code");
            });
            Test("null movement pointer is not accepted", () =>
            {
                var mem = MovementMemory(); mem.UInts[FakeMemory.Client + MovementProbe.PointerRva] = 0;
                Check(!new MovementProbe(mem).TryRead(out _, out _), "null pointer");
            });
            Test("server movement is rejected for local-player probe", () =>
            {
                var data = MovementHeader(); BitConverter.GetBytes(1).CopyTo(data, 4);
                Check(!MovementProbe.TryDecode(0x20000000, data, out _, out _), "server rejected");
            });
            Test("nonfinite movement position is rejected", () =>
            {
                var data = MovementHeader(); BitConverter.GetBytes(float.NaN).CopyTo(data, 0x38);
                Check(!MovementProbe.TryDecode(0x20000000, data, out _, out _), "NaN rejected");
            });
            Test("movement zero origin and airborne marker are legal", () =>
            {
                var data = MovementHeader(); Array.Clear(data, 0x38, 12);
                BitConverter.GetBytes(-1).CopyTo(data, 0xE0);
                Check(MovementProbe.TryDecode(0x20000000, data, out var m, out _) && m.OnGround == -1, "airborne origin zero");
            });
            Test("ULZ literal stream decodes exactly", () =>
            {
                Check(NavGraph.DecodeUlz(new byte[] { 0x60, 65, 66, 67 }, 3).SequenceEqual(new byte[] { 65,66,67 }), "literal");
            });
            Test("ULZ rejects invalid back reference", () =>
            {
                bool failed = false;
                try { NavGraph.DecodeUlz(new byte[] { 0,1,0 }, 4); } catch (InvalidDataException) { failed = true; }
                Check(failed, "invalid reference rejected");
            });
            Test("graph edges stay directed", () =>
            {
                var g = SmallGraph();
                Check(g.FindRoute(0, 2)?.Nodes.SequenceEqual(new[] {0,1,2}) == true, "forward route");
                Check(g.FindRoute(2, 0) == null, "must not invent reverse edge");
            });
            Test("jump edges need explicit planning opt-in", () =>
            {
                var g = SmallGraph(1);
                Check(g.FindRoute(0, 2) == null, "jump excluded by default");
                Check(g.FindRoute(0, 2, allowSpecial: true) != null, "jump planning opt in");
            });
            Test("team-only nodes are filtered", () =>
            {
                var g = SmallGraph(0, 1 << 30);
                Check(g.FindRoute(0, 2, "t") == null && g.FindRoute(0, 2, "any") == null, "CT only blocked");
                Check(g.FindRoute(0, 2, "ct") != null, "CT allowed");
            });
            Test("bundled dust2 graph loads and route follows real links", () =>
            {
                var g = NavGraph.Load(Path.Combine(AppContext.BaseDirectory, "de_dust2.graph"));
                Check(g.Nodes.Count == 1238, "bundled node count");
                var route = g.FindRoute(0, 66);
                Check(route != null && route.Nodes.First() == 0 && route.Nodes.Last() == 66, "route endpoints");
                for (int i = 1; i < route!.Nodes.Count; i++)
                    Check(g.Nodes[route.Nodes[i-1]].Links.Any(l => l.To == route.Nodes[i] && l.Flags == 0), "route uses graph edge");
            });
            Test("BSP point contents and clear segment", () =>
            {
                var map=BspMap.FromBytes(SyntheticBsp());
                Check(map.PointContents(new(1,0,0))==-1 && map.PointContents(new(-1,0,0))==-2,"halfspace");
                Check(map.WorldPointSegmentClear(new(1,0,0),new(3,0,0)),"clear");
                Check(!map.WorldPointSegmentClear(new(1,0,0),new(-3,0,0)),"crossing solid");
                Check(!map.WorldPointSegmentClear(new(-1,0,0),new(3,0,0)),"reverse solid");
            });
            Test("BSP trace detects wall between two empty endpoints", () =>
            {
                var original=SyntheticBsp(); var data=new byte[original.Length+40]; original.CopyTo(data,0);
                void I(int o,int v)=>BitConverter.GetBytes(v).CopyTo(data,o);
                void S(int o,short v)=>BitConverter.GetBytes(v).CopyTo(data,o);
                void F(int o,float v)=>BitConverter.GetBytes(v).CopyTo(data,o);
                I(12,original.Length); I(16,40); F(original.Length,1); F(original.Length+20,1); F(original.Length+32,2);
                int n=BitConverter.ToInt32(data,44);
                I(n,0); S(n+4,1); S(n+6,-2); I(n+24,1); S(n+28,-2); S(n+30,-1);
                var map=BspMap.FromBytes(data);
                Check(map.PointContents(new(-1,0,0))==-1 && map.PointContents(new(3,0,0))==-1,"empty endpoints");
                Check(!map.WorldPointSegmentClear(new(-1,0,0),new(3,0,0)),"interior wall");
                Check(!map.WorldPointSegmentClear(new(3,0,0),new(-1,0,0)),"reverse interior wall");
                Check(map.WorldPointSegmentClear(new(3,0,0),new(3,0,0)),"zero length empty");
            });
            Test("BSP bomb goal association uses brush model", () =>
            {
                var map=BspMap.FromBytes(SyntheticBsp()); var zone=map.BombZones().Single();
                Check(zone.Label=="a" && zone.Model==1,"target label");
                Check(map.InsideZone(new(2,0,0),zone),"inside");
                Check(!map.InsideZone(new(-2,0,0),zone) && !map.InsideZone(new(20,0,0),zone),"outside");
            });
            Test("BSP rejects unsupported version", () => RejectBsp(b=>BitConverter.GetBytes(29).CopyTo(b,0)));
            Test("BSP rejects negative lump", () => RejectBsp(b=>BitConverter.GetBytes(-1).CopyTo(b,4)));
            Test("BSP rejects lump outside file", () => RejectBsp(b=>BitConverter.GetBytes(int.MaxValue).CopyTo(b,8)));
            Test("BSP rejects plane stride", () => RejectBsp(b=>BitConverter.GetBytes(19).CopyTo(b,16)));
            Test("BSP rejects NaN plane", () => RejectBsp(b=>BitConverter.GetBytes(float.NaN).CopyTo(b,BitConverter.ToInt32(b,12))));
            Test("BSP rejects out of range child", () => RejectBsp(b=>BitConverter.GetBytes((short)300).CopyTo(b,BitConverter.ToInt32(b,44)+4)));
            Test("BSP rejects cyclic node", () => RejectBsp(b=>BitConverter.GetBytes((short)0).CopyTo(b,BitConverter.ToInt32(b,44)+4)));
            Test("BSP rejects unknown leaf content", () => RejectBsp(b=>BitConverter.GetBytes(0).CopyTo(b,BitConverter.ToInt32(b,84))));
            Test("graph edge predicate excludes forbidden links", () =>
            { Check(SmallGraph().FindRoute(0,2,edgeAllowed:(from,edge)=>from!=1)==null,"filter applied"); });
            Test("map route attaches coordinates to graph and site", () =>
            {
                var graph=SmallGraph(); graph.Nodes[2]=graph.Nodes[2] with {Flags=NavGraph.GoalFlag};
                var nav=new MapNavigation(graph,BspMap.FromBytes(SyntheticBsp()));
                var route=nav.Plan(new(0,0,0),"a","t");
                Check(route!=null && route.Anchor==0 && route.Route.Nodes.SequenceEqual(new[]{0,1,2}),"anchored site route");
                Check(nav.Plan(new(1000,0,0),"a","t")==null,"no distant snap");
            });
            Test("CFG numeric values accept dot comma and whitespace",()=>
            {
                Check(Math.Abs(GameConfig.ParseDpc(" 0.07106 ")-.07106)<1e-10,"dot");
                Check(Math.Abs(GameConfig.ParseDpc("0,07106")-.07106)<1e-10,"comma");
            });
            Test("CFG rejects malformed and nonfinite calibration with friendly error",()=>
            {
                foreach(string value in new[]{"NaN","Infinity","0,07.1","hello","0","-1","0.07106 text","3"})
                {
                    bool rejected=false;try{GameConfig.ParseDpc(value);}catch(ArgumentException e){rejected=e.Message.Contains("--degrees-per-count");}
                    Check(rejected,"bad number "+value);
                }
            });
            void WithCfg(Action<string> test)
            {
                string dir=Path.Combine(Path.GetTempPath(),"csbot-cfg-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(dir);
                try{test(dir);}finally{Directory.Delete(dir,true);}
            }
            const string baseCfg="sensitivity \"3.230000\"; m_yaw \"0.022\"\nbind w +forward\nbind SHIFT +speed\n";
            Test("CFG user values yield 0.07106 without executing commands",()=>WithCfg(dir=>
            {
                string path=Path.Combine(dir,"config.cfg");File.WriteAllText(path,baseCfg+"m_filter 0\nquit\n");
                var c=GameConfig.Load(path);Check(Math.Abs(c.DegreesPerCount-.07106)<1e-10,"product");
                Check(c.Bindings["w"]=="+forward" && c.Bindings["SHIFT"]=="+speed","bindings");
                Check(c.Warnings.Count==0,"no warnings");
            }));
            Test("CFG exec follows order and later settings override includes",()=>WithCfg(dir=>
            {
                string path=Path.Combine(dir,"config.cfg");File.WriteAllText(path,baseCfg+"exec userconfig.cfg\nsensitivity 4\n");
                File.WriteAllText(Path.Combine(dir,"userconfig.cfg"),"sensitivity 2; m_yaw 0.02\n");
                var c=GameConfig.Load(path);Check(Math.Abs(c.DegreesPerCount-.08)<1e-10 && c.Files.Count==2,"ordered override");
            }));
            Test("CFG missing exec is explicit warning not silent override",()=>WithCfg(dir=>
            {
                string path=Path.Combine(dir,"config.cfg");File.WriteAllText(path,baseCfg+"exec absent.cfg\n");
                Check(GameConfig.Load(path).Warnings.Any(w=>w.Contains("absent.cfg")),"missing include warning");
            }));
            Test("CFG rejects include cycles and traversal",()=>WithCfg(dir=>
            {
                string path=Path.Combine(dir,"config.cfg");
                foreach(string tail in new[]{"exec config.cfg","exec ../other.cfg"})
                {
                    File.WriteAllText(path,baseCfg+tail);bool rejected=false;
                    try{GameConfig.Load(path);}catch(InvalidDataException){rejected=true;}Check(rejected,"bad exec");
                }
            }));
            Test("CFG tokenizer preserves semicolons and comments inside quotes",()=>
            {
                var t=GameConfig.Tokenize("bind q \"say // text; hi\"; sensitivity 3 // comment\nm_yaw 0.022");
                Check(t.Count==3 && t[0][2]=="say // text; hi" && t[1][0]=="sensitivity","tokenization");
            });
            Test("v19 CFG allows unbound Shift because bot never synthesizes it",()=>WithCfg(dir=>
            {
                string path=Path.Combine(dir,"config.cfg");File.WriteAllText(path,baseCfg+"exec userconfig.cfg");
                File.WriteAllText(Path.Combine(dir,"userconfig.cfg"),"unbind SHIFT");
                Check(!GameConfig.Load(path).Warnings.Any(w=>w.Contains("bind SHIFT")),"Shift no longer required");
            }));
            Test("CFG warns for filters and dynamic aliases",()=>WithCfg(dir=>
            {
                string path=Path.Combine(dir,"config.cfg");File.WriteAllText(path,baseCfg+"m_filter 1; alias foo \"sensitivity 9\"");
                var c=GameConfig.Load(path);Check(c.Warnings.Count==2,"filter and alias warnings");
            }));
            Test("CFG UTF8 BOM and default exec extension are handled",()=>WithCfg(dir=>
            {
                string path=Path.Combine(dir,"config.cfg");File.WriteAllText(path,baseCfg+"exec userconfig",new System.Text.UTF8Encoding(true));
                File.WriteAllText(Path.Combine(dir,"userconfig.cfg"),"sensitivity 2");
                Check(Math.Abs(GameConfig.Load(path).DegreesPerCount-.044)<1e-10,"BOM and extension");
            }));
            MoveSample Pose(float time=1,ProbeVector? pos=null,ProbeVector? angles=null)=>new(0x20000000,0,0,time,0.01f,
                pos??new ProbeVector(0,0,36.04f),angles??default,default,new(0,0,17),0,0,0,0,0);
            WalkCheck Clear(ProbeVector a,ProbeVector b)=>new(true,"test clear",b);
            Test("SendInput x64 ABI is 40 bytes",()=>Check(WindowsControl.InputSize==40,"ABI size"));
            Test("input refuses arming while user holds controls",()=>
            {
                var backend=new FakeControlBackend{UserBusy=true};using var input=new WindowsControl(backend,false);
                bool refused=false;try {input.Arm();}catch(InvalidOperationException){refused=true;}
                Check(refused && backend.KeyEvents.Count==0,"manual keys held");
            });
            Test("input gate releases on focus loss and latches stop",()=>
            {
                var backend=new FakeControlBackend();using var input=new WindowsControl(backend,false);
                input.Arm();input.Apply(new(true,0,false,"",0));backend.Focused=false;input.CheckWatchdog();
                Check(backend.KeyEvents.SequenceEqual(new[]{true,false}) && input.Fault!="","release on focus loss");
                bool refused=false;try {input.Arm();} catch(InvalidOperationException){refused=true;}Check(refused,"no auto rearm");
            });
            Test("input watchdog releases on heartbeat timeout",()=>
            {
                var backend=new FakeControlBackend();using var input=new WindowsControl(backend,false);
                input.Arm();input.Apply(new(true,0,false,"",0));backend.Now=251;input.CheckWatchdog();
                Check(backend.KeyEvents.Last()==false && input.Fault.Contains("watchdog"),"timeout release");
            });
            Test("input stop key prevents further mouse or movement",()=>
            {
                var backend=new FakeControlBackend();using var input=new WindowsControl(backend,false);
                input.Arm();input.Apply(new(true,0,false,"",0));backend.StopPressed=true;
                input.Apply(new(true,12,false,"",0));
                Check(backend.KeyEvents.SequenceEqual(new[]{true,false}) && backend.MouseEvents.Count==0,"stop and release");
            });
            Test("input disposal releases owned keys",()=>
            {
                var backend=new FakeControlBackend();using(var input=new WindowsControl(backend,false))
                {input.Arm();input.Apply(new(true,0,false,"",0));}
                Check(backend.KeyEvents.SequenceEqual(new[]{true,false}),"dispose releases");
            });
            Test("partial key-down failure still attempts key release",()=>
            {
                var backend=new FakeControlBackend{DownFails=true};
                try {using var input=new WindowsControl(backend,false);input.Arm();input.Apply(new(true,0,false,"",0));}
                catch(InvalidOperationException){}
                Check(backend.KeyEvents.SequenceEqual(new[]{true,false}),"partial release attempted");
            });
            Test("guard requires advancing movement time",()=>
            {
                var guard=new LiveSampleGuard(); for(int i=0;i<4;i++) Check(guard.Observe(Pose(1+i*.05f),100,i*50)=="","sample");
                Check(guard.Advances==3,"three advances");
            });
            Test("guard rejects stale movement time",()=>
            {
                var g=new LiveSampleGuard();g.Observe(Pose(),100,0);g.Observe(Pose(),100,100);g.Observe(Pose(),100,200);
                Check(g.Observe(Pose(),100,300).Contains("stale"),"stale time");
            });
            Test("guard rejects sampling stalls",()=>
            { var g=new LiveSampleGuard();g.Observe(Pose(),100,0);Check(g.Observe(Pose(2),100,300).Contains("gap"),"300ms gap"); });
            Test("guard rejects death spectator air and crouch",()=>
            {
                Check(new LiveSampleGuard().Observe(Pose(),0,0)!="","hp zero");
                foreach(var p in new[]{Pose() with{Dead=1},Pose() with{Spectator=1},Pose() with{OnGround=-1},Pose() with{Flags=1<<14},Pose() with{Flags=1<<12}})
                    Check(new LiveSampleGuard().Observe(p,100,0)!="","bad state");
            });
            Test("guard rejects pointer time and position discontinuities",()=>
            {
                foreach(var p in new[]{Pose(2) with{Pointer=0x30000000},Pose(0.5f),Pose(2,new(1000,0,36))})
                { var g=new LiveSampleGuard();g.Observe(Pose(),100,0);Check(g.Observe(p,100,50)!="","context discontinuity"); }
            });
            Test("controller releases intent on focus loss",()=>
            { var c=new TravelController(new[]{new ProbeVector(100,0,36.04f)},Clear,.055);Check(c.Tick(Pose(),0,false).StopReason.Contains("focus"),"focus"); });
            Test("controller correct yaw sign and no forward while turning",()=>
            {
                var c=new TravelController(new[]{new ProbeVector(0,100,36.04f)},Clear,.055);
                var r=c.Tick(Pose(),0,true);Check(!r.Forward && r.MouseDx<0,"turn left for positive yaw");
            });
            Test("controller moves only when aligned",()=>
            { var c=new TravelController(new[]{new ProbeVector(100,0,36.04f)},Clear,.055);Check(c.Tick(Pose(),0,true).Forward,"aligned W"); });
            Test("controller stops on stuck progress",()=>
            {
                var c=new TravelController(new[]{new ProbeVector(100,0,36.04f)},Clear,.055);c.Tick(Pose(),0,true);
                Check(c.Tick(Pose(2.9f),1900,true).StopReason.Contains("stuck"),"stuck");
            });
            Test("controller stops on absent mouse response",()=>
            {
                var c=new TravelController(new[]{new ProbeVector(0,100,36.04f)},Clear,.055);c.Tick(Pose(),0,true);
                Check(c.Tick(Pose(2.6f),1600,true).StopReason.Contains("yaw response"),"no response");
            });
            Test("controller rejects geometry pitch and excessive speed",()=>
            {
                var c=new TravelController(new[]{new ProbeVector(100,0,36.04f)},(a,b)=>new(false,"wall",a),.055);
                Check(c.Tick(Pose(),0,true).StopReason.Contains("wall"),"geometry");
                var good=new TravelController(new[]{new ProbeVector(100,0,36.04f)},Clear,.055);
                Check(good.Tick(Pose(1,angles:new(80,0,0)),0,true).StopReason.Contains("pitch"),"pitch");
                Check(good.Tick(Pose() with{Velocity=new(250,0,0)},0,true).StopReason.Contains("speed"),"speed");
            });
            Test("controller finishes without further movement",()=>
            { var c=new TravelController(new[]{new ProbeVector(0,0,36.04f)},Clear,.055);var r=c.Tick(Pose(),0,true);Check(r.Finished && !r.Forward && r.MouseDx==0,"done"); });
            Test("controller kinematic simulation follows a two-leg route",()=>
            {
                var controller=new TravelController(new[]{new ProbeVector(100,0,36.04f),new ProbeVector(100,100,36.04f)},Clear,.055);
                var pose=Pose();double vx=0,vy=0,yaw=0;bool done=false;
                for(int i=0;i<1500;i++)
                {
                    var command=controller.Tick(pose,i*50,true);Check(command.StopReason=="","sim stop: "+command.StopReason);
                    if(command.Finished){done=true;break;}
                    yaw=TravelController.Normalize(yaw-command.MouseDx*.055);
                    if(command.Forward){vx=100*Math.Cos(yaw*Math.PI/180);vy=100*Math.Sin(yaw*Math.PI/180);}
                    else {vx*=.5;vy*=.5;}
                    pose=pose with{Time=1+(i+1)*.05f,Origin=new((float)(pose.Origin.X+vx*.05),(float)(pose.Origin.Y+vy*.05),36.04f),
                        Angles=new(0,(float)yaw,0),Velocity=new((float)vx,(float)vy,0)};
                }
                Check(done && NavGraph.Distance(pose.Origin,new(100,100,36.04f))<4.1,"completed route in ideal kinematic model");
            });
            Test("steering sends one pulse then waits for feedback",()=>
            {
                var steering=new PulseSteering(.07106);var first=steering.Tick(99,-99,0,true);
                Check(first.MouseDx>0 && first.MouseDx<=8,"tiny initial pulse");
                Check(steering.Tick(99,-99,50,true).MouseDx==0,"no burst at 50ms");
                Check(steering.Tick(99,-99,100,true).MouseDx==0,"no burst at 100ms");
            });
            Test("steering learns actual gain instead of trusting CFG",()=>
            {
                var steering=new PulseSteering(.07106);var first=steering.Tick(9.27,-8.35,0,true);
                double actual=9.27-first.MouseDx*.246;
                Check(steering.Tick(actual,.92-actual,50,true).MouseDx==0,"settle");
                steering.Tick(actual,.92-actual,150,true);
                Check(Math.Abs(steering.LastMeasuredGain-.246)<.001 && steering.Gain>.246,"measured actual gain");
            });
            Test("steering rejects wrong-sign response",()=>
            {
                var st=new PulseSteering(.07106);var pulse=st.Tick(10,-10,0,true);
                st.Tick(12,-12,50,true);var result=st.Tick(12,-12,150,true);
                Check(result.StopReason.Contains("sign") && result.MouseDx==0,"wrong sign stop");
            });
            Test("controller does not accumulate input on same movement sample",()=>
            {
                var c=new TravelController(new[]{new ProbeVector(0,100,36.04f)},Clear,.07106);
                Check(c.Tick(Pose(),0,true).MouseDx!=0,"initial pulse");
                var stale=c.Tick(Pose(),50,true);Check(stale.MouseDx==0 && !stale.Forward && stale.Mode=="wait-fresh-sample","stale sample wait");
            });
            Test("controller hysteresis avoids chatter near aligned heading",()=>
            {
                var c=new TravelController(new[]{new ProbeVector(100,0,36.04f)},Clear,.07106);
                Check(c.Tick(Pose(),0,true).Forward,"initial aligned");
                var next=c.Tick(Pose(1.05f,angles:new(0,4.5f,0)),50,true);
                Check(next.Forward && next.MouseDx==0,"4.5 degrees does not flip walking to turn");
            });
            Test("user-log oscillation regression converges with stronger delayed response",()=>
            {
                foreach(double start in new[]{9.27,-4.73})
                foreach(int delay in new[]{0,100,250})
                {
                    var target=new ProbeVector(-740.3068f,-786.30365f,164.03125f);
                    var pose=Pose(1,new(-857.625f,-788.188f,164.03125f),new(3.8f,(float)start,0));
                    var c=new TravelController(new[]{target},Clear,.07106);var queue=new List<(long At,int Dx)>();
                    double yaw=start; bool walk=false; long previousPulse=-10000;
                    for(int i=0;i<200;i++)
                    {
                        long now=i*50;
                        foreach(var item in queue.Where(x=>x.At<=now).ToArray()){yaw=TravelController.Normalize(yaw-item.Dx*.246);queue.Remove(item);}
                        pose=pose with{Time=1+i*.05f,Angles=new(3.8f,(float)yaw,0)};
                        var command=c.Tick(pose,now,true);Check(command.StopReason=="","regression stop: "+command.StopReason);
                        if(command.MouseDx!=0){Check(now-previousPulse>=120,"isolated pulses");previousPulse=now;queue.Add((now+delay,command.MouseDx));}
                        if(command.Forward){Check(Math.Abs(command.YawError)<=2.5,"aligned before forward");walk=true;break;}
                    }
                    Check(walk,"converged for yaw/delay "+start+" / "+delay);
                }
            });
            Test("steering 159-degree turn converges across supported delayed gains",()=>
            {
                foreach(double gain in new[]{.025,.07106,.246,.8})
                {
                    var st=new PulseSteering(.07106);var queue=new List<(long At,int Dx)>();double yaw=159;bool aligned=false;
                    for(int i=0;i<600;i++)
                    {
                        long now=i*50;
                        foreach(var item in queue.Where(x=>x.At<=now).ToArray()){yaw=TravelController.Normalize(yaw-item.Dx*gain);queue.Remove(item);}
                        double error=TravelController.Normalize(-yaw);var result=st.Tick(yaw,error,now,Math.Abs(error)>2.5);
                        Check(result.StopReason=="","pulse turn: "+result.StopReason);
                        if(result.MouseDx!=0)queue.Add((now+150,result.MouseDx));
                        if(!result.Waiting && Math.Abs(error)<=2.5){aligned=true;break;}
                    }
                    Check(aligned,"turn gain "+gain);
                }
            });
            Test("combined input sends forward and mouse in one update",()=>
            {
                var backend=new FakeControlBackend();using var input=new WindowsControl(backend,false);input.Arm();
                input.Apply(new(true,5,false,"",0,Walk:false));
                Check(backend.KeyEvents.SequenceEqual(new[]{true}) && backend.MouseEvents.SequenceEqual(new[]{5}) && !backend.WalkModes[0],"simultaneous run and mouse");
            });
            Test("input switches walk run without releasing forward between modes",()=>
            {
                var backend=new FakeControlBackend();using var input=new WindowsControl(backend,false);input.Arm();
                input.Apply(new(true,0,false,"",0));input.Apply(new(true,0,false,"",0,Walk:false));input.Apply(new(true,0,false,"",0,Walk:false));
                Check(backend.KeyEvents.SequenceEqual(new[]{true,true}) && backend.WalkModes.SequenceEqual(new[]{true,false}),"only speed mode changed");
            });
            Test("combined profile runs on long clear straight",()=>
            {
                var c=new TravelController(new[]{new ProbeVector(300,0,36.04f)},Clear,.07106,TravelOptions.Balanced);
                var cmd=c.Tick(Pose(),0,true);Check(cmd.Forward && !cmd.Walk,"running allowed");
            });
            Test("combined walk-only profile never requests run",()=>
            {
                var c=new TravelController(new[]{new ProbeVector(300,0,36.04f)},Clear,.07106,TravelOptions.CombinedWalk);
                Check(c.Tick(Pose(),0,true).Walk,"walk mode");
            });
            Test("combined heading prediction denies blind forward movement",()=>
            {
                var c=new TravelController(new[]{new ProbeVector(300,0,36.04f)},Clear,.07106,TravelOptions.Balanced,
                    (p,yaw,d)=>new(false,"wall in actual heading",p));
                var first=c.Tick(Pose(),0,true);Check(!first.Forward,"blocked heading");
                var last=c.Tick(Pose(2.3f),1300,true);Check(last.StopReason.Contains("clearance"),"not infinite waiting");
            });
            Test("combined run requires lateral clearance too",()=>
            {
                var c=new TravelController(new[]{new ProbeVector(300,0,36.04f)},Clear,.07106,TravelOptions.Balanced,
                    (p,yaw,d)=>new(Math.Abs(yaw)<1,"side margin",p));
                var cmd=c.Tick(Pose(),0,true);Check(cmd.Forward && cmd.Walk,"walk when side margin not clear");
            });
            Test("combined uses walk before sharp upcoming corner",()=>
            {
                var c=new TravelController(new[]{new ProbeVector(200,0,36.04f),new ProbeVector(200,200,36.04f)},Clear,.07106,TravelOptions.Balanced);
                var cmd=c.Tick(Pose(),0,true);Check(cmd.Forward && cmd.Walk,"corner does not request run");
            });
            Test("combined checks straight lookahead instead of stopping at every node",()=>
            {
                var c=new TravelController(new[]{new ProbeVector(40,0,36.04f),new ProbeVector(90,0,36.04f),new ProbeVector(150,0,36.04f)},Clear,.07106,TravelOptions.Balanced);
                var cmd=c.Tick(Pose(),0,true);Check(cmd.TargetIndex==2 && cmd.Forward,"straight line lookahead");
            });
            Test("supported-air grace is bounded and still needs external floor evidence",()=>
            {
                var g=new LiveSampleGuard();var air=Pose() with{OnGround=-1};
                Check(g.Observe(air,100,0,true)=="","first supported air");
                Check(g.Observe(air with{Time=1.05f},100,50,true)=="","brief supported air");
                Check(g.Observe(air with{Time=1.15f},100,150,true).Contains("120ms"),"deadline");
                Check(new LiveSampleGuard().Observe(air,100,0).Contains("not grounded"),"no evidence no grace");
            });
            Test("frame guard reports concrete frametime separately",()=>
            {Check(new LiveSampleGuard().Observe(Pose() with{FrameTime=0},100,0).Contains("frameTime=0"),"specific frame failure");});
            (int Ms,int Simultaneous) SimulatedTrip(TravelOptions option)
            {
                var targets=new[]{new ProbeVector(100,0,36.04f),new ProbeVector(240,0,36.04f),new ProbeVector(240,120,36.04f)};
                var c=new TravelController(targets,Clear,.07106,option);double x=0,y=0,vx=0,vy=0,yaw=159;
                var queue=new List<(long At,int Dx)>();int combined=0;
                for(int i=0;i<4000;i++)
                {
                    long now=i*25;
                    foreach(var item in queue.Where(v=>v.At<=now).ToArray()){yaw=TravelController.Normalize(yaw-item.Dx*.125);queue.Remove(item);}
                    var pose=Pose(1+i*.025f,new((float)x,(float)y,36.04f),new(0,(float)yaw,0)) with{Velocity=new((float)vx,(float)vy,0)};
                    var cmd=c.Tick(pose,now,true);Check(cmd.StopReason=="","simulation stop: "+cmd.StopReason);
                    if(cmd.Finished)return ((int)now,combined);
                    if(cmd.MouseDx!=0)queue.Add((now+50,cmd.MouseDx));
                    if(cmd.Forward && cmd.MouseDx!=0)combined++;
                    if(cmd.Forward)
                    {
                        double speed=cmd.Walk?125:250;double targetVx=speed*Math.Cos(yaw*Math.PI/180),targetVy=speed*Math.Sin(yaw*Math.PI/180);
                        vx+=.35*(targetVx-vx);vy+=.35*(targetVy-vy);
                    }
                    else{vx*=.6;vy*=.6;}
                    x+=vx*.025;y+=vy*.025;
                }
                throw new Exception("Kinematic trip did not finish");
            }
            Test("combined model finishes faster and corrects mouse while moving",()=>
            {
                var old=SimulatedTrip(TravelOptions.Cautious);var fast=SimulatedTrip(TravelOptions.Balanced);
                Check(fast.Ms<old.Ms*.8 && fast.Simultaneous>0,"faster combined trip");
                Console.WriteLine($"MODEL ONLY trip: cautious={old.Ms}ms combined={fast.Ms}ms simultaneous={fast.Simultaneous}");
            });
            Test("fast pulse feedback converges with delay and count-dependent gain",()=>
            {
                foreach(int delay in new[]{0,100,250})
                foreach(int profile in new[]{0,1,2,3})
                {
                    var st=new PulseSteering(.07106,true);double yaw=159;bool aligned=false;
                    var queue=new List<(long At,int Dx)>();
                    for(int i=0;i<1000;i++)
                    {
                        long now=i*25;
                        foreach(var item in queue.Where(v=>v.At<=now).ToArray())
                        {
                            double gain=profile switch{0=>.07106,1=>.246,2=>.5,_=>.08+.001*Math.Abs(item.Dx)};
                            yaw=TravelController.Normalize(yaw-item.Dx*gain);queue.Remove(item);
                        }
                        double error=TravelController.Normalize(-yaw);var step=st.Tick(yaw,error,now,Math.Abs(error)>1.5);
                        Check(step.StopReason=="","fast feedback stop: "+step.StopReason);
                        if(step.MouseDx!=0)queue.Add((now+delay,step.MouseDx));
                        if(!step.Waiting && Math.Abs(error)<=1.5){aligned=true;break;}
                    }
                    Check(aligned,"fast feedback convergence");
                }
            });
            Test("fast steering brakes before bounded retry and recovers dropped packet",()=>
            {
                var st=new PulseSteering(.1,true);var first=st.Tick(10,-10,0,true);
                var brake=st.Tick(10,-10,300,true,100);Check(brake.HoldMovement && brake.MouseDx==0,"brake first");
                Check(st.Tick(10,-10,500,true,20).MouseDx==0,"no retry while moving");
                var retry=st.Tick(10,-10,550,true,0);
                Check(retry.HoldMovement && Math.Sign(retry.MouseDx)==Math.Sign(first.MouseDx) && Math.Abs(retry.MouseDx)<=8,"small same sign retry");
                Check(st.Tick(10,-10,575,true,0).HoldMovement,"remain braked awaiting retry response");
                double yaw=10-retry.MouseDx*.1;
                st.Tick(yaw,-yaw,600,true);
                var recovered=st.Tick(yaw,-yaw,750,true);
                Check(recovered.StopReason=="" && st.LastMeasuredGain>0 && !recovered.HoldMovement,"feedback recovered");
            });
            Test("fast steering missing responses has finite retry budget",()=>
            {
                var st=new PulseSteering(.1,true);int packets=0;string stop="";
                for(int now=0;now<=3000;now+=25)
                {
                    var cmd=st.Tick(10,-10,now,true,0);if(cmd.MouseDx!=0)packets++;
                    if(cmd.StopReason!=""){stop=cmd.StopReason;break;}
                }
                Check(packets==3 && stop.Contains("bounded"),"initial packet plus two retries then stop");
            });
            Test("fast steering never retries unbraked motion indefinitely",()=>
            {
                var st=new PulseSteering(.1,true);st.Tick(10,-10,0,true,100);
                var cmd=st.Tick(10,-10,1100,true,100);
                Check(cmd.StopReason!="" && cmd.MouseDx==0,"moving input failure stops");
            });
            Test("combined controller releases forward during missing mouse response",()=>
            {
                var c=new TravelController(new[]{new ProbeVector(300,0,36.04f)},Clear,.1,TravelOptions.Balanced);
                c.Tick(Pose(1,angles:new(0,10,0)),0,true);
                c.Tick(Pose(1.05f,angles:new(0,9.2f,0)),50,true);
                var moving=c.Tick(Pose(1.15f,angles:new(0,9.2f,0)),150,true);
                Check(moving.Forward && moving.MouseDx!=0,"learned correction while moving");
                var brake=c.Tick(Pose(1.45f,angles:new(0,9.2f,0)) with{Velocity=new(100,0,0)},450,true);
                Check(!brake.Forward && brake.MouseDx==0 && brake.Mode.Contains("retry-brake"),"retry releases W");
            });
            MapRoute RecoveryRoute()=>new(0,0,new("a","test",0,default,default),new(new(){0},0));
            Test("recovery whitelist rejects safety and feedback faults",()=>
            {
                foreach(string reason in new[]{"game lost foreground focus","dead/spectator/invalid HP","stale playermove time >250ms","mouse yaw response has unexpected sign","mouse response changed abruptly","pitch outside +/-25 degrees","read failure","watchdog fault"})
                    Check(!ReplanRecovery.CanRecover(reason),"must not recover: "+reason);
                foreach(string reason in new[]{"live path rejected: wall","heading clearance blocked for >1.2s","stuck: no progress","mouse input has no yaw response after bounded retry/brake","turn timeout: feedback did not converge"})
                    Check(ReplanRecovery.CanRecover(reason),"selected navigation failure");
            });
            Test("recovery brakes waits for stable floor then uses actual origin",()=>
            {
                int calls=0;ProbeVector origin=default;
                var recovery=new ReplanRecovery(p=>{calls++;origin=p;return Task.FromResult<MapRoute?>(RecoveryRoute());});
                Check(recovery.Begin("live path rejected: wall",0)=="","begin");
                var pose=Pose(pos:new(12,30,36.04f));
                Check(recovery.Tick(pose with{Velocity=new(80,0,0)},0,true).Mode=="recovery-brake" && calls==0,"no moving plan");
                Check(recovery.Tick(pose,100,true).Mode=="recovery-stabilize","settle");
                recovery.Tick(pose,499,true);Check(calls==0,"wait 400ms");
                recovery.Tick(pose,500,true);Check(calls==1 && origin==pose.Origin,"live origin");
                Check(recovery.Tick(pose,525,true).Route!=null && !recovery.Active,"route ready");
            });
            Test("recovery never blocks on an unfinished planner",()=>
            {
                var pending=new TaskCompletionSource<MapRoute?>();
                var recovery=new ReplanRecovery(_=>pending.Task);recovery.Begin("stuck: wall",0);
                recovery.Tick(Pose(),0,true);recovery.Tick(Pose(),400,true);
                Check(recovery.Tick(Pose(),600,true).Mode=="recovery-planning","poll pending without blocking");
                Check(recovery.Tick(Pose(),10001,true).StopReason.Contains("timeout"),"timeout even if worker pending");
                pending.SetResult(null);
            });
            Test("recovery exhausted after three route failures",()=>
            {
                var recovery=new ReplanRecovery(_=>Task.FromResult<MapRoute?>(null));
                recovery.Begin("stuck: wall",0);string stop="";
                for(int now=0;now<5000;now+=25){var step=recovery.Tick(Pose(),now,true);if(step.StopReason!=""){stop=step.StopReason;break;}}
                Check(recovery.Attempts==3 && stop.Contains("exhausted") && !recovery.Active,"finite retries");
            });
            Test("recovery budget is shared across repeated successful resumes",()=>
            {
                var recovery=new ReplanRecovery(_=>Task.FromResult<MapRoute?>(RecoveryRoute()));
                for(int i=0;i<3;i++)
                {
                    long now=i*1000;Check(recovery.Begin("stuck: test",now)=="","allowed attempt");
                    recovery.Tick(Pose(),now,true);recovery.Tick(Pose(),now+400,true);
                    Check(recovery.Tick(Pose(),now+425,true).Route!=null,"resume");
                }
                Check(recovery.Begin("stuck: repeated",4000).Contains("exhausted"),"no infinite resume cycle");
            });
            Test("recovery rejects stale planned attachment after displacement",()=>
            {
                var recovery=new ReplanRecovery(_=>Task.FromResult<MapRoute?>(RecoveryRoute()));
                recovery.Begin("stuck: test",0);recovery.Tick(Pose(),0,true);recovery.Tick(Pose(),400,true);
                var moved=Pose(pos:new(5,0,36.04f));recovery.Tick(moved,450,true);
                var result=recovery.Tick(moved,850,true);
                Check(result.Route==null && recovery.Attempts==2 && recovery.Active,"discard stale route and retry");
            });
            Test("recovery requires floor and re-stabilizes after disturbance",()=>
            {
                int calls=0;var recovery=new ReplanRecovery(_=>{calls++;return Task.FromResult<MapRoute?>(RecoveryRoute());});
                recovery.Begin("stuck: test",0);
                recovery.Tick(Pose(),0,true);recovery.Tick(Pose(),300,false);
                recovery.Tick(Pose(),400,true);recovery.Tick(Pose(),700,true);
                Check(calls==0,"unsupported gap reset stable timer");
                recovery.Tick(Pose(),800,true);Check(calls==1,"fresh stable floor");
            });
            Test("recovery planner exception becomes final stop",()=>
            {
                var recovery=new ReplanRecovery(_=>Task.FromException<MapRoute?>(new InvalidOperationException("fixture")));
                recovery.Begin("stuck: test",0);recovery.Tick(Pose(),0,true);recovery.Tick(Pose(),400,true);
                Check(recovery.Tick(Pose(),425,true).StopReason.Contains("fixture"),"fault surfaced");
            });
            Test("neutral recovery input releases keys without sending mouse",()=>
            {
                var backend=new FakeControlBackend();using var input=new WindowsControl(backend,false);input.Arm();
                input.Apply(new(true,0,false,"",0));input.Apply(new(false,0,false,"",-1,Mode:"recovery-neutral"));
                Check(backend.KeyEvents.SequenceEqual(new[]{true,false}) && backend.MouseEvents.Count==0,"release owned keys only");
            });
            Test("continuous recovery has no global route-attempt limit and uses backoff",()=>
            {
                int calls=0;var recovery=new ReplanRecovery(_=>{calls++;return Task.FromResult<MapRoute?>(null);},0);
                recovery.Begin("stuck: test",0);
                for(int now=0;now<=15000;now+=25)
                {
                    var result=recovery.Tick(Pose(),now,true);
                    Check(result.StopReason=="" && result.Route==null,"keeps waiting instead of exiting on no route");
                }
                Check(recovery.Active && recovery.Attempts>3 && calls<10,"continuous but throttled");
            });
            StepLandingPause LandingFixture()=>new((p,v,z)=>new(true,"fixture clear",p),_=>true);
            Test("landing requires recent verified grounded history",()=>
            {
                var air=Pose() with{OnGround=-1,Velocity=new(0,0,-4)};
                Check(LandingFixture().Observe(air,0).StopReason!="","cannot arm in midair");
                var landing=LandingFixture();landing.Observe(Pose(),0);
                Check(landing.Observe(air,251).StopReason!="","stale takeoff refused");
            });
            Test("landing state waits without resetting its time limit",()=>
            {
                var landing=LandingFixture();landing.Observe(Pose(),0);var air=Pose() with{OnGround=-1,Velocity=new(0,0,-4)};
                Check(landing.Observe(air,50).Waiting,"first air");
                Check(landing.Observe(air,500).Waiting,"still within500ms");
                Check(landing.Observe(air,551).StopReason.Contains("500ms"),"bounded total wait");
            });
            Test("landing rejects upward jump and excessive falling speed",()=>
            {
                foreach(float vz in new[]{10f,200f,-181f})
                {
                    var landing=LandingFixture();landing.Observe(Pose(),0);
                    Check(landing.Observe(Pose() with{OnGround=-1,Velocity=new(0,0,vz)},50).StopReason!="","velocity bound");
                }
            });
            Test("landing bounds total height from takeoff not each fresh sample",()=>
            {
                var landing=LandingFixture();landing.Observe(Pose(pos:new(0,0,52.04f)),0);
                Check(landing.Observe(Pose(pos:new(0,0,40)) with{OnGround=-1,Velocity=new(0,0,-80)},50).Waiting,"first12units");
                Check(landing.Observe(Pose(pos:new(0,0,28)) with{OnGround=-1,Velocity=new(0,0,-100)},100).StopReason!="","24-unit cumulative fall refused");
            });
            Test("landing ground flag still needs support and time bound",()=>
            {
                bool supported=true;var landing=new StepLandingPause((p,v,z)=>new(true,"fixture",p),_=>supported);
                landing.Observe(Pose(),0);landing.Observe(Pose() with{OnGround=-1},50);supported=false;
                Check(landing.Observe(Pose(),100).StopReason!="","unsupported groundflag refused");
                var late=LandingFixture();late.Observe(Pose(),0);late.Observe(Pose() with{OnGround=-1},50);
                Check(late.Observe(Pose(),600).StopReason!="","late ground cannot bypass timeout");
            });
            Test("landing corridor rejects missing floor wall and excessive drop",()=>
            {
                var gap=new WalkGeometry(BspMap.FromBytes(BspFixture.Build(new TestBox(new(-1000,-1000,-1000),new(25,1000,0)))));
                Check(!gap.CheckStepLanding(new(0,0,52),new(250,0,-4),52).Safe,"gap ahead");
                var wall=new WalkGeometry(BspMap.FromBytes(BspFixture.Build(BspFixture.Floor,new(new(40,-100,0),new(45,100,100)))));
                Check(!wall.CheckStepLanding(new(0,0,52),new(130,0,-4),52).Safe,"momentum wall");
                var flat=new WalkGeometry(BspMap.FromBytes(BspFixture.Build(BspFixture.Floor)));
                Check(!flat.CheckStepLanding(new(0,0,60),new(130,0,-4),60).Safe,"24-unit drop");
                Check(!flat.CheckStepLanding(new(0,0,48),new(130,0,-4),60).Safe,"cumulative24 even when12remain");
                Check(flat.CheckStepLanding(new(0,0,52),new(130,0,-4),52).Safe,"16-unit landing corridor clear");
            });
            Test("extended air guard retains death freshness and original default",()=>
            {
                var air=Pose() with{OnGround=-1};var guard=new LiveSampleGuard();
                Check(guard.Observe(air,100,0,true,500)=="","new grace");
                Check(guard.Observe(air with{Time=1.2f},100,200,true,500)=="","fresh air beyond120");
                Check(guard.Observe(air with{Time=1.3f},0,300,true,500).Contains("HP"),"death still stops");
                var stale=new LiveSampleGuard();stale.Observe(air,100,0,true,500);
                Check(stale.Observe(air,100,251,true,500)!="","freshness not extended");
            });
            Test("step landing completion clears state for next grounded segment",()=>
            {
                var landing=LandingFixture();landing.Observe(Pose(),0);landing.Observe(Pose() with{OnGround=-1},50);
                Check(landing.Observe(Pose(),150).Landed,"land once");
                Check(!landing.Observe(Pose(),175).Landed,"no repeated replan event");
                Check(landing.Observe(Pose() with{OnGround=-1},200).Waiting,"next separate step");
            });
            Test("shipped config parses accelerated settings and normal run profile",()=>
            {
                var settings=BotSettings.Load(Path.Combine(AppContext.BaseDirectory,"config.txt"));
                Check(settings.Motion=="run" && settings.LoopMs==15 && settings.MouseNearTurnMaxDeg==6 && settings.MouseSettleMs==40,"shipped values");
                var report=new List<string>();settings.Report(report.Add);Check(report.Count>=50 && report.Any(l=>l=="SETTING Motion=run"),"effective report");
            });
            Test("settings permit comments BOM decimal comma and case insensitive keys",()=>
            {
                var settings=BotSettings.Parse("\uFEFF# test\n motion=RUN ; fast\n mouseFastFraction=0,8\nLoopMs=15\n");
                Check(settings.Motion=="run" && settings.MouseFastFraction==.8 && settings.LoopMs==15,"human format");
            });
            Test("settings reject unknown duplicate malformed and unsafe values",()=>
            {
                foreach(string text in new[]{"Unknown=1","LoopMs=20\nloopms=30","LoopMs=0","LoopMs=12.5","MouseGainMargin=NaN","MouseGainMargin=Infinity","DegreesPerCount=0.0001","Motion=turbo","LandingPauseMs=1000","MouseFirstMaxCounts=99","DisableWatchdog=true","MouseTurnMaxDeg=999","NoEquals","LoopMs="})
                {
                    bool refused=false;try{BotSettings.Parse(text);}catch(Exception e)when(e is ArgumentException or FormatException){refused=true;}
                    Check(refused,"reject "+text);
                }
            });
            Test("settings validate coupled waits angles and radii",()=>
            {
                foreach(string text in new[]{"MouseQuietMs=100\nMouseSettleMs=40","MouseRetryBrakeMs=500\nMouseRetryAfterMs=450","MouseRetryAfterMs=700\nMouseNoResponseMs=700","GoalRadius=6\nWaypointRadius=3","PrecisionToleranceDeg=1\nYawToleranceDeg=0.5","MoveMaxErrorDeg=5\nRunMaxErrorDeg=15","MouseTurnMaxDeg=2\nMouseNearTurnMaxDeg=6","ForecastMinUnits=64\nForecastMaxUnits=64\nRecoveryTimeoutMs=3000\nRecoveryBackoffMs=5000"})
                {
                    bool refused=false;try{BotSettings.Parse(text);}catch(FormatException){refused=true;}Check(refused,"coupled limits");
                }
            });
            Test("config mouse acceleration changes pulse and settle without increasing first probe",()=>
            {
                var settings=BotSettings.Parse("MouseNearTurnMaxDeg=6\nMouseFastFraction=0.8\nMouseSettleMs=40\nMouseQuietMs=20");
                var st=new PulseSteering(.1,true,settings);var initial=st.Tick(0,10,0,true);
                Check(Math.Abs(initial.MouseDx)<=8,"first probe remains small");
                double yaw=-initial.MouseDx*.1;st.Tick(yaw,10-yaw,25,true);
                var calibrated=st.Tick(yaw,10-yaw,150,true);
                Check(Math.Abs(calibrated.MouseDx)>30,"larger calibrated near correction");
                double next=yaw-calibrated.MouseDx*.1;st.Tick(next,10-next,175,true);
                var ready=st.Tick(next,10-next,200,true);Check(ready.Mode!="settling","uses configured settle window");
            });
            Test("steering budget reset preserves pending pulse validation",()=>
            {
                var st=new PulseSteering(.1,true);st.Tick(0,90,0,true);st.BeginSegment();
                st.Tick(-1,91,50,true);var failed=st.Tick(-1,91,150,true);
                Check(failed.StopReason.Contains("sign"),"new target cannot hide wrong-sign pending response");
            });
            Test("pulse budget is now waypoint scoped in actual controller",()=>
            {
                var settings=BotSettings.Parse("MousePulseBudget=40");
                var c=new TravelController(new[]{new ProbeVector(0,100,36.04f),new ProbeVector(0,200,36.04f),new ProbeVector(0,300,36.04f)},Clear,.07106,TravelOptions.Cautious,settings:settings);
                double yaw=0;int packets=0;
                // Artificial waypoint transitions isolate controller bookkeeping, not game physics.
                for(int i=0;i<90;i++)
                {
                    float y=i<30?0:i<60?100:200;
                    var cmd=c.Tick(Pose(1+i*.2f,new(0,y,36.04f),new(0,(float)yaw,0)),i*200,true);
                    Check(cmd.StopReason=="","new segment must not inherit old budget: "+cmd.StopReason);
                    if(cmd.MouseDx!=0){packets++;yaw=TravelController.Normalize(yaw-cmd.MouseDx*.005);}
                }
                Check(packets>40,"whole trip exceeds per-segment budget without disabling it");
            });
            Test("same waypoint pulse budget remains finite and separately recoverable",()=>
            {
                var st=new PulseSteering(.1,true,BotSettings.Parse("MousePulseBudget=40"));double yaw=0;string reason="";
                for(int i=0;i<120;i++)
                {
                    var step=st.Tick(yaw,10,i*200,true);if(step.StopReason!=""){reason=step.StopReason;break;}
                    yaw=PulseSteering.Normalize(yaw-step.MouseDx*.1);
                }
                Check(reason.StartsWith("mouse pulse budget exhausted") && ReplanRecovery.CanRecover(reason),"budget may replan");
                Check(!ReplanRecovery.CanRecover("unstable mouse feedback: repeated reversals (6)"),"real reversal fault remains final");
            });
            Test("configured repeated reversal limit remains distinct from pulse budget",()=>
            {
                var st=new PulseSteering(.1,true,BotSettings.Parse("MouseMaxReversals=3"));double yaw=0;string reason="";int sign=1;
                for(int i=0;i<20;i++)
                {
                    var step=st.Tick(yaw,sign*10,i*200,true);if(step.StopReason!=""){reason=step.StopReason;break;}
                    if(step.MouseDx!=0)sign=-sign;
                    yaw=PulseSteering.Normalize(yaw-step.MouseDx*.1);
                }
                Check(reason.Contains("reversals") && !reason.Contains("budget exhausted"),"specific error");
            });
            Test("run preferred profile avoids shift only on checked heading",()=>
            {
                var c=new TravelController(new[]{new ProbeVector(40,0,36.04f)},Clear,.1,TravelOptions.Parse("run"));
                var cmd=c.Tick(Pose(),0,true);Check(cmd.Forward && !cmd.Walk,"short clear segment run preference");
                var denied=new TravelController(new[]{new ProbeVector(100,0,36.04f)},Clear,.1,TravelOptions.Parse("run"),(p,y,d)=>new(false,"blocked",p));
                Check(!denied.Tick(Pose(),0,true).Forward,"run cannot bypass heading check");
            });
            Test("config movement thresholds and run probe are consumed",()=>
            {
                var settings=BotSettings.Parse("RunMinDistance=160\nRunProbeUnits=48");var probes=new List<double>();
                var c=new TravelController(new[]{new ProbeVector(120,0,36.04f)},Clear,.1,TravelOptions.Balanced,(p,y,d)=>{probes.Add(d);return new(true,"clear",p);},settings);
                Check(c.Tick(Pose(),0,true).Walk,"configured balanced minimum distance");
                var run=new TravelController(new[]{new ProbeVector(120,0,36.04f)},Clear,.1,TravelOptions.RunVerified,(p,y,d)=>{probes.Add(d);return new(true,"clear",p);},settings);
                Check(!run.Tick(Pose(),0,true).Walk && probes.Contains(48),"configured run probe");
            });
            Test("config progress timeout is applied without altering focus stop",()=>
            {
                var c=new TravelController(new[]{new ProbeVector(100,0,36.04f)},Clear,.1,TravelOptions.Balanced,settings:BotSettings.Parse("ProgressTimeoutMs=600"));
                c.Tick(Pose(),0,true);Check(c.Tick(Pose(1.7f),700,true).StopReason.Contains("600ms"),"configured timeout");
                Check(c.Tick(Pose(1.8f),800,false).StopReason.Contains("focus"),"focus remains hard stop");
            });
            Test("config landing pause can tighten but cannot exceed hard bounds",()=>
            {
                var cfg=BotSettings.Parse("LandingPauseMs=200");var landing=new StepLandingPause((p,v,z)=>new(true,"fixture",p),_=>true,cfg);
                landing.Observe(Pose(),0);landing.Observe(Pose() with{OnGround=-1},50);
                Check(landing.Observe(Pose() with{OnGround=-1},251).StopReason.Contains("200ms"),"configured landing bound");
            });
            Test("config recovery stable interval is consumed",()=>
            {
                int calls=0;var recovery=new ReplanRecovery(_=>{calls++;return Task.FromResult<MapRoute?>(RecoveryRoute());},0,BotSettings.Parse("RecoveryStableMs=150"));
                recovery.Begin("stuck: test",0);recovery.Tick(Pose(),0,true);recovery.Tick(Pose(),149,true);Check(calls==0,"wait");
                recovery.Tick(Pose(),150,true);Check(calls==1,"configured stabilization");
            });
            Test("shipped fast settings converge under delayed variable gain feedback",()=>
            {
                var cfg=BotSettings.Load(Path.Combine(AppContext.BaseDirectory,"config.txt"));
                foreach(int delay in new[]{0,100,250})foreach(int profile in new[]{0,1,2,3})
                {
                    var st=new PulseSteering(.07106,true,cfg);double yaw=159;bool aligned=false;var queue=new List<(long At,int Dx)>();
                    for(int i=0;i<1000;i++)
                    {
                        long now=i*25;
                        foreach(var item in queue.Where(v=>v.At<=now).ToArray())
                        {
                            double gain=profile switch{0=>.07106,1=>.246,2=>.5,_=>.08+.001*Math.Abs(item.Dx)};
                            yaw=PulseSteering.Normalize(yaw-item.Dx*gain);queue.Remove(item);
                        }
                        var step=st.Tick(yaw,-yaw,now,Math.Abs(yaw)>cfg.YawToleranceDeg);
                        Check(step.StopReason=="","shipped feedback stop: "+step.StopReason);
                        if(step.MouseDx!=0)queue.Add((now+delay,step.MouseDx));
                        if(!step.Waiting && Math.Abs(yaw)<=cfg.YawToleranceDeg){aligned=true;break;}
                    }
                    Check(aligned,"shipped feedback converges");
                }
            });
            Test("angle normalization wraps across zero",()=>Check(Math.Abs(TravelController.Normalize(359)-(-1))<.001 && Math.Abs(TravelController.Normalize(-359)-1)<.001,"wrap"));
            Test("standing clip hull trace finds floor and wall",()=>
            {
                var map=BspMap.FromBytes(BspFixture.Build(BspFixture.Floor,new(new(40,-100,0),new(45,100,100))));
                Check(map.HullContents(new(0,0,36.04f))==-1,"standing empty");
                Check(map.HullContents(new(0,0,35))==-2,"standing floor collision");
                var floor=map.TraceHull(new(0,0,40),new(0,0,20));
                Check(!floor.Clear && floor.Normal.Z>.99 && Math.Abs(floor.End.Z-36)<.1,"floor trace normal and end");
                Check(!map.TraceHull(new(0,0,36.04f),new(100,0,36.04f)).Clear,"wall between clear endpoints");
            });
            Test("heading forecast rejects wall and unsupported forward gap",()=>
            {
                var wall=new WalkGeometry(BspMap.FromBytes(BspFixture.Build(BspFixture.Floor,new(new(40,-100,0),new(45,100,100)))));
                Check(!wall.PredictHeading(new(0,0,36.04f),0,96).Safe,"wall forecast");
                var gap=new WalkGeometry(BspMap.FromBytes(BspFixture.Build(new TestBox(new(-1000,-1000,-1000),new(40,1000,0)))));
                Check(!gap.PredictHeading(new(0,0,36.04f),0,96).Safe,"gap forecast");
            });
            Test("walk accepts supported flat ground",()=>
            { var w=new WalkGeometry(BspMap.FromBytes(BspFixture.Build(BspFixture.Floor)));Check(w.Check(new(0,0,36.04f),new(100,0,36.04f)).Safe,"flat walk"); });
            Test("walk rejects a corridor narrower than player",()=>
            {
                var w=new WalkGeometry(BspMap.FromBytes(BspFixture.Build(BspFixture.Floor,
                    new(new(-100,12,0),new(200,100,100)),new(new(-100,-100,0),new(200,-12,100)))));
                Check(!w.Check(new(0,0,36.04f),new(100,0,36.04f)).Safe,"24-unit gap vs 32 width");
            });
            Test("walk accepts 12-unit step but rejects 24-unit step",()=>
            {
                foreach(int height in new[]{12,24})
                {
                    var w=new WalkGeometry(BspMap.FromBytes(BspFixture.Build(BspFixture.Floor,new(new(40,-1000,0),new(200,1000,height)))));
                    Check(w.Check(new(0,0,36.04f),new(100,0,36.04f+height)).Safe==(height==12),"step "+height);
                }
            });
            Test("walk accepts short drop but rejects excessive drop",()=>
            {
                foreach(int drop in new[]{12,24})
                {
                    var w=new WalkGeometry(BspMap.FromBytes(BspFixture.Build(
                        new(new(-1000,-1000,-1000),new(40,1000,0)),new(new(40,-1000,-1000),new(1000,1000,-drop)))));
                    Check(w.Check(new(0,0,36.04f),new(100,0,36.04f-drop)).Safe==(drop==12),"drop "+drop);
                }
            });
            Test("walk refuses unsupported gap",()=>
            {
                var w=new WalkGeometry(BspMap.FromBytes(BspFixture.Build(
                    new(new(-1000,-1000,-1000),new(40,1000,0)),new(new(120,-1000,-1000),new(1000,1000,0)))));
                Check(!w.Check(new(0,0,36.04f),new(160,0,36.04f)).Safe,"gap");
            });
            Test("clip hull rejects cycles and invalid indices",()=>
            {
                foreach(short child in new short[]{0,30000})
                {
                    byte[] data=BspFixture.Build(BspFixture.Floor);int off=BitConverter.ToInt32(data,76);
                    BitConverter.GetBytes(child).CopyTo(data,off+4); bool rejected=false;
                    try { BspMap.FromBytes(data); } catch(InvalidDataException) { rejected=true; }
                    Check(rejected,"bad clip child");
                }
            });
            RunV15Tests();
            RunV16Tests();
            RunV17Tests();
            RunV18Tests();
            RunV19Tests();
            RunV20Tests();
            RunV21Tests();
            if(args.Length==2 && args[0]=="--client") {RunV17ClientFileTest(args[1]);RunV19ClientFileTests(args[1]);args=Array.Empty<string>();}
            if(args.Length==2 && args[0]=="--engine") {RunV16EngineFileTest(args[1]);RunV19EngineFileTests(args[1]);args=Array.Empty<string>();}
            if(args.Length!=0)
            {
                if(args.Length!=2 || args[0]!="--bsp") throw new ArgumentException("Tests: [--bsp FILE | --engine HW_DLL | --client CLIENT_DLL]");
                var map=BspMap.Load(args[1]); var graph=NavGraph.Load(Path.Combine(AppContext.BaseDirectory,"de_dust2.graph"));
                var nav=new MapNavigation(graph,map);
                RunV15MapTests(map,graph,args[1]);
                RunV18MapTests(map,graph);
                RunV21MapTests(args[1]);
                Test("actual BSP user-log anchor avoids needless backtracking",()=>
                {
                    var walk=new WalkGeometry(map);var position=new ProbeVector(-816.8281f,-789.4453f,164.03125f);
                    var route=nav.Plan(position,"a","t",walk);
                    Check(route!=null && route.Anchor==918,"forward anchor 918 instead of rear 919");
                    Check(graph.Nodes[route!.Anchor].Origin.X>position.X,"anchor ahead in X for this reported pose");
                });
                Test("actual BSP combined mode permits forward and mouse on checked heading",()=>
                {
                    var walk=new WalkGeometry(map);var start=new ProbeVector(-832,-704,164.03125f);
                    var route=nav.Plan(start,"a","t",walk)!;
                    var c=new TravelController(route.Route.Nodes.Select(id=>graph.Nodes[id].Origin).ToArray(),walk.Check,.07106,TravelOptions.Balanced,walk.PredictHeading);
                    var pose=Pose(1,start,new(0,8,0));double yaw=8;bool simultaneous=false;
                    var queue=new List<(long At,int Dx)>();
                    for(int i=0;i<100;i++)
                    {
                        long now=i*25;
                        foreach(var item in queue.Where(x=>x.At<=now).ToArray()){yaw=TravelController.Normalize(yaw-item.Dx*.125);queue.Remove(item);}
                        pose=pose with{Time=1+i*.025f,Angles=new(0,(float)yaw,0)};
                        var cmd=c.Tick(pose,now,true);Check(cmd.StopReason=="","actual hull control stop: "+cmd.StopReason);
                        if(cmd.MouseDx!=0)queue.Add((now+50,cmd.MouseDx));
                        if(cmd.Forward && cmd.MouseDx!=0){simultaneous=true;break;}
                    }
                    Check(simultaneous,"real map geometry allows combined input near T spawn");
                });
                Test("uploaded wall corner tightens deadband and resumes safe movement",()=>
                {
                    var w=new WalkGeometry(map);var from=new ProbeVector(655.812f,643.250f,36.03125f);var target=new ProbeVector(655.3427f,707.04095f,36.03125f);
                    Check(w.Check(from,target).Safe,"route clear");
                    Check(!w.PredictHeading(from,89.3903,24).Safe && w.PredictHeading(from,90.4219,24).Safe,"reproduce deadband collision");
                    var c=new TravelController(new[]{target},w.Check,.112217,TravelOptions.Balanced,w.PredictHeading);
                    double yaw=89.3903;bool moved=false;var queue=new List<(long At,int Dx)>();
                    for(int i=0;i<40;i++)
                    {
                        long now=i*25;
                        foreach(var item in queue.Where(v=>v.At<=now).ToArray()){yaw=TravelController.Normalize(yaw-item.Dx*.112217);queue.Remove(item);}
                        var cmd=c.Tick(Pose(1+i*.025f,from,new(0,(float)yaw,0)),now,true);
                        Check(cmd.StopReason=="","corner stop: "+cmd.StopReason);
                        if(i==0)Check(cmd.MouseDx<0 && !cmd.Forward && cmd.Mode.Contains("precision"),"fine correction, not idle brake");
                        if(cmd.MouseDx!=0)queue.Add((now+50,cmd.MouseDx));
                        if(cmd.Forward){Check(w.PredictHeading(from,yaw,24).Safe,"safe actual heading");moved=true;break;}
                    }
                    Check(moved,"resumed within one second without disabling geometry");
                });
                Test("actual BSP replans safely from last logged pre-stop position",()=>
                {
                    var position=new ProbeVector(56.519f,-540.630f,36.03125f);var w=new WalkGeometry(map);
                    var route=nav.Plan(position,"a","t",w);
                    Check(route!=null,"checked alternate attachment available from last logged pose");
                    var at=position;
                    foreach(int id in route!.Route.Nodes){var to=graph.Nodes[id].Origin;Check(w.Check(at,to).Safe,"replan segment "+id);at=to;}
                    Console.WriteLine($"REPLAN BSP regression: last known pose, anchor={route.Anchor}, nodes={route.Route.Nodes.Count}. Not final unlogged stop pose / not a live walk.");
                });
                Test("actual logged 16-unit step descent pauses then permits grounded replan",()=>
                {
                    var w=new WalkGeometry(map);var landing=new StepLandingPause(w.CheckStepLanding,p=>w.Supported(p,out _));
                    var guard=new LiveSampleGuard();
                    var ground=Pose(pos:new(177.602f,-35.122f,52.03125f));
                    Check(!landing.Observe(ground,0).Waiting && guard.Observe(ground,100,0)=="","verified previous ground");
                    var origin=new ProbeVector(177.634f,-31.223f,52.03125f);
                    Check(w.SnapToFloor(origin,18.1f,out var floor) && Math.Abs(origin.Z-floor.Z-16)<.1,"actual 16-unit floor, not 8-unit grace");
                    for(int i=0;i<4;i++)
                    {
                        float t=i*.05f;
                        var pose=Pose(1.05f+t,new(origin.X+.919f*t,origin.Y+130*t,origin.Z-4*t-400*t*t)) with{OnGround=-1,Velocity=new(.919f,130,-4-800*t)};
                        var state=landing.Observe(pose,50+i*50);
                        Check(state.Waiting && state.StopReason=="","checked falling frame "+i+": "+state.StopReason);
                        Check(guard.Observe(pose,100,50+i*50,true,500)=="","guard keeps freshness/HP checks while allowing passive landing");
                    }
                    var landed=Pose(1.25f,new(origin.X+.18f,origin.Y+26,36.04f));
                    var result=landing.Observe(landed,250);
                    Check(result.Landed && !result.Waiting && result.StopReason=="","grounded finish");
                    Check(guard.Observe(landed,100,250)=="","guard grounded again");
                    var route=nav.Plan(landed.Origin,"a","t",w);Check(route!=null,"grounded route after landing");
                });
                Test("actual BSP standing hull and floor at T spawn",()=>
                {
                    var walk=new WalkGeometry(map);var p=new ProbeVector(-832,-704,164.031f);
                    Check(map.HasClipHulls && walk.SolidModels.Count==11,"world and 10 breakables");
                    Check(walk.Supported(p,out _),"T spawn support");
                    Check(walk.Check(p,graph.Nodes[896].Origin).Safe,"spawn attachment standing hull");
                });
                Test("actual BSP walking routes to both sites pass standing checks",()=>
                {
                    var walk=new WalkGeometry(map); var p=new ProbeVector(-832,-704,164.031f);
                    foreach(string site in new[]{"a","b"})
                    {
                        var route=nav.Plan(p,site,"t",walk);Check(route!=null,"walk route "+site);
                        var at=p;
                        foreach(int id in route!.Route.Nodes)
                        { var target=graph.Nodes[id].Origin;Check(walk.Check(at,target).Safe,"standing edge to "+id);at=target; }
                    }
                });
                Test("actual BSP fingerprint matches user map",()=> Check(map.MatchesSuppliedDust2 && map.FileSize==2057288,"sha256,size"));
                Test("actual BSP all graph node centers in empty world",()=> Check(nav.NonEmptyNodes==0,"1238 empty"));
                Test("actual BSP four known directed edges blocked",()=> Check(nav.BlockedEdges.SetEquals(new[]{(566,557),(621,713),(892,504),(1133,1136)}),"four edges"));
                Test("actual BSP two labeled zones and 40 spawns",()=>
                {
                    var zones=map.BombZones();
                    Check(zones.Count==2 && zones.Select(z=>z.Label).OrderBy(x=>x).SequenceEqual(new[]{"a","b"}),"A,B");
                    Check(nav.GoalNodes(zones.Single(z=>z.Label=="a")).Count==9 && nav.GoalNodes(zones.Single(z=>z.Label=="b")).Count==10,"zone goals");
                    Check(map.Entities.Count(e=>e.GetValueOrDefault("classname")=="info_player_start")==20 &&
                        map.Entities.Count(e=>e.GetValueOrDefault("classname")=="info_player_deathmatch")==20,"spawn entities");
                });
                Test("actual BSP T and CT routes to both sites follow clear graph edges",()=>
                {
                    foreach(var (position,team) in new[]{(new ProbeVector(-832,-704,164.031f),"t"),(new ProbeVector(448,2464,-91.969f),"ct")})
                    foreach(string site in new[]{"a","b"})
                    {
                        var plan=nav.Plan(position,site,team); Check(plan!=null,"route exists "+team+site);
                        for(int i=1;i<plan!.Route.Nodes.Count;i++)
                        {
                            int from=plan.Route.Nodes[i-1], to=plan.Route.Nodes[i];
                            Check(graph.Nodes[from].Links.Any(e=>e.To==to) && !nav.BlockedEdges.Contains((from,to)),"existing clear edge");
                        }
                    }
                });
            }
            Console.WriteLine($"{_passed} tests passed. Offline/synthetic tests only; no live-game verification.");
            return 0;
        }
        catch (Exception ex) { Console.Error.WriteLine(ex); return 1; }
    }
}

internal sealed class FakeMemory : IGameMemory
{
    public const uint Client = 0x0F8A0000;
    public Dictionary<string, uint> Modules { get; } = new(StringComparer.OrdinalIgnoreCase)
        { ["client.dll"] = Client, ["hw.dll"] = 0x04930000 };
    public Dictionary<string, uint> ModuleSizes { get; } = new(StringComparer.OrdinalIgnoreCase)
        { ["client.dll"] = 0x15B000, ["hw.dll"] = 0x1229A8E };
    public Dictionary<uint, int> Ints { get; } = new()
    {
        [Client + GameOffsets.ClientHealthDirectRva] = 100,
        [Client + GameOffsets.ClientMoneyDirectRva] = 800,
        [Client + GameOffsets.ClientArmorDirectRva] = 0
    };
    public Dictionary<uint, byte[]> ByteBlocks { get; } = new();
    public Dictionary<uint, uint> UInts { get; } = new();
    public int LastReadError { get; private set; }
    public nuint LastBytesRead { get; private set; }
    public int VecReads { get; private set; }
    public (float X, float Y, float Z) Xyz { get; set; } = (0, 0, 0);
    public void RefreshModules() { }
    public Action<uint>? BeforeBytes {get;set;}
    public Action<uint>? BeforeInt {get;set;}
    public bool AllowPrefixReads {get;set;}
    public bool ReadBytes(uint address, byte[] buffer)
    {
        BeforeBytes?.Invoke(address);
        if (ByteBlocks.TryGetValue(address, out var data) && (data.Length == buffer.Length || AllowPrefixReads && data.Length >= buffer.Length))
        {
            data.AsSpan(0,buffer.Length).CopyTo(buffer); LastReadError = 0; LastBytesRead = (nuint)buffer.Length;
            return true;
        }
        LastReadError = 299; LastBytesRead = 0;
        return false;
    }
    public bool ReadInt32(uint address, out int value)
    {
        BeforeInt?.Invoke(address);
        bool ok = Ints.TryGetValue(address, out value);
        LastReadError = ok ? 0 : 299; LastBytesRead = ok ? (nuint)4 : 0;
        return ok;
    }
    public bool ReadUInt32(uint address, out uint value)
    {
        bool ok = UInts.TryGetValue(address, out value);
        LastReadError = ok ? 0 : 299; LastBytesRead = ok ? (nuint)4 : 0;
        return ok;
    }
    public bool ReadVec3(uint address, out float x, out float y, out float z)
    {
        CheckAddress(address);
        VecReads++; (x, y, z) = Xyz;
        LastReadError = 0; LastBytesRead = 12;
        return true;
    }
    private static void CheckAddress(uint address)
    {
        if (address != 0x04930000 + GameOffsets.HwRawXyzRva)
            throw new Exception("Unexpected raw XYZ address: a fallback must not be used");
    }
}
