namespace CSBot;
internal sealed class FakeControlBackend : IControlBackend
{
    public bool Focused {get;set;}=true;
    public bool StopPressed {get;set;}
    public bool UserBusy {get;set;}
    public long Now {get;set;}
    public bool DownFails {get;set;}
    public List<bool> KeyEvents {get;}=new();
    public List<byte> Taps {get;}=new();
    public void Tap(byte scan)=>Taps.Add(scan);
    public List<int> MouseEvents {get;}=new();
    public List<bool> WalkModes {get;}=new();
    public void Keys(bool down,bool walk=true) {KeyEvents.Add(down);if(down)WalkModes.Add(walk);if(down && DownFails) throw new InvalidOperationException("simulated partial input failure");}
    public bool ObjectiveFails {get;set;}
    public List<(bool Attack,bool Use,bool Select)> ObjectiveEvents {get;}=new();
    public List<(int X,int Y)> Axes {get;}=new();
    public void ObjectiveKeys(bool attack,bool use,bool selectC4)
    {ObjectiveEvents.Add((attack,use,selectC4));if(ObjectiveFails && (attack || use || selectC4))throw new InvalidOperationException("partial objective failure");}
    public void MouseAxes(int dx,int dy){Axes.Add((dx,dy));if(dx!=0)Mouse(dx);}
    public void Mouse(int dx)=>MouseEvents.Add(dx);
}
