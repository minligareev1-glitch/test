using System.Diagnostics;
namespace CSBot;
internal static partial class ReaderTests
{
    private static void RunV18Tests()
    {
        Test("v18 alive without a death does not impose respawn wait",()=>Check(!new RespawnLifecycle(new()).Observe(MissionPose(),100,0).Waiting,"alive"));
        Test("v18 death releases into indefinite wait rather than exit",()=>
        {var l=new RespawnLifecycle(new());Check(l.Observe(MissionPose(),0,0).Entered,"enter");Check(l.Observe(MissionPose(),0,100000).Waiting,"no expiry");Check(!l.Observe(MissionPose(),0,100025).Entered,"one transition");});
        Test("v18 each death and spectator flag independently waits",()=>
        {foreach(var p in new[]{MissionPose() with{Dead=1},MissionPose() with{DeadFlag=1},MissionPose() with{Spectator=1}})Check(new RespawnLifecycle(new()).Observe(p,100,0).Waiting,"flag");});
        Test("v18 respawn requires warmup and three advancing frames",()=>
        {var l=new RespawnLifecycle(new());l.Observe(MissionPose(),0,0);for(int n=0;n<6;n++)Check(l.Observe(MissionPose() with{Time=2+n*.025f},100,25+n*25).Waiting,"warmup");Check(l.Observe(MissionPose() with{Time=2.15f},100,175).Resumed,"resume");Check(!l.Observe(MissionPose() with{Time=3},100,200).Waiting,"normal");});
        Test("v18 frozen respawn time never resumes",()=>
        {var l=new RespawnLifecycle(new());l.Observe(MissionPose(),0,0);for(int n=1;n<60;n++)Check(l.Observe(MissionPose(),100,n*25).Waiting,"stale");});
        Test("v18 respawn sampling gap restarts warmup",()=>
        {var l=new RespawnLifecycle(new());l.Observe(MissionPose(),0,0);for(int n=0;n<4;n++)l.Observe(MissionPose() with{Time=2+n*.025f},100,25+n*25);Check(l.Observe(MissionPose() with{Time=3},100,1000).Waiting,"gap");Check(l.Observe(MissionPose() with{Time=3.025f},100,1025).Waiting,"still warmup");});
        Test("v18 invalid respawn samples reset warmup",()=>
        {foreach(var bad in new[]{MissionPose() with{OnGround=-1},MissionPose() with{Flags=1<<12},MissionPose() with{Server=1},MissionPose() with{Angles=new(float.NaN,0,0)},MissionPose() with{FrameTime=0}}){var l=new RespawnLifecycle(new());l.Observe(MissionPose(),0,0);Check(l.Observe(bad,100,25).Waiting,"invalid");Check(l.Observe(MissionPose() with{Time=2},100,50).Waiting,"restarts");}});
        Test("v18 respawn pointer and teleport reset warmup",()=>
        {foreach(var p in new[]{MissionPose() with{Pointer=0x30000000},MissionPose() with{Origin=new(1000,0,36)}}){var l=new RespawnLifecycle(new());l.Observe(MissionPose(),0,0);for(int n=0;n<5;n++)l.Observe(MissionPose() with{Time=2+n*.025f},100,25+n*25);Check(l.Observe(p with{Time=4},100,200).Waiting,"changed");}});
        Test("v18 second death can resume again",()=>
        {var l=new RespawnLifecycle(new());for(int round=0;round<2;round++){long start=round*1000;l.Observe(MissionPose(),0,start);RespawnStep step=new(true);for(int n=0;n<=6;n++)step=l.Observe(MissionPose() with{Time=2+n*.025f},100,start+25+n*25);Check(step.Resumed,"round");}});
        Test("v18 neutral death input retains authorization but releases all owned keys",()=>
        {var b=new FakeControlBackend();using var i=new WindowsControl(b,false);i.Arm();i.Apply(new(true,0,false,"",0,Attack:true));i.Apply(new(false,0,false,"",-1));Check(b.KeyEvents.SequenceEqual(new[]{true,false}) && b.ObjectiveEvents.Last()==(false,false,false),"release");i.Apply(new(true,0,false,"",0));Check(b.KeyEvents.Last(),"authorized resume without another Arm");});
        Test("v18 focus fault still prevents automatic resume",()=>
        {var b=new FakeControlBackend();using var i=new WindowsControl(b,false);i.Arm();i.Apply(new(false,0,false,"",-1));b.Focused=false;bool rejected=false;try{i.Apply(new(true,0,false,"",0));}catch(InvalidOperationException){rejected=true;}Check(rejected || !b.KeyEvents.LastOrDefault(),"no keys to other window");});
        Test("v18 late plan rejected after death even for same map and site",()=>Check(!PlanAcceptance.Current(1,2,"dust/site","dust/site",default,default),"epoch"));
        Test("v18 late plan rejected for context or large pose changes",()=>
        {Check(!PlanAcceptance.Current(1,1,"T","CT",default,default),"team");Check(!PlanAcceptance.Current(1,1,"T","T",default,new(65,0,0)),"pose");Check(PlanAcceptance.Current(1,1,"T","T",default,new(32,0,0)),"braking tolerated");});
        Test("v18 reverse field follows directed links and closest weighted goal",()=>
        {var s=new FastRouteSearch(5,new[]{new RouteEdge(0,1,1),new(1,2,2),new(1,3,1),new(3,4,1)});var f=s.Compute(new[]{(2,0d),(4,4d)},_=>true);Check(f.Path(0)!.SequenceEqual(new[]{0,1,2}) && f.Distance[0]==3,"weighted");Check(f.Path(4)!.SequenceEqual(new[]{4}),"seed");Check(new FastRouteSearch(3,new[]{new RouteEdge(0,1,1),new(1,2,1)}).Compute(new[]{(0,0d)},_=>true).Path(2)==null,"no reversed travel");});
        Test("v18 reverse field enforces team exclusions and temporary penalty",()=>
        {var s=new FastRouteSearch(4,new[]{new RouteEdge(0,1,1),new(1,3,1),new(0,2,3),new(2,3,1)});Check(s.Compute(new[]{(3,0d)},id=>id!=1).Path(0)!.SequenceEqual(new[]{0,2,3}),"allowed");Check(s.Compute(new[]{(3,0d)},_=>true,id=>id==1?10:0).Path(0)!.SequenceEqual(new[]{0,2,3}),"penalty");});
        Test("v18 reverse field rejects negative and nonfinite costs",()=>
        {foreach(double cost in new[]{-1d,0d,double.NaN,double.PositiveInfinity}){bool rejected=false;try{_=new FastRouteSearch(2,new[]{new RouteEdge(0,1,cost)});}catch(ArgumentException){rejected=true;}Check(rejected,"bad edge");}});
        Test("v18 reverse field observes cancellation",()=>
        {using var c=new CancellationTokenSource();c.Cancel();bool canceled=false;try{new FastRouteSearch(2,new[]{new RouteEdge(0,1,1)}).Compute(new[]{(1,0d)},_=>true,token:c.Token);}catch(OperationCanceledException){canceled=true;}Check(canceled,"cancel");});
        Test("v18 farthest shortcut uses hull check rather than straight-line proximity",()=>
        {var points=new[]{new ProbeVector(40,0,36),new(100,0,36),new(200,0,36),new(300,0,36)};int calls=0;WalkCheck CheckLine(ProbeVector a,ProbeVector b){calls++;return new(b.X<=200,"fixture wall",b);}Check(RouteLookahead.Select(points,new(0,0,36),0,384,24,CheckLine)==2 && calls==2,"skip far blocked");calls=0;Check(RouteLookahead.Select(points,default,0,384,24,CheckLine,1)==0 && calls==1,"budget");});
        Test("v18 path simplifier preserves goal and cannot cross a gap",()=>
        {var points=new[]{new ProbeVector(40,0,36),new(80,0,36),new(120,0,36),new(160,0,36)};WalkCheck Segment(ProbeVector a,ProbeVector b)=>new(NavGraph.Distance(a,b)<=85,"gap",b);var r=RouteLookahead.Simplify(new(0,0,36),points,new(),Segment,default);Check(r.SequenceEqual(new[]{points[1],points[3]}),"two safe segments");});
        Test("v18 path simplifier refuses unsafe original segment",()=>
        {bool rejected=false;try{RouteLookahead.Simplify(default,new[]{new ProbeVector(30,0,36)},new(),(a,b)=>new(false,"wall",a),default);}catch(InvalidDataException){rejected=true;}Check(rejected,"no unchecked fallback");});
        Test("v18 adaptive controller selects farther visible node",()=>
        {var points=new[]{new ProbeVector(50,0,36),new(100,0,36),new(250,0,36)};var c=new TravelController(points,(a,b)=>new(true,"clear",b),.1,TravelOptions.Balanced,settings:new(),adaptiveLookahead:true);var cmd=c.Tick(MissionPose(),0,true);Check(cmd.TargetIndex==2,"far target");});
        Test("v18 planted T navigates without attack and off preserves old stop",()=>
        {var w=World(planted:true);var s=new BotSettings();var a=new BombObjectives(.1,s).Tick(w,MissionPose(),0,true,true);Check(a.Navigate && a.Command?.Attack!=true,"cover");s.PostPlantMode="off";Check(!new BombObjectives(.1,s).Tick(w,MissionPose(),0,true,true).Navigate,"off");});
        Test("v18 cover holds once then relocates without extending deadline",()=>
        {var p=new PostPlantCoordinator();var s=new BotSettings();var w=World(planted:true);p.Observe(w,0,s);p.Arrived("post-plant-cover",new(200,0,36),100,s);p.Arrived("post-plant-cover",new(200,0,36),4000,s);p.Observe(w,5099,s);Check(p.Holding && p.Revision==0,"hold");p.Observe(w,5100,s);Check(!p.Holding && p.Revision==1 && p.Previous.HasValue,"relocate");});
        Test("v18 patrol immediately rotates while clear HUD resets cover context",()=>
        {var p=new PostPlantCoordinator();var s=new BotSettings();var w=World(planted:true);p.Observe(w,0,s);p.Arrived("post-plant-patrol",new(200,0,36),100,s);p.Observe(w,115,s);Check(p.Revision==1 && !p.Holding,"patrol");p.Observe(w with{BombPlanted=false},130,s);Check(p.Revision==0 && p.Previous==null,"clear");Check(!PostPlantCoordinator.Active(w with{Team=2},s),"CT not cover");});
        Test("v18 config accepts new tuning and rejects incoherent radii",()=>
        {var s=BotSettings.Parse("AutoRetryMs=0\nNavAttachRadius=512\nPostPlantMode=patrol\nRespawnWarmupMs=200");Check(s.NavAttachRadius==512 && s.AutoReplanStableMs==0 && s.PostPlantMode=="patrol","parse");foreach(string text in new[]{"PostPlantMode=aggressive","PostPlantMinDistance=512\nPostPlantMaxDistance=128","NavAttachRadius=128\nNavPreferredAdvance=256","RespawnWarmupMs=0"}){bool rejected=false;try{BotSettings.Parse(text);}catch(FormatException){rejected=true;}Check(rejected,"bad setting");}});
    }
    private static void RunV18MapTests(BspMap map,NavGraph graph)
    {
        var loaded=new LoadedMap("de_dust2",map,graph,new WalkGeometry(map),new MapNavigation(graph,map));FastNavigator? fast=null;
        Test("v18 BSP builds immutable checked directed graph once",()=>
        {fast=new FastNavigator(loaded);Check(fast.Edges>100,"walk edges");Console.WriteLine($"BENCH v18 cold walk cache {fast.BuildMs:F1} ms; {fast.Edges} directed standing edges; offline only");});
        void SafeRoute(ProbeVector origin,MissionRoute? route,string kind)
        {Check(route!=null && route.Kind==kind && route.Targets.Count>0,"route "+kind);var at=origin;foreach(var t in route!.Targets){Check(loaded.Walk.Check(at,t).Safe,"standing segment "+t);at=t;}Check(route.Targets.Count<=route.RawTargets,"compressed");Console.WriteLine($"BENCH {kind}: {route.ComputeMs:F2} ms, raw={route.RawTargets}, targets={route.Targets.Count}, attach={route.AttachDistance:F1}; offline only");}
        Test("v18 BSP T and CT route both sites from actual spawn areas",()=>
        {foreach(int team in new[]{1,2})foreach(string site in new[]{"a","b"}){var start=team==1?new ProbeVector(-832,-704,164.03125f):new ProbeVector(448,2464,-91.969f);var r=fast!.Plan(World(team),start,team==1?0:-90,new(){ObjectiveSite=site});SafeRoute(start,r,"site-approach");Check(map.InsideZone(r!.Targets[^1],MissionPlanner.Site(loaded,site)),"goal site");}});
        Test("v18 BSP compressed routes never cut user reported wall corner",()=>
        {var start=new ProbeVector(655.812f,643.250f,36.03125f);SafeRoute(start,fast!.Plan(World(),start,90,new()),"site-approach");});
        Test("v18 BSP CT attaches to actual planted bomb and checks final approach",()=>
        {var node=graph.Nodes.First(n=>map.InsideZone(n.Origin,MissionPlanner.Site(loaded,"a")) && loaded.Walk.Supported(n.Origin,out _));var bomb=new ProbeVector(node.Origin.X,node.Origin.Y,node.Origin.Z-36);var start=new ProbeVector(448,2464,-91.969f);var r=fast!.Plan(World(2,planted:true,bomb:bomb),start,-90,new());SafeRoute(start,r,"defuse-approach");Check(NavGraph.Distance(r!.Targets[^1],bomb)<=60,"use range");});
        Test("v18 BSP post-plant cover and patrol use reachable annulus nodes",()=>
        {var start=graph.Nodes.First(n=>map.InsideZone(n.Origin,MissionPlanner.Site(loaded,"a")) && loaded.Walk.Supported(n.Origin,out _)).Origin;var bomb=new ProbeVector(start.X,start.Y,start.Z-36);foreach(string mode in new[]{"cover","patrol"}){var s=new BotSettings{PostPlantMode=mode};var r=fast!.Plan(World(planted:true,bomb:bomb),start,0,s);Check(r!=null && (r.Kind=="post-plant-cover" || r.Kind=="post-plant-patrol"),"post route");SafeRoute(start,r,r!.Kind);double distance=NavGraph.Distance(r.Targets[^1],bomb);Check(distance>=s.PostPlantMinDistance && distance<=s.PostPlantMaxDistance,"annulus");var next=fast.Plan(World(planted:true,bomb:bomb),r.Targets[^1],0,s,previous:r.Targets[^1]);Check(next!=null && NavGraph.Distance(next.Targets[^1],r.Targets[^1])>=s.PostPlantRelocateDistance,"new checked destination");SafeRoute(r.Targets[^1],next,next!.Kind);}});
        Test("v18 BSP cached repeat plan uses same graph and yields safe route",()=>
        {var start=new ProbeVector(-832,-704,164.03125f);var timer=Stopwatch.StartNew();for(int i=0;i<3;i++)SafeRoute(start,fast!.Plan(World(),start,0,new()),"site-approach");Console.WriteLine($"BENCH v18 repeat mean {timer.Elapsed.TotalMilliseconds/3:F2} ms (includes independent segment validation); offline CPU only");});
    }
}
