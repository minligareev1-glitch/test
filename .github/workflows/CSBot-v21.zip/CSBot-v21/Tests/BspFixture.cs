namespace CSBot;

internal readonly record struct TestBox(ProbeVector Min,ProbeVector Max);
internal static class BspFixture
{
    // Synthetic brush union with a pre-expanded standing hull (16,16,36).
    // Independent of Valve map assets. World render tree deliberately empty: tests target clip hulls.
    public static byte[] Build(params TestBox[] boxes)
    {
        int count=boxes.Length*6;
        var parts=new Dictionary<int,byte[]> {
            [0]=System.Text.Encoding.ASCII.GetBytes("{\"classname\" \"worldspawn\"}\0"),
            [1]=new byte[count*20],[5]=new byte[24],[9]=new byte[count*8],[10]=new byte[28],[14]=new byte[64] };
        void I(byte[] b,int o,int v)=>BitConverter.GetBytes(v).CopyTo(b,o);
        void S(byte[] b,int o,short v)=>BitConverter.GetBytes(v).CopyTo(b,o);
        void F(byte[] b,int o,float v)=>BitConverter.GetBytes(v).CopyTo(b,o);
        for(int box=0;box<boxes.Length;box++)
        {
            var bounds=boxes[box];
            float[] min={bounds.Min.X-16,bounds.Min.Y-16,bounds.Min.Z-36};
            float[] max={bounds.Max.X+16,bounds.Max.Y+16,bounds.Max.Z+36};
            for(int side=0;side<6;side++)
            {
                int index=box*6+side,axis=side/2; bool reverse=(side%2)==1;
                F(parts[1],index*20+axis*4,reverse?-1:1);
                F(parts[1],index*20+12,reverse?-max[axis]:min[axis]);
                I(parts[1],index*20+16,axis);
                I(parts[9],index*8,index);
                S(parts[9],index*8+4,side==5?(short)-2:(short)(index+1));
                S(parts[9],index*8+6,box==boxes.Length-1?(short)-1:(short)((box+1)*6));
            }
        }
        S(parts[5],4,-1);S(parts[5],6,-1); I(parts[10],0,-1);
        for(int axis=0;axis<3;axis++) { F(parts[14],axis*4,-4096); F(parts[14],12+axis*4,4096); }
        I(parts[14],36,0); I(parts[14],40,0); I(parts[14],44,0); I(parts[14],48,0);
        var data=new byte[124+parts.Values.Sum(p=>p.Length)];I(data,0,30);int cursor=124;
        foreach(var part in parts) { I(data,4+8*part.Key,cursor);I(data,8+8*part.Key,part.Value.Length);part.Value.CopyTo(data,cursor);cursor+=part.Value.Length; }
        return data;
    }
    public static TestBox Floor=>new(new(-1000,-1000,-1000),new(1000,1000,0));
}
