using System.Text;
namespace CSBot;
internal static partial class ReaderTests
{
    private static byte[] TeamText(string text){var data=new byte[16];Encoding.ASCII.GetBytes(text).CopyTo(data,0);return data;}
    private static void RunV17Tests()
    {
        Test("v17 regression legacy getter zero but TeamInfo T",()=>
        {var m=ProfileMemory();m.ByteBlocks[FakeMemory.Client+WorldStateReader.LegacyTeamArray+104]=BitConverter.GetBytes((short)0);Check(new WorldStateReader(m).TryRead(0,out var w,out var e),e);Check(w.Team==1 && w.LegacyTeam==0 && w.TeamName=="TERRORIST" && w.TeamSource=="TeamInfo" && w.LocalEntityIndex==1,"active TeamInfo instead of zero legacy");});
        Test("v17 CT comes from explicit TeamInfo not absence of C4",()=>
        {var m=WorldMemory(2,c4:false);Check(new WorldStateReader(m).TryRead(0,out var w,out var e),e);Check(w.Team==2 && w.TeamName=="CT" && !w.HasC4,"CT explicit");m=WorldMemory(1,c4:false);Check(new WorldStateReader(m).TryRead(0,out w,out e) && w.Team==1,e);});
        Test("v17 legacy conflicting team never overrides active TeamInfo",()=>
        {var m=WorldMemory(2);m.ByteBlocks[FakeMemory.Client+WorldStateReader.LegacyTeamArray+104]=BitConverter.GetBytes((short)1);Check(new WorldStateReader(m).TryRead(0,out var w,out var e) && w.Team==2 && w.LegacyTeam==1,e);});
        Test("v17 empty or spectator team stays unknown even carrying C4",()=>
        {foreach(string text in new[]{"","SPECTATOR","UNASSIGNED"}){var m=WorldMemory(0,c4:true);m.ByteBlocks[FakeMemory.Client+WorldStateReader.TeamArray+106]=TeamText(text);Check(new WorldStateReader(m).TryRead(0,out var w,out var e) && w.Team==0 && w.HasC4,e);}});
        Test("v17 number and name disagreement never guesses",()=>
        {foreach(var (team,text) in new[]{(1,"CT"),(2,"TERRORIST"),(0,"CT"),(1,"")}){var m=WorldMemory(team);m.ByteBlocks[FakeMemory.Client+WorldStateReader.TeamArray+106]=TeamText(text);Check(!new WorldStateReader(m).TryRead(0,out _,out var e) && e.Contains("disagree"),e);}});
        Test("v17 no fallback to adjacent nonempty row",()=>
        {var m=WorldMemory(0);m.ByteBlocks[FakeMemory.Client+WorldStateReader.TeamArray+208]=BitConverter.GetBytes((short)1);m.ByteBlocks[FakeMemory.Client+WorldStateReader.TeamArray+210]=TeamText("TERRORIST");Check(new WorldStateReader(m).TryRead(0,out var w,out var e) && w.Team==0 && w.LocalEntityIndex==1,e);});
        Test("v17 highest movement index attaches exactly to entity32",()=>
        {var m=WorldMemory(0);uint at=FakeMemory.Client+WorldStateReader.TeamArray+32*104;m.ByteBlocks[at]=BitConverter.GetBytes((short)2);m.ByteBlocks[at+2]=TeamText("CT");Check(new WorldStateReader(m).TryRead(31,out var w,out var e) && w.LocalEntityIndex==32 && w.Team==2,e);});
        Test("v17 full TeamInfo signature covers address comparisons and writes",()=>
        {foreach(int at in new[]{0,16,33,49,53,60,62,78,82,90,93}){var m=WorldMemory();m.ByteBlocks[FakeMemory.Client+WorldStateReader.TeamInfoCodeRva][at]^=1;Check(!new WorldStateReader(m).TryRead(0,out _,out var e) && e.Contains("TeamInfo handler signature"),e);}});
        Test("v17 team name mutation during snapshot is rejected",()=>
        {var m=WorldMemory();uint at=FakeMemory.Client+WorldStateReader.TeamArray+106;int reads=0;m.BeforeBytes=a=>{if(a==at && ++reads==2)m.ByteBlocks[at]=TeamText("CT");};Check(!new WorldStateReader(m).TryRead(0,out _,out var e) && e.Contains("changed during snapshot"),e);});
        Test("v17 malformed or unavailable team name refused",()=>
        {foreach(int kind in new[]{0,1,2}){var m=WorldMemory();uint at=FakeMemory.Client+WorldStateReader.TeamArray+106;if(kind==0)m.ByteBlocks.Remove(at);else if(kind==1)m.ByteBlocks[at]=Enumerable.Repeat((byte)'T',16).ToArray();else m.ByteBlocks[at][0]=10;Check(!new WorldStateReader(m).TryRead(0,out _,out _),"name must be readable terminated printable");}});
        Test("v17 unknown legacy read does not invalidate active team",()=>
        {var m=WorldMemory();m.ByteBlocks.Remove(FakeMemory.Client+WorldStateReader.LegacyTeamArray+104);Check(new WorldStateReader(m).TryRead(0,out var w,out var e) && w.Team==1 && w.LegacyTeam==-1,e);});
        Test("v17 matched TeamInfo gives T plant and CT defuse branch",()=>
        {foreach(int team in new[]{1,2}){var m=WorldMemory(team,c4:true,planted:team==2);Check(new WorldStateReader(m).TryRead(0,out var w,out var e),e);var f=new BombObjectives(.071,new());var a=f.Tick(w,MissionPose(),0,true,true);Check(team==1?a.Command?.Attack==true:a.Mode.StartsWith("defuse",StringComparison.Ordinal) && a.Command?.Attack!=true,"actual TeamInfo selects action without manual team");}});
    }
    private static void RunV17ClientFileTest(string path)
    {
        Test("v17 TeamInfo profile matches actual supplied client PE",()=>
        {
            byte[] file=File.ReadAllBytes(path);Check(Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(file)).Equals("b474ecfbb6f2fc6c4aa48fceb0b5735dfe2cb23ce06ba0a1008137cd228c714a",StringComparison.OrdinalIgnoreCase),"supplied client fingerprint");
            int pe=BitConverter.ToInt32(file,0x3c),sections=BitConverter.ToUInt16(file,pe+6),optional=pe+24,headers=optional+BitConverter.ToUInt16(file,pe+20);uint image=BitConverter.ToUInt32(file,optional+28);
            byte[] ReadRva(uint target,int length){for(int i=0;i<sections;i++){int at=headers+i*40;uint rva=BitConverter.ToUInt32(file,at+12),size=BitConverter.ToUInt32(file,at+16);if(target>=rva && target+(uint)length<=rva+size){int offset=checked((int)(BitConverter.ToUInt32(file,at+20)+target-rva));return file.AsSpan(offset,length).ToArray();}}throw new Exception("RVA unmapped");}
            var expected=WorldStateReader.TeamInfoSignature(image);var actual=ReadRva(WorldStateReader.TeamInfoCodeRva,expected.Length);Check(actual.SequenceEqual(expected),"actual TeamInfo code");
            Check(ReadRva(0xE4128,3).SequenceEqual(Encoding.ASCII.GetBytes("CT\0")) && ReadRva(0xE411C,10).SequenceEqual(Encoding.ASCII.GetBytes("TERRORIST\0")),"compared team literals");
            Check(BitConverter.ToUInt32(ReadRva(0xC9D3C,4))==image+0x290A0,"TeamInfo virtual method slot");
            Check(ReadRva(0x45350,28).SequenceEqual(WorldStateReader.TeamSignature(image)),"legacy getter really points to old field");
            foreach(var (at,rva) in new (int,uint)[]{(16,0x12B31C),(33,0xE4128),(53,0x12B31A),(62,0xE411C),(82,0x12B31A),(93,0x12B31A)})
                Check(BitConverter.ToUInt32(actual,at)==image+rva,"grounded operand "+at);
        });
    }
}
