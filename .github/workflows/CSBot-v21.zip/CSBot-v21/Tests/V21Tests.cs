using System.Text;
using System.Text.Json;
namespace CSBot;
internal static partial class ReaderTests
{
    private static byte[] RegistrationBsp(bool zones=true,bool solid=false,bool dynamic=false)
    {
        byte[] original=BspFixture.Build(BspFixture.Floor);var lumps=new byte[15][];
        for(int i=0;i<15;i++)lumps[i]=original.AsSpan(BitConverter.ToInt32(original,4+i*8),BitConverter.ToInt32(original,8+i*8)).ToArray();
        if(zones)
        {
            lumps[0]=Encoding.ASCII.GetBytes("{\"classname\" \"worldspawn\"}\n{\"classname\" \"func_bomb_target\" \"model\" \"*1\" \"target\" \"tgt_a\"}\n"+(dynamic?"{\"classname\" \"func_door\" \"model\" \"*1\"}\n":"")+"\0");
            lumps[14]=lumps[14].Concat(lumps[14]).ToArray();
        }
        if(solid)BitConverter.GetBytes(-2).CopyTo(lumps[10],0);
        var result=new byte[124+lumps.Sum(x=>x.Length)];BitConverter.GetBytes(30).CopyTo(result,0);int pos=124;
        for(int i=0;i<15;i++){BitConverter.GetBytes(pos).CopyTo(result,4+i*8);BitConverter.GetBytes(lumps[i].Length).CopyTo(result,8+i*8);lumps[i].CopyTo(result,pos);pos+=lumps[i].Length;}
        return result;
    }
    private static byte[] RegistrationGraph(float x=100)
    {
        byte[] raw=new byte[220];BitConverter.GetBytes(NavGraph.GoalFlag).CopyTo(raw,4);BitConverter.GetBytes(x).CopyTo(raw,8);BitConverter.GetBytes(36f).CopyTo(raw,16);
        for(int k=0;k<8;k++)BitConverter.GetBytes((short)-1).CopyTo(raw,56+k*20+18);
        var packed=new byte[]{0xe0,0xd5,0x00}.Concat(raw).ToArray();var result=new byte[24+packed.Length];int[] header={0x59415042,2,8,1,packed.Length,raw.Length};for(int i=0;i<6;i++)BitConverter.GetBytes(header[i]).CopyTo(result,i*4);packed.CopyTo(result,24);return result;
    }
    private static void InMaps(Action<string> action)
    {
        string root=Path.Combine(Path.GetTempPath(),"CSBot-v21-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(Path.Combine(root,"Maps"));Directory.CreateDirectory(Path.Combine(root,"Navigation"));
        try{action(root);}finally{Directory.Delete(root,true);}
    }
    private static void MapPair(string root,string name="de_test")
    {File.WriteAllBytes(Path.Combine(root,"Maps",name+".bsp"),RegistrationBsp());File.WriteAllBytes(Path.Combine(root,"Navigation",name+".graph"),RegistrationGraph());}
    private static Dictionary<string,MapAsset> MapEntries(string root)=>JsonSerializer.Deserialize<Dictionary<string,MapAsset>>(File.ReadAllText(Path.Combine(root,"Maps","maps.json")))!;
    private static void RunV21Tests()
    {
        Test("v21 Maps discovery registers multiple matching pairs without registry",()=>InMaps(root=>
        {MapPair(root,"de_one");MapPair(root,"de_two");var log=new List<string>();var r=MapCatalog.RegisterMaps(root,log.Add);Check(r==new MapRegistration(2,2,0,0,0) && MapEntries(root).Count==2,"two maps");Check(MapCatalog.Load(root,"de_two").Name=="de_two" && log.Last().Contains("source=Maps"),"load actual requested pair");}));
        Test("v21 unchanged assets do not rewrite registry",()=>InMaps(root=>
        {MapPair(root);MapCatalog.RegisterMaps(root);string p=Path.Combine(root,"Maps","maps.json");var bytes=File.ReadAllBytes(p);var time=new DateTime(2020,1,1,0,0,0,DateTimeKind.Utc);File.SetLastWriteTimeUtc(p,time);var r=MapCatalog.RegisterMaps(root);Check(r.Unchanged==1 && r.Registered==0 && File.GetLastWriteTimeUtc(p)==time && bytes.SequenceEqual(File.ReadAllBytes(p)),"cached hashes");}));
        Test("v21 graph changes automatically update fingerprint after preflight",()=>InMaps(root=>
        {MapPair(root);MapCatalog.RegisterMaps(root);var old=MapEntries(root)["de_test"];File.WriteAllBytes(Path.Combine(root,"Navigation","de_test.graph"),RegistrationGraph(101));var r=MapCatalog.RegisterMaps(root);Check(r.Registered==1 && MapEntries(root)["de_test"].GraphSha256!=old.GraphSha256 && MapCatalog.Load(root,"de_test").Graph.Nodes[0].Origin.X==101,"updated graph");}));
        Test("v21 BSP changes automatically update fingerprint after preflight",()=>InMaps(root=>
        {MapPair(root);MapCatalog.RegisterMaps(root);var old=MapEntries(root)["de_test"];string p=Path.Combine(root,"Maps","de_test.bsp");File.WriteAllBytes(p,File.ReadAllBytes(p).Concat(new byte[]{0}).ToArray());Check(MapCatalog.RegisterMaps(root).Registered==1 && MapEntries(root)["de_test"].BspSha256!=old.BspSha256,"updated BSP");}));
        Test("v21 missing graph is skipped while valid pair registers",()=>InMaps(root=>
        {MapPair(root);File.WriteAllBytes(Path.Combine(root,"Maps","de_missing.bsp"),RegistrationBsp());var log=new List<string>();var r=MapCatalog.RegisterMaps(root,log.Add);Check(r==new MapRegistration(2,1,0,1,0) && MapEntries(root).Count==1 && log.Any(x=>x.Contains("Matching asset missing")),"missing counterpart");}));
        Test("v21 graph-only files are not discovery source",()=>InMaps(root=>
        {File.WriteAllBytes(Path.Combine(root,"Navigation","de_only.graph"),RegistrationGraph());var r=MapCatalog.RegisterMaps(root);Check(r.Found==0 && !File.Exists(Path.Combine(root,"Maps","maps.json")),"Maps source only");}));
        foreach(bool graph in new[]{true,false})
        Test("v21 corrupt "+(graph?"graph":"BSP")+" does not block other maps",()=>InMaps(root=>
        {MapPair(root);MapPair(root,"de_bad");File.WriteAllBytes(Path.Combine(root,graph?"Navigation":"Maps",graph?"de_bad.graph":"de_bad.bsp"),new byte[]{1,2,3});var r=MapCatalog.RegisterMaps(root);Check(r.Registered==1 && r.Skipped==1 && r.Errors==1 && !MapEntries(root).ContainsKey("de_bad"),"reject corrupted");}));
        Test("v21 no bomb zones map rejected by current mission preflight",()=>InMaps(root=>
        {MapPair(root);File.WriteAllBytes(Path.Combine(root,"Maps","de_test.bsp"),RegistrationBsp(zones:false));var r=MapCatalog.RegisterMaps(root);Check(r.Skipped==1 && r.Errors==1 && r.Registered==0,"no bomb mission");}));
        Test("v21 absent collision hulls cannot be registered",()=>InMaps(root=>
        {MapPair(root);File.WriteAllBytes(Path.Combine(root,"Maps","de_test.bsp"),SyntheticBsp());Check(MapCatalog.RegisterMaps(root).Errors==1,"no hulls");}));
        Test("v21 graph node in solid contents cannot be registered",()=>InMaps(root=>
        {MapPair(root);File.WriteAllBytes(Path.Combine(root,"Maps","de_test.bsp"),RegistrationBsp(solid:true));Check(MapCatalog.RegisterMaps(root).Errors==1,"solid node");}));
        Test("v21 unsupported dynamic brush is not silently accepted",()=>InMaps(root=>
        {MapPair(root);File.WriteAllBytes(Path.Combine(root,"Maps","de_test.bsp"),RegistrationBsp(dynamic:true));Check(MapCatalog.RegisterMaps(root).Errors==1,"dynamic door");}));
        Test("v21 invalid map filename skipped without traversing paths",()=>InMaps(root=>
        {MapPair(root);MapPair(root,"bad name");var r=MapCatalog.RegisterMaps(root);Check(r.Registered==1 && r.Skipped==1 && r.Errors==1 && MapEntries(root).ContainsKey("de_test"),"invalid name");}));
        Test("v21 scanning is top level and ignores nested BSP files",()=>InMaps(root=>
        {Directory.CreateDirectory(Path.Combine(root,"Maps","nested"));File.WriteAllBytes(Path.Combine(root,"Maps","nested","de_nested.bsp"),RegistrationBsp());Check(MapCatalog.RegisterMaps(root).Found==0,"not recursive");}));
        Test("v21 asset extension and basename matching ignore case",()=>InMaps(root=>
        {File.WriteAllBytes(Path.Combine(root,"Maps","DE_CASE.BSP"),RegistrationBsp());File.WriteAllBytes(Path.Combine(root,"Navigation","De_Case.GRAPH"),RegistrationGraph());Check(MapCatalog.RegisterMaps(root).Registered==1 && MapCatalog.Load(root,"de_case").Name=="de_case","mixed case");}));
        Test("v21 case-colliding file pairs rejected on case-sensitive filesystem",()=>InMaps(root=>
        {if(OperatingSystem.IsWindows())return;MapPair(root);File.WriteAllBytes(Path.Combine(root,"Maps","DE_TEST.BSP"),RegistrationBsp());var r=MapCatalog.RegisterMaps(root);Check(r.Errors==2 && r.Registered==0,"ambiguous files");}));
        foreach(string registry in new[]{"{bad json","null","{\"de_test\":{\"BspSha256\":\"x\",\"GraphSha256\":\"y\"}}"})
        Test("v21 invalid registry preserved "+registry[..Math.Min(12,registry.Length)],()=>InMaps(root=>
        {MapPair(root);string p=Path.Combine(root,"Maps","maps.json");File.WriteAllText(p,registry);Check(MapCatalog.RegisterMaps(root).Errors==1 && File.ReadAllText(p)==registry && !Directory.EnumerateFiles(Path.Combine(root,"Maps"),"*.tmp").Any(),"preserve registry");}));
        Test("v21 unrelated registry entries preserved",()=>InMaps(root=>
        {MapPair(root,"de_existing");MapCatalog.RegisterMaps(root);File.Delete(Path.Combine(root,"Maps","de_existing.bsp"));MapPair(root,"de_new");Check(MapCatalog.RegisterMaps(root).Registered==1 && MapEntries(root).Count==2,"not pruning manual entries");}));
        Test("v21 load still refuses asset hash mismatch until validated registration",()=>InMaps(root=>
        {MapPair(root);MapCatalog.RegisterMaps(root);File.WriteAllBytes(Path.Combine(root,"Navigation","de_test.graph"),RegistrationGraph(105));bool refused=false;try{MapCatalog.Load(root,"de_test");}catch(InvalidDataException){refused=true;}Check(refused,"changed hash");Check(MapCatalog.RegisterMaps(root).Registered==1 && MapCatalog.Load(root,"de_test").Graph.Nodes[0].Origin.X==105,"validated replacement");}));
        Test("v21 unknown requested map never substitutes a registered map",()=>InMaps(root=>
        {MapPair(root);MapCatalog.RegisterMaps(root);bool failed=false;try{MapCatalog.Load(root,"de_other");}catch(InvalidDataException e){failed=e.Message.Contains("no fallback map");}Check(failed,"no guessed map");}));
        Test("v21 single-map registration CLI retained",()=>InMaps(root=>
        {MapPair(root);Check(MapCatalog.TryRun(new[]{"--register-map","de_test",root},out int code) && code==0 && MapEntries(root).Count==1,"single CLI");}));
        Test("v21 all-map registration CLI works offline",()=>InMaps(root=>
        {MapPair(root);Check(MapCatalog.TryRun(new[]{"--register-maps",root},out int code) && code==0 && MapEntries(root).Count==1,"all CLI");}));
        Test("v21 missing Maps folder is nonfatal and not created",()=>
        {string root=Path.Combine(Path.GetTempPath(),Guid.NewGuid().ToString("N"));var r=MapCatalog.RegisterMaps(root);Check(r.Found==0 && r.Errors==0 && !Directory.Exists(root),"no writes");});
        Test("v21 invalid level diagnostics include empty raw value and address",()=>
        {var m=ProfileMemory(name:"");Check(!new WorldStateReader(m).TryRead(0,out _,out var e) && e.Contains("raw=\"\"") && e.Contains("level=0x") && e.Contains("connectionState=") && e.Contains("no map guessed"),e);});
        Test("v21 invalid level diagnostics quote controls and preserve raw hex",()=>
        {var m=ProfileMemory(name:"bad\nname");Check(!new WorldStateReader(m).TryRead(0,out _,out var e) && e.Contains("bad\\nname") && e.Contains("6261640A6E616D65") && !e.Contains('\n'),e);});
    }
    private static void RunV21MapTests(string bsp)
    {
        Test("v21 supplied BSP and graph automatically register from Maps",()=>InMaps(root=>
        {File.Copy(bsp,Path.Combine(root,"Maps","de_dust2.bsp"));File.Copy(Path.Combine(AppContext.BaseDirectory,"de_dust2.graph"),Path.Combine(root,"Navigation","de_dust2.graph"));var r=MapCatalog.RegisterMaps(root);Check(r.Registered==1 && r.Errors==0 && MapCatalog.Load(root,"de_dust2").Map.MatchesSuppliedDust2,"real pair");Check(MapCatalog.RegisterMaps(root).Unchanged==1,"cached pair");}));
    }
}
