using System.Text;
namespace CSBot;
internal static partial class ReaderTests
{
    private static MoveSample MissionPose(ProbeVector? origin=null,ProbeVector? angles=null)=>new(0x20000000,0,0,1,.01f,origin??new(0,0,36),angles??default,default,new(0,0,17),0,0,0,0,0);
    private static WorldState World(int team=1,bool c4=true,bool permission=true,int weapon=6,bool planted=false,ProbeVector? bomb=null)=>new("de_dust2",team,c4,permission,weapon,planted,bomb??default);
    private static FakeMemory WorldMemory(int team=1,bool c4=true,bool permission=true,int weapon=6,bool planted=false)
    {
        var m=new FakeMemory();m.ByteBlocks[FakeMemory.Client+BombHudProfile.DropRva]=BombHudProfile.Signature(FakeMemory.Client);uint c=FakeMemory.Client,h=m.Modules["hw.dll"],f=h+0x1000,p=h+0x2000;
        m.ByteBlocks[c+0x45350]=WorldStateReader.TeamSignature(c);
        m.ByteBlocks[c+WorldStateReader.TeamInfoCodeRva]=WorldStateReader.TeamInfoSignature(c);
        m.UInts[c+WorldStateReader.EngineTable+0x128]=f;
        m.ByteBlocks[f]=new byte[]{0xb8}.Concat(BitConverter.GetBytes(p)).Concat(new byte[]{0xc3}).ToArray();
        var name=new byte[64];Encoding.ASCII.GetBytes("maps/de_dust2.bsp").CopyTo(name,0);m.ByteBlocks[p]=name;
        m.ByteBlocks[c+WorldStateReader.TeamArray+104]=BitConverter.GetBytes((short)team);
        var teamText=new byte[16];Encoding.ASCII.GetBytes(team==1?"TERRORIST":team==2?"CT":"").CopyTo(teamText,0);
        m.ByteBlocks[c+WorldStateReader.TeamArray+104+2]=teamText;
        m.ByteBlocks[c+WorldStateReader.LegacyTeamArray+104]=BitConverter.GetBytes((short)0);
        var icons=new byte[208];if(c4){Encoding.ASCII.GetBytes("c4").CopyTo(icons,0);BitConverter.GetBytes(123).CopyTo(icons,24);BitConverter.GetBytes(permission?1:0).CopyTo(icons,48);}m.ByteBlocks[c+WorldStateReader.Icons]=icons;
        var bomb=new byte[52];BitConverter.GetBytes(12f).CopyTo(bomb,0);BitConverter.GetBytes(34f).CopyTo(bomb,4);BitConverter.GetBytes(0f).CopyTo(bomb,8);
        BitConverter.GetBytes(planted?1:0).CopyTo(bomb,16);BitConverter.GetBytes(planted?99999:0).CopyTo(bomb,20);BitConverter.GetBytes((short)(planted?1:0)).CopyTo(bomb,24);m.ByteBlocks[c+WorldStateReader.BombData]=bomb;
        m.UInts[c+WorldStateReader.WeaponPointer]=weapon==0?0:c+WorldStateReader.Weapons+(uint)weapon*328;return m;
    }
    private static void RunV15Tests()
    {
        Test("v15 death needs alive context and two advancing death samples",()=>
        {var l=new LifeEvidence();var p=MissionPose();Check(!l.Observe("map/1",p,0,0),"zero before alive");l.Observe("map/1",p,100,25);var d=p with{Time=2,Dead=1};Check(!l.Observe("map/1",d,0,50),"first death neutral wait");Check(l.Observe("map/1",d with{Time=2.05f},0,100),"fresh confirmed death");});
        Test("v15 stale death and map transition are not terminal evidence",()=>
        {var l=new LifeEvidence();var p=MissionPose();l.Observe("map/1",p,100,0);var d=p with{Time=2,Dead=1};l.Observe("map/1",d,0,50);Check(!l.Observe("map/1",d,0,100),"stale");Check(!l.Observe("other/1",d with{Time=3},0,150),"new context zero");Check(!l.Observe("other/1",d with{Time=4},0,200),"no alive evidence in new map");});
        Test("v15 HUD snapshot reads map team C4 permission and ID6",()=>
        {var r=new WorldStateReader(WorldMemory());Check(r.TryRead(0,out var w,out var e),e);Check(w.Map=="de_dust2" && w.Team==1 && w.HasC4 && w.CanPlant && w.WeaponId==6 && !w.BombPlanted,"HUD snapshot");});
        Test("v15 HUD planted coordinates and CT",()=>
        {var r=new WorldStateReader(WorldMemory(2,false,false,29,true));Check(r.TryRead(0,out var w,out var e),e);Check(w.Team==2 && w.BombPlanted && w.Bomb==new ProbeVector(12,34,0) && w.WeaponId==29 && !w.HasC4,"CT HUD");});
        Test("v15 nonflashing C4 does not authorize planting",()=>
        {var r=new WorldStateReader(WorldMemory(permission:false));Check(r.TryRead(0,out var w,out var e),e);Check(w.HasC4 && !w.CanPlant,"no flash");});
        Test("v15 map parser rejects traversal and unsupported names",()=>
        {foreach(string name in new[]{"../de_dust2.bsp","maps/../x.bsp","C:/x.bsp","","maps/sub/x.bsp","bad name","карта"}){bool failed=false;try{WorldStateReader.NormalizeMap(name);}catch(FormatException){failed=true;}Check(failed,name);}Check(WorldStateReader.NormalizeMap("MAPS\\DE_DUST2.BSP")=="de_dust2","normalize");});
        Test("v15 unsupported map stub never guesses dust2",()=>
        {var m=WorldMemory();m.ByteBlocks[m.Modules["hw.dll"]+0x1000][0]=0x55;Check(!new WorldStateReader(m).TryRead(0,out _,out var e) && e.Contains("no map guessed"),e);});
        Test("v15 map thunk and pointer-return stub are supported",()=>
        {var m=WorldMemory();uint h=m.Modules["hw.dll"],f=h+0x1000,g=h+0x1100,ptr=h+0x1200;
            m.ByteBlocks[f]=new byte[]{0xe9}.Concat(BitConverter.GetBytes((int)(g-f-5))).Concat(new byte[]{0x90}).ToArray();
            m.ByteBlocks[g]=new byte[]{0xa1}.Concat(BitConverter.GetBytes(ptr)).Concat(new byte[]{0xc3}).ToArray();m.UInts[ptr]=h+0x2000;
            Check(new WorldStateReader(m).TryRead(0,out var w,out var e) && w.Map=="de_dust2",e);
            m.ByteBlocks[g]=new byte[]{0xa1}.Concat(BitConverter.GetBytes(0x20000000u)).Concat(new byte[]{0xc3}).ToArray();m.UInts[0x20000000]=h+0x2000;Check(!new WorldStateReader(m).TryRead(0,out _,out _),"pointer storage outside engine refused");});
        Test("v15 HUD runtime code signature is mandatory",()=>
        {var m=WorldMemory();m.ByteBlocks[FakeMemory.Client+0x45350][0]=0x90;Check(!new WorldStateReader(m).TryRead(0,out _,out var e) && e.Contains("signature"),e);});
        Test("v15 invalid local index team and weapon pointers refused",()=>
        {var m=WorldMemory();var r=new WorldStateReader(m);Check(!r.TryRead(32,out _,out _),"index");m.ByteBlocks[FakeMemory.Client+WorldStateReader.TeamArray+104]=BitConverter.GetBytes((short)8);Check(!r.TryRead(0,out _,out _),"team");m=WorldMemory();m.UInts[FakeMemory.Client+WorldStateReader.WeaponPointer]++;Check(!new WorldStateReader(m).TryRead(0,out _,out _),"unaligned weapon");});
        Test("v15 malformed icon and bomb states refused",()=>
        {var m=WorldMemory();BitConverter.GetBytes(9).CopyTo(m.ByteBlocks[FakeMemory.Client+WorldStateReader.Icons],48);Check(!new WorldStateReader(m).TryRead(0,out _,out _),"icon");m=WorldMemory(planted:true);BitConverter.GetBytes(float.NaN).CopyTo(m.ByteBlocks[FakeMemory.Client+WorldStateReader.BombData],0);Check(!new WorldStateReader(m).TryRead(0,out _,out _),"NaN bomb");m=WorldMemory();m.ByteBlocks[FakeMemory.Client+WorldStateReader.BombData][16]=2;Check(!new WorldStateReader(m).TryRead(0,out _,out _),"activeflag");});
        Test("v15 rejects weapon and icon changes during snapshot",()=>
        {foreach(bool weapon in new[]{true,false}){var m=WorldMemory();int reads=0;m.BeforeBytes=a=>{if(a==FakeMemory.Client+WorldStateReader.BombData && ++reads==2){if(weapon)m.UInts[FakeMemory.Client+WorldStateReader.WeaponPointer]=0;else m.ByteBlocks[FakeMemory.Client+WorldStateReader.Icons][0]=0;}};Check(!new WorldStateReader(m).TryRead(0,out _,out var e) && e.Contains("changed"),e);}});
        Test("v15 inverted m_pitch reverses issued vertical packets",()=>
        {var p=MissionPose();var w=World(2,planted:true,bomb:new(20,0,0));var s=new BotSettings();var normal=new BombObjectives(.071,s).Tick(w,p,0,false,true).Command!;var inverted=new BombObjectives(.071,s,-1).Tick(w,p,0,false,true).Command!;Check(normal.MouseDy!=0 && inverted.MouseDy==-normal.MouseDy,"pitch sign");});
        Test("v15 T planting requires zone C4 permission and selected ID6",()=>
        {var s=new BotSettings();var p=MissionPose();foreach(var w in new[]{World(c4:false),World(permission:false),World(weapon:29),World(team:2)}){var a=new BombObjectives(.071,s).Tick(w,p,0,true,true);Check(a.Command?.Attack!=true,"no unsafe attack");}Check(new BombObjectives(.071,s).Tick(World(),p,0,false,true).Navigate,"outside zone");var ready=new BombObjectives(.071,s).Tick(World(),p,0,true,true);Check(ready.Command?.Attack==true && !ready.Navigate,"plant hold");});
        Test("v15 selecting C4 is rate limited and waits for weapon acknowledgement",()=>
        {var f=new BombObjectives(.071,new());var p=MissionPose();Check(f.Tick(World(weapon:1),p,0,true,true).Command?.SelectC4==true,"select");Check(f.Tick(World(weapon:1),p,100,true,true).Command?.SelectC4==false,"rate limit");Check(f.Tick(World(weapon:1),p,800,true,true).Command?.SelectC4==true,"retry");Check(f.Tick(World(),p,900,true,true).Command?.Attack==true,"ack");});
        Test("v15 plant window releases and does not claim success",()=>
        {var s=new BotSettings();var f=new BombObjectives(.071,s);var p=MissionPose();f.Tick(World(),p,0,true,true);var a=f.Tick(World(),p,s.PlantHoldMs+1,true,true);Check(a.Command?.Attack!=true && a.Mode.Contains("not-confirmed"),"window release");Check(f.Tick(World(),p,s.PlantHoldMs+100,true,true).Command?.Attack!=true,"cooldown");Check(f.Tick(World(planted:true),p,6000,true,true).Command?.Attack!=true,"planted cancels attack");});
        Test("v15 movement and air prevent plant and defuse",()=>
        {var p=MissionPose();foreach(var pose in new[]{p with{OnGround=-1},p with{Velocity=new(11,0,0)}}){Check(new BombObjectives(.071,new()).Tick(World(),pose,0,true,true).Command?.Attack!=true,"plant brake");Check(new BombObjectives(.071,new()).Tick(World(2,planted:true,bomb:new(10,0,36)),pose,0,false,true).Command?.Use!=true,"defuse brake");}});
        Test("v15 CT needs planted HUD near distance and clear line",()=>
        {var p=MissionPose();var f=new BombObjectives(.071,new());Check(f.Tick(World(2),p,0,false,true).Navigate,"no bomb");Check(f.Tick(World(2,planted:true,bomb:new(100,0,36)),p,1,false,true).Navigate,"far");Check(f.Tick(World(2,planted:true,bomb:new(10,0,36)),p,2,false,false).Command?.Use!=true,"occluded");});
        Test("v15 aligned CT holds E and timed window is not success",()=>
        {var s=new BotSettings();var p=MissionPose();var w=World(2,planted:true,bomb:new(20,0,49));var f=new BombObjectives(.071,s);Check(f.Tick(w,p,0,false,true).Command?.Use==true,"aligned use");Check(f.Tick(w,p,s.DefuseHoldMs+1,false,true).Command?.Use!=true,"bounded release");Check(f.Tick(w with{BombPlanted=false},p,s.DefuseHoldMs+20,false,true).Command?.Use!=true,"clear HUD not a success assertion");});
        Test("v15 yaw and pitch aiming converges before E",()=>
        {var s=new BotSettings();var f=new BombObjectives(.071,s);var w=World(2,planted:true,bomb:new(25,20,0));var p=MissionPose();double yaw=0,pitch=0;var pending=new List<(long At,int X,int Y)>();bool used=false,both=false;
            for(long t=0;t<8000;t+=25){foreach(var q in pending.Where(x=>x.At<=t).ToArray()){yaw=PulseSteering.Normalize(yaw-q.X*.071);pitch+=q.Y*.071;pending.Remove(q);}p=p with{Angles=new((float)pitch,(float)yaw,0)};var a=f.Tick(w,p,t,false,true);Check(a.Error=="",a.Error);var c=a.Command!;if(c.Use){used=true;break;}if(c.MouseDx!=0 && c.MouseDy!=0)both=true;if(c.MouseDx!=0 || c.MouseDy!=0)pending.Add((t+25,c.MouseDx,c.MouseDy));}Check(used && both,"two-axis feedback before use");});
        Test("v15 horizon feedback survives navigation ticks",()=>
        {var s=new BotSettings();var f=new BombObjectives(.071,s);var p=MissionPose(angles:new(45,0,0));double pitch=45;bool done=false;
            for(int t=0;t<8000;t+=50){p=p with{Angles=new((float)pitch,0,0)};Check(f.Tick(World(2),p,t,false,true).Navigate,"navigate");var a=f.Flatten(p,t);Check(a.Error=="",a.Error);pitch+=a.Command!.MouseDy*.071;if(Math.Abs(pitch)<5){done=true;break;}}Check(done,"horizon converges without resetting every tick");});
        Test("v15 objectives off never attack or use",()=>
        {var s=new BotSettings{AutoObjectives="off"};var f=new BombObjectives(.071,s);Check(f.Tick(World(),MissionPose(),0,true,true).Navigate && f.Tick(World(2,planted:true),MissionPose(),1,true,true).Command==null,"disabled");});
        foreach(string reason in new[]{"neutral","focus","watchdog","stop","dispose","finished"})
        Test("v15 objective input released on "+reason,()=>
        {var b=new FakeControlBackend();var i=new WindowsControl(b,false);i.Arm();i.Apply(new(false,0,false,"",0,Attack:true,Use:true));Check(b.ObjectiveEvents.Last()==(true,true,false),"holds");switch(reason){case "focus":b.Focused=false;i.CheckWatchdog();break;case "watchdog":b.Now=251;i.CheckWatchdog();break;case "stop":b.StopPressed=true;i.Apply(new(false,8,false,"",0,MouseDy:2,Attack:true));break;case "dispose":i.Dispose();break;case "finished":i.Apply(new(false,0,true,"",0));break;default:i.Apply(new(false,0,false,"",0));break;}Check(b.ObjectiveEvents.Last()==(false,false,false),"release");Check(b.Axes.Count==0,"no late mouse");i.Dispose();});
        Test("v15 partial objective failure is released on disposal",()=>
        {var b=new FakeControlBackend{ObjectiveFails=true};try{using var i=new WindowsControl(b,false);i.Arm();i.Apply(new(false,0,false,"",0,Attack:true,Use:true,SelectC4:true));}catch(InvalidOperationException){}Check(b.ObjectiveEvents.SequenceEqual(new[]{(true,true,true),(false,false,false)}),"partial input release");});
        Test("v15 movement release does not cancel an active defuse",()=>
        {var b=new FakeControlBackend();using var i=new WindowsControl(b,false);i.Arm();i.Apply(new(true,0,false,"",0));i.Apply(new(false,0,false,"",0,Use:true));i.Apply(new(false,0,false,"",0,Use:true));Check(b.KeyEvents.SequenceEqual(new[]{true,false}) && b.ObjectiveEvents.Count==1 && b.ObjectiveEvents[0].Use,"E held while W released");i.Apply(new(false,2,false,"",0,MouseDy:3));Check(b.ObjectiveEvents.Last()==(false,false,false) && b.Axes.Last()==(2,3),"axes and release");});
        Test("v15 settings validate objective toggles and bounds",()=>
        {foreach(string text in new[]{"AutoObjectives=yes","ObjectiveSite=c","DefuseRadius=100","PlantHoldMs=0"}){bool failed=false;try{BotSettings.Parse(text);}catch(Exception e)when(e is ArgumentException or FormatException or InvalidDataException){failed=true;}Check(failed,text);}var s=BotSettings.Load(Path.Combine(AppContext.BaseDirectory,"config.txt"));Check(s.AutoObjectives=="on" && s.Motion=="run" && s.DefuseHoldMs>=10500,"shipped defaults");});
    }
    private static void RunV15MapTests(BspMap map,NavGraph graph,string bsp)
    {
        var loaded=new LoadedMap("de_dust2",map,graph,new WalkGeometry(map),new MapNavigation(graph,map));
        Test("v15 auto mission uses actual T origin and site",()=>
        {var origin=new ProbeVector(-832,-704,164.03125f);var r=MissionPlanner.Build(loaded,World(),origin,new());Check(r!=null && r.Kind=="site-approach" && r.Targets.Count>0,"site route");Check(loaded.Walk.Check(origin,r!.Targets[0]).Safe,"live attachment");});
        Test("v15 CT plans to actual planted bomb with standing hull",()=>
        {var node=graph.Nodes.First(n=>loaded.Map.InsideZone(n.Origin,MissionPlanner.Site(loaded,"a")) && loaded.Walk.Supported(n.Origin,out _));
            var bomb=new ProbeVector(node.Origin.X,node.Origin.Y,node.Origin.Z-36);var origin=new ProbeVector(448,2464,-91.969f);var w=World(2,planted:true,bomb:bomb);var r=MissionPlanner.Build(loaded,w,origin,new());Check(r!=null && r.Kind=="defuse-approach","bomb approach");var at=origin;foreach(var target in r!.Targets){Check(loaded.Walk.Check(at,target).Safe,"checked attachment/edge");at=target;}Check(NavGraph.Distance(at,bomb)<=60,"defuse range");});
        Test("v15 automatic map catalog checks hashes and rejects missing maps",()=>
        {string dir=Path.Combine(Path.GetTempPath(),Guid.NewGuid().ToString("N"));Directory.CreateDirectory(Path.Combine(dir,"Maps"));Directory.CreateDirectory(Path.Combine(dir,"Navigation"));try{File.Copy(bsp,Path.Combine(dir,"Maps","de_dust2.bsp"));File.Copy(Path.Combine(AppContext.BaseDirectory,"de_dust2.graph"),Path.Combine(dir,"Navigation","de_dust2.graph"));
            string hash=Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(Path.Combine(dir,"Navigation","de_dust2.graph")))).ToLowerInvariant();
            File.WriteAllText(Path.Combine(dir,"Maps","maps.json"),System.Text.Json.JsonSerializer.Serialize(new Dictionary<string,MapAsset>{{"de_dust2",new(map.Sha256,hash)}}));
            Check(MapCatalog.Load(dir,"maps/de_dust2.bsp").Name=="de_dust2","automatic load");bool failed=false;try{MapCatalog.Load(dir,"de_inferno");}catch(InvalidDataException){failed=true;}Check(failed,"no fallback");File.AppendAllText(Path.Combine(dir,"Navigation","de_dust2.graph"),"bad");failed=false;try{MapCatalog.Load(dir,"de_dust2");}catch(InvalidDataException){failed=true;}Check(failed,"hash mismatch");}finally{Directory.Delete(dir,true);}});
    }
}
