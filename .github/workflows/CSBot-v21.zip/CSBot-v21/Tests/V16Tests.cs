using System.Text;
namespace CSBot;
internal static partial class ReaderTests
{
    private static FakeMemory ProfileMemory(int state=4,string name="maps/de_dust2.bsp",uint engine=0x04930000)
    {
        var m=WorldMemory();m.AllowPrefixReads=true;
        m.Modules["hw.dll"]=engine;
        m.UInts[FakeMemory.Client+WorldStateReader.EngineTable+0x128]=engine+WorldStateReader.LevelFunctionRva;
        m.ByteBlocks[engine+WorldStateReader.LevelFunctionRva]=WorldStateReader.LevelSignature(engine);
        m.Ints[engine+WorldStateReader.ConnectionStateRva]=state;
        var text=new byte[WorldStateReader.LevelBufferLength];Encoding.ASCII.GetBytes(name).CopyTo(text,0);
        m.ByteBlocks[engine+WorldStateReader.LevelBufferRva]=text;
        return m;
    }
    private static void RunV16Tests()
    {
        Test("v16 exact reported FF1508C9AA04 function reads dust2",()=>
        {var m=ProfileMemory();var code=m.ByteBlocks[0x04949950];Check(Convert.ToHexString(code[..6])=="FF1508C9AA04","reported relocated prefix");Check(code.Length==27,"full branch length");Check(new WorldStateReader(m).TryRead(0,out var w,out var e),e);Check(w.Map=="de_dust2" && w.Team==1,"world");});
        Test("v16 exact profile supports relocated engine bases",()=>
        {foreach(uint engine in new uint[]{0x01D00000,0x04930000,0x10000000}){var m=ProfileMemory(engine:engine);Check(new WorldStateReader(m).TryRead(0,out var w,out var e) && w.Map=="de_dust2",e);}});
        Test("v16 state less than three never reads stale map",()=>
        {foreach(int state in new[]{-1,0,1,2}){var m=ProfileMemory(state);bool readMap=false;m.BeforeBytes=a=>{if(a==m.Modules["hw.dll"]+WorldStateReader.LevelBufferRva)readMap=true;};Check(!new WorldStateReader(m).TryRead(0,out _,out var e) && e.Contains("level not ready") && !readMap,e);}});
        Test("v16 signed state three takes actual level buffer",()=>
        {var m=ProfileMemory(3);Check(new WorldStateReader(m).TryRead(0,out var w,out var e) && w.Map=="de_dust2",e);});
        Test("v16 absent connection state is not a guessed level",()=>
        {var m=ProfileMemory();m.Ints.Remove(m.Modules["hw.dll"]+WorldStateReader.ConnectionStateRva);Check(!new WorldStateReader(m).TryRead(0,out _,out var e) && e.Contains("state unreadable"),e);});
        Test("v16 full signature rejects wrong condition call or map operand",()=>
        {foreach(int offset in new[]{2,7,13,15,19,20,22,26}){var m=ProfileMemory();m.ByteBlocks[m.Modules["hw.dll"]+WorldStateReader.LevelFunctionRva][offset]^=1;Check(!new WorldStateReader(m).TryRead(0,out _,out var e) && e.Contains("signature differs"),e);}});
        Test("v16 FF15 at unrelated address is not emulated",()=>
        {var m=ProfileMemory();uint h=m.Modules["hw.dll"],other=h+0x19940;m.UInts[FakeMemory.Client+WorldStateReader.EngineTable+0x128]=other;m.ByteBlocks[other]=WorldStateReader.LevelSignature(h);Check(!new WorldStateReader(m).TryRead(0,out _,out var e) && e.Contains("no map guessed"),e);});
        Test("v16 truncated code or short level buffer refused",()=>
        {foreach(bool truncateCode in new[]{true,false}){var m=ProfileMemory();uint a=m.Modules["hw.dll"]+(truncateCode?WorldStateReader.LevelFunctionRva:WorldStateReader.LevelBufferRva);m.ByteBlocks[a]=m.ByteBlocks[a][..^1];Check(!new WorldStateReader(m).TryRead(0,out _,out _),"truncated read");}});
        Test("v16 uses exactly forty-byte map buffer not adjacent counters",()=>
        {var m=ProfileMemory();uint a=m.Modules["hw.dll"]+WorldStateReader.LevelBufferRva;int reads=0;m.BeforeBytes=x=>{if(x==a)reads++;};Check(new WorldStateReader(m).TryRead(0,out _,out var e),e);Check(m.ByteBlocks[a].Length==40 && reads==2,"40-byte reads and reread");});
        Test("v16 state transition during snapshot rejected",()=>
        {var m=ProfileMemory();uint a=m.Modules["hw.dll"]+WorldStateReader.ConnectionStateRva;int reads=0;m.BeforeInt=x=>{if(x==a && ++reads==2)m.Ints[a]=2;};Check(!new WorldStateReader(m).TryRead(0,out _,out var e) && e.Contains("changed during snapshot"),e);});
        Test("v16 changed callback table rejected",()=>
        {var m=ProfileMemory();uint slot=FakeMemory.Client+WorldStateReader.EngineTable+0x128;int reads=0;m.BeforeBytes=x=>{if(x==FakeMemory.Client+WorldStateReader.BombData && ++reads==2)m.UInts[slot]++;};Check(!new WorldStateReader(m).TryRead(0,out _,out var e) && e.Contains("changed during snapshot"),e);});
        Test("v16 profile map change and path variants are read not hardcoded",()=>
        {foreach(string name in new[]{"de_inferno","maps/de_nuke.bsp","maps\\de_dust2.bsp"}){var m=ProfileMemory(name:name);Check(new WorldStateReader(m).TryRead(0,out var w,out var e),e);Check(w.Map==WorldStateReader.NormalizeMap(name),"actual map text");}});
        Test("v16 empty unsafe and unterminated levels are refused",()=>
        {foreach(string name in new[]{"","maps/../de_dust2.bsp",new string('a',40)}){var m=ProfileMemory(name:name);Check(!new WorldStateReader(m).TryRead(0,out _,out _),"invalid text");}});
        Test("v16 engine bound checks cover full profile data",()=>
        {var m=ProfileMemory();m.ModuleSizes["hw.dll"]=0x100000;Check(!new WorldStateReader(m).TryRead(0,out _,out var e),e);});
    }
    private static void RunV16EngineFileTest(string path)
    {
        Test("v16 full profile matches supplied PE bytes and logged relocation",()=>
        {
            byte[] file=File.ReadAllBytes(path);
            Check(Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(file)).Equals("319fd65a9151d42c451c9821a78a031d20da51fcc5db2f555de1651416469c3c",StringComparison.OrdinalIgnoreCase),"exact supplied hw.dll fingerprint");
            int pe=BitConverter.ToInt32(file,0x3c),sections=BitConverter.ToUInt16(file,pe+6),optional=pe+24;
            Check(BitConverter.ToUInt16(file,optional)==0x10b,"PE32");uint image=BitConverter.ToUInt32(file,optional+28);
            int headers=optional+BitConverter.ToUInt16(file,pe+20),offset=-1;
            for(int i=0;i<sections;i++){int at=headers+i*40;uint rva=BitConverter.ToUInt32(file,at+12),size=BitConverter.ToUInt32(file,at+16);if(WorldStateReader.LevelFunctionRva>=rva && WorldStateReader.LevelFunctionRva+27<=rva+size)offset=checked((int)(BitConverter.ToUInt32(file,at+20)+WorldStateReader.LevelFunctionRva-rva));}
            Check(offset>=0,"function file offset");var actual=file.AsSpan(offset,27).ToArray();Check(actual.SequenceEqual(WorldStateReader.LevelSignature(image)),"complete real function not just prefix");
            const uint loaded=0x04930000;foreach(int at in new[]{2,7,15,22})BitConverter.GetBytes(unchecked(BitConverter.ToUInt32(actual,at)-image+loaded)).CopyTo(actual,at);
            Check(actual.SequenceEqual(WorldStateReader.LevelSignature(loaded)) && Convert.ToHexString(actual[..6])=="FF1508C9AA04","actual operands rebased to logged address");
        });
    }
}
