using System.Text;
namespace CSBot;
internal static partial class ReaderTests
{
    private static BotSettings CombatSettings(string mode="medium")
    {var s=new BotSettings{Difficulty=mode,CombatReactionMs=0,FireStableMs=0};DifficultyProfile.Resolve(s).Apply(s);s.Validate();return s;}
    private static EnemyState CombatEnemy(long now=0,int id=2)=>new(id,2,new(200,0,36),new(200,0,53),100,10)
        {HeadPoint=new(200,0,64),ObservedAtMs=now};
    private static WorldState GunWorld(int weapon=28)=>AimWorld() with{WeaponId=weapon};
    private static MoveSample CombatPose(long now=0,ProbeVector? angles=null)=>MissionPose(angles:angles) with{Time=1+now/1000f};
    private static bool Clear(ProbeVector a,ProbeVector b)=>true;
    private static void RunV20Tests()
    {
        foreach(string name in new[]{"easy","medium","hard","god"})
        Test("v20 profile validates "+name,()=>
        {var s=BotSettings.Parse("Difficulty="+name.ToUpperInvariant());var p=DifficultyProfile.Resolve(s);p.Apply(s);s.Validate();Check(s.Difficulty==name && s.AimScanMs==p.ScanMs && s.AimMaxDistance==p.Range && s.MouseMaxCounts==p.MouseCounts && s.LoopMs==p.LoopMs,"effective tuning");});
        Test("v20 profile speeds and delays are ordered",()=>
        {var p=new[]{"easy","medium","hard","god"}.Select(x=>DifficultyProfile.Resolve(new(){Difficulty=x})).ToArray();for(int n=1;n<4;n++)Check(p[n].ReactionMs<p[n-1].ReactionMs && p[n].Range>p[n-1].Range && p[n].MouseCounts>p[n-1].MouseCounts && p[n].ScanMs<p[n-1].ScanMs,"ordered");});
        Test("v20 manual tuning preserves explicit steering and ranges",()=>
        {var s=new BotSettings{Difficulty="god",DifficultyTuning="off",MouseMaxCounts=50,AimFovDeg=90,AimMaxDistance=1000,LoopMs=30};var p=DifficultyProfile.Resolve(s);p.Apply(s);Check(s.MouseMaxCounts==50 && s.AimFovDeg==90 && s.AimMaxDistance==1000 && s.LoopMs==30 && p.AimPart=="head","manual with head profile");});
        Test("v20 invalid new settings rejected",()=>
        {foreach(string text in new[]{"Difficulty=expert","DifficultyTuning=yes","AutoFire=maybe","RearTurn=yes","CombatReactionMs=-2","FireStableMs=-2","FireFreshMs=501","HeadAimRadius=0","BodyAimRadius=17","AimMaxDistance=16385","FireBurstMs=1001"}){bool rejected=false;try{BotSettings.Parse(text);}catch(FormatException){rejected=true;}Check(rejected,text);}});
        Test("v20 complete config has 101 fields and tuning validates",()=>
        {var s=BotSettings.Load(Path.Combine(AppContext.BaseDirectory,"config.txt"));int count=0;s.Report(_=>count++);Check(count==101,"101 fields");DifficultyProfile.Resolve(s).Apply(s);s.Validate();});
        foreach(string name in new[]{"easy","medium","hard","god"})
        Test("v20 target point "+name,()=>
        {var a=new EnemyAim(.1,CombatSettings(name),1).Tick(GunWorld(),CombatPose(),new[]{CombatEnemy()},0,Clear);Check(a.Active && a.Part==(name is "easy" or "medium"?"body":"head"),"selected point");});
        Test("v20 hard uses body at distance or when head blocked",()=>
        {var e=CombatEnemy() with{Origin=new(2000,0,36),AimPoint=new(2000,0,53),HeadPoint=new(2000,0,64)};var s=CombatSettings("hard");Check(new EnemyAim(.1,s,1).Tick(GunWorld(),CombatPose(),new[]{e},0,Clear).Part=="body","far body");Check(new EnemyAim(.1,s,1).Tick(GunWorld(),CombatPose(),new[]{CombatEnemy()},0,(_,b)=>b.Z<60).Part=="body","head blocked");});
        Test("v20 God refuses body fallback and missing head",()=>
        {var s=CombatSettings("god");Check(!new EnemyAim(.1,s,1).Tick(GunWorld(),CombatPose(),new[]{CombatEnemy()},0,(_,b)=>b.Z<60).Active,"head obstructed");Check(!new EnemyAim(.1,s,1).Tick(GunWorld(),CombatPose(),new[]{CombatEnemy() with{HeadPoint=null}},0,Clear).Active,"head unknown");});
        Test("v20 exact rear enemy produces turn not attack",()=>
        {var e=CombatEnemy() with{Origin=new(-200,0,36),AimPoint=new(-200,0,53)};var a=new EnemyAim(.1,CombatSettings(),1).Tick(GunWorld(),CombatPose(),new[]{e},0,Clear);Check(a.Active && a.ErrorDeg==180 && a.Command!.MouseDx!=0 && !a.Command.Attack,"180 turn");});
        Test("v20 rear switch and radius restrict rear acquisition",()=>
        {var s=CombatSettings();var e=CombatEnemy() with{Origin=new(-200,0,36),AimPoint=new(-200,0,53)};s.RearTurn="off";Check(!new EnemyAim(.1,s,1).Tick(GunWorld(),CombatPose(),new[]{e},0,Clear).Active,"rear disabled");s.RearTurn="on";s.RearAwarenessRadius=100;Check(!new EnemyAim(.1,s,1).Tick(GunWorld(),CombatPose(),new[]{e},0,Clear).Active,"rear too far");});
        Test("v20 God 360 includes rear elevated target",()=>
        {var e=CombatEnemy() with{Origin=new(-3000,0,36),AimPoint=new(-3000,0,53),HeadPoint=new(-3000,0,100)};var a=new EnemyAim(.1,CombatSettings("god"),1).Tick(GunWorld(),CombatPose(),new[]{e},0,Clear);Check(a.Active && a.Part=="head","all-angle");});
        Test("v20 yaw wrap chooses short rear/front turn",()=>
        {var e=CombatEnemy() with{Origin=new(-200,-3.49f,36),AimPoint=new(-200,-3.49f,53)};var a=new EnemyAim(.1,CombatSettings(),1).Tick(GunWorld(),CombatPose(angles:new(0,179,0)),new[]{e},0,Clear);Check(a.Active && a.ErrorDeg<2.1 && a.Command!.MouseDx<0,"wrap short");});
        Test("v20 aligned live firearm starts fire with no mouse",()=>
        {var a=new EnemyAim(.1,CombatSettings(),1).Tick(GunWorld(),CombatPose(),new[]{CombatEnemy()},0,Clear);Check(a.Command is{Attack:true,Forward:false,Use:false,MouseDx:0,MouseDy:0},"fire");});
        Test("v20 reaction delays input and resets on target switch",()=>
        {var s=CombatSettings("easy");s.CombatReactionMs=-1;var aim=new EnemyAim(.1,s,1);foreach(long t in new long[]{0,300,699}){var a=aim.Tick(GunWorld(),CombatPose(t),new[]{CombatEnemy(t)},t,Clear);Check(a.Command is{Attack:false,MouseDx:0,MouseDy:0},"wait");}Check(aim.Tick(GunWorld(),CombatPose(700),new[]{CombatEnemy(700)},700,Clear).Command!.Attack,"reaction elapsed");var changed=aim.Tick(GunWorld(),CombatPose(710),new[]{CombatEnemy(710,3)},710,Clear);Check(!changed.Command!.Attack && changed.Mode.StartsWith("combat-react"),"new target waits");});
        Test("v20 hard damage shortens profile reaction only",()=>
        {var s=CombatSettings("hard");s.CombatReactionMs=-1;var aim=new EnemyAim(.1,s,1);var e=CombatEnemy() with{HeadPoint=new(200,0,53)};Check(!aim.Tick(GunWorld(),CombatPose(),new[]{e},0,Clear,true).Command!.Attack,"first");Check(aim.Tick(GunWorld(),CombatPose(35),new[]{e with{ObservedAtMs=35}},35,Clear,true).Command!.Attack,"35ms");});
        Test("v20 stability interval required before fire",()=>
        {var s=CombatSettings();s.FireStableMs=70;var aim=new EnemyAim(.1,s,1);foreach(long t in new long[]{0,69,70}){var a=aim.Tick(GunWorld(),CombatPose(t),new[]{CombatEnemy(t)},t,Clear);Check(a.Command!.Attack==(t==70),"stable "+t);}});
        Test("v20 stale unobserved and future snapshots cannot fire",()=>
        {foreach(long stamp in new long[]{-1,0,501}){var a=new EnemyAim(.1,CombatSettings(),1).Tick(GunWorld(),CombatPose(500),new[]{CombatEnemy(stamp)},500,Clear);Check(a.Active && !a.Command!.Attack,"stale "+stamp);}});
        Test("v20 frozen movement frame stops existing attack",()=>
        {var aim=new EnemyAim(.1,CombatSettings(),1);Check(aim.Tick(GunWorld(),CombatPose(),new[]{CombatEnemy()},0,Clear).Command!.Attack,"start");Check(!aim.Tick(GunWorld(),CombatPose(),new[]{CombatEnemy(101)},101,Clear).Command!.Attack,"frozen");});
        Test("v20 queued mouse feedback prevents shooting",()=>
        {var aim=new EnemyAim(.1,CombatSettings(),1);var e=CombatEnemy() with{AimPoint=new(200,10,53)};var a=aim.Tick(GunWorld(),CombatPose(),new[]{e},0,Clear);Check(a.Command!.MouseDx!=0 && !a.Command.Attack,"pulse");var b=aim.Tick(GunWorld(),CombatPose(10, new(0,2.8624f,0)),new[]{e with{ObservedAtMs=10}},10,Clear);Check(!b.Command!.Attack,"pending");});
        Test("v20 AutoFire off keeps aiming and forbids fire",()=>
        {var s=CombatSettings();s.AutoFire="off";var a=new EnemyAim(.1,s,1).Tick(GunWorld(),CombatPose(),new[]{CombatEnemy()},0,Clear);Check(a.Active && !a.Command!.Attack,"aim only");});
        Test("v20 weapon whitelist excludes C4 knife grenades and unknown",()=>
        {foreach(int weapon in new[]{-1,0,4,6,9,25,29,99})Check(!new EnemyAim(.1,CombatSettings(),1).Tick(GunWorld(weapon),CombatPose(),new[]{CombatEnemy()},0,Clear).Command!.Attack,"no firearm "+weapon);foreach(int weapon in new[]{1,3,16,17,18,22,26,28,30})Check(FireControl.Firearm(weapon),"firearm "+weapon);});
        Test("v20 unknown local team allies and world walls never targeted",()=>
        {foreach(int team in new[]{0,3})Check(!new EnemyAim(.1,CombatSettings(),1).Tick(GunWorld() with{Team=team},CombatPose(),new[]{CombatEnemy()},0,Clear).Active,"unknown team");Check(!new EnemyAim(.1,CombatSettings(),1).Tick(GunWorld(),CombatPose(),new[]{CombatEnemy() with{Team=1}},0,Clear).Active,"ally");Check(!new EnemyAim(.1,CombatSettings(),1).Tick(GunWorld(),CombatPose(),new[]{CombatEnemy()},0,(_,_)=>false).Active,"wall");});
        Test("v20 lost target death and disabled module clear fire state",()=>
        {foreach(int kind in new[]{0,1,2,3}){var s=CombatSettings();var aim=new EnemyAim(.1,s,1);Check(aim.Tick(GunWorld(),CombatPose(),new[]{CombatEnemy()},0,Clear).Command!.Attack,"start");if(kind==2)s.EnemyAim="off";var pose=CombatPose(10);if(kind==1)pose=pose with{Dead=1};if(kind==3)pose=pose with{Spectator=1};Check(!aim.Tick(GunWorld(),pose,kind==0?Array.Empty<EnemyState>():new[]{CombatEnemy(10)},10,Clear).Active,"release "+kind);}});
        Test("v20 backwards wall and sample times invalidate combat",()=>
        {foreach(bool wall in new[]{true,false}){var aim=new EnemyAim(.1,CombatSettings(),1);aim.Tick(GunWorld(),CombatPose(100),new[]{CombatEnemy(100)},100,Clear);var a=aim.Tick(GunWorld(),CombatPose(wall?110:0),new[]{CombatEnemy(110)},wall?90:110,Clear);Check(!a.Active && a.Error!="","time");}});
        Test("v20 fire cone shrinks with distance and head size",()=>
        {var s=CombatSettings("god");var e=CombatEnemy() with{Origin=new(8000,0,36),AimPoint=new(8000,0,53),HeadPoint=new(8000,0,53)};var a=new EnemyAim(.1,s,1).Tick(GunWorld(),CombatPose(),new[]{e},0,Clear);Check(a.Command!.Attack && a.FireConeDeg<.03,"distant tiny cone");});
        Test("v20 burst and cooldown use exact boundaries",()=>
        {var f=new FireControl();Check(f.Tick(0,true,100,50),"start");Check(f.Tick(99,true,100,50),"held");Check(!f.Tick(100,true,100,50),"burst end");Check(!f.Tick(149,true,100,50),"cooldown");Check(f.Tick(150,true,100,50),"next");Check(!f.Tick(151,false,100,50) && !f.Firing,"lost eligibility releases");f.Reset();Check(f.Tick(0,true,100,50),"reset");});
        Test("v20 pistols and semi rifles have bounded trigger taps",()=>
        {var s=CombatSettings("god");var p=DifficultyProfile.Resolve(s);Check(p.Burst(s,17)==90 && p.Burst(s,28)==450,"semi cap");s.FireBurstMs=30;Check(p.Burst(s,17)==30,"smaller override");});
        Test("v20 teammate or another player blocks shot corridor",()=>
        {var e=CombatEnemy();foreach(int team in new[]{1,2}){var blocker=new EnemyState(3,team,new(100,0,36),new(100,0,53),100,10);Check(!FireControl.CorridorClear(new(0,0,53),e.AimPoint,new[]{e,blocker},1,2),"blocked "+team);}Check(FireControl.CorridorClear(new(0,0,53),e.AimPoint,new[]{e,e with{Index=3,Origin=new(100,50,36)}},1,2),"off axis");});
        Test("v20 friendly crossing releases integrated trigger",()=>
        {var aim=new EnemyAim(.1,CombatSettings(),1);Check(aim.Tick(GunWorld(),CombatPose(),new[]{CombatEnemy()},0,Clear).Command!.Attack,"start");var friend=new EnemyState(3,1,new(100,0,36),new(100,0,53),100,10);Check(!aim.Tick(GunWorld(),CombatPose(10),new[]{CombatEnemy(10),friend},10,Clear).Command!.Attack,"friend");});
        Test("v20 verified slot switching precedes fire",()=>
        {var aim=new EnemyAim(.1,CombatSettings(),1,true);var a=aim.Tick(GunWorld(29),CombatPose(),new[]{CombatEnemy()},0,Clear);Check(a.Command is{TapScan:0x02,Attack:false},"primary");a=aim.Tick(GunWorld(29),CombatPose(650),new[]{CombatEnemy(650)},650,Clear);Check(a.Command is{TapScan:0x03,Attack:false},"secondary");a=aim.Tick(GunWorld(29),CombatPose(1300),new[]{CombatEnemy(1300)},1300,Clear);Check(a.Command is{TapScan:0,Attack:false},"bounded");Check(new EnemyAim(.1,CombatSettings(),1,false).Tick(GunWorld(29),CombatPose(),new[]{CombatEnemy()},0,Clear).Command!.TapScan==0,"unverified binds");});
        Test("v20 God threat selection prefers observed nearby flash",()=>
        {var s=CombatSettings("god");var far=CombatEnemy() with{Origin=new(2000,0,36),HeadPoint=new(2000,0,53)};var near=CombatEnemy(id:3) with{Origin=new(-200,0,36),HeadPoint=new(-200,0,53),MuzzleFlash=true};Check(new EnemyAim(.1,s,1).Tick(GunWorld(),CombatPose(),new[]{far,near},0,Clear).Target==3,"near firing threat");});
        Test("v20 reader includes known friends only for corridor checks",()=>
        {var m=EnemyMemory();var t=m.ByteBlocks[FakeMemory.Client+WorldStateReader.TeamArray+2*104];Array.Clear(t);BitConverter.GetBytes((short)1).CopyTo(t,0);Encoding.ASCII.GetBytes("TERRORIST").CopyTo(t,2);var r=new EnemyReader(m);Check(r.TryRead(AimWorld(),MissionPose(),new(),out var e,out var why) && e.Count==0,why);Check(r.TryReadPlayers(AimWorld(),MissionPose(),new(),out e,out why) && e.Count==1 && e[0].Team==1,why);});
        Test("v20 reader estimates standing crouched and verified hull head",()=>
        {foreach(int kind in new[]{0,1,2}){var m=EnemyMemory();var b=m.ByteBlocks[0x30000000+2*EnemyReader.Stride];BitConverter.GetBytes(kind==1?1:0).CopyTo(b,EnemyReader.State+200);if(kind==2){foreach(var (off,value) in new[]{(124,-16f),(128,-16f),(132,-36f),(136,16f),(140,16f),(144,32f)})BitConverter.GetBytes(value).CopyTo(b,EnemyReader.State+off);}Check(new EnemyReader(m).TryReadPlayers(AimWorld(),MissionPose(),new(),out var e,out var why) && e.Count==1,why);Check(e[0].HeadPoint!.Value.Z==(kind==1?46:kind==2?60:64),"estimated head "+kind);}});
        foreach(string name in new[]{"easy","medium","hard","god"})
        Test("v20 W duty no Shift "+name,()=>
        {var p=new MotionPacer(DifficultyProfile.Resolve(new(){Difficulty=name}));int moving=0;for(int t=0;t<240;t+=10){var a=p.Apply(new(true,7,false,"",0,Walk:false,MouseDy:2),t);if(a.Forward)moving++;Check(!a.Walk && a.MouseDx==7 && a.MouseDy==2,"mouse preserved");}Check(name is "hard" or "god"?moving==24:moving>0 && moving<24,"duty");p.Reset();Check(p.Apply(new(true,0,false,"",0,Walk:false),1000).Forward,"reset");});
        Test("v20 damage awareness observes only HP or armor loss",()=>
        {var d=new DamageAwareness();Check(!d.Observe(100,100,0) && !d.Observe(100,100,50),"baseline");Check(d.Observe(100,90,100) && d.Observe(100,90,1299),"armor");Check(!d.Observe(100,90,1300),"expires");Check(d.Observe(90,90,1400),"hp");Check(!d.Observe(0,90,1500) && !d.Observe(100,100,1600),"death reset");});
        Test("v20 owned trigger releases on neutral and lost focus",()=>
        {foreach(bool focus in new[]{true,false}){var b=new FakeControlBackend();using var input=new WindowsControl(b,false);input.Arm();input.Apply(new(false,0,false,"",0,Walk:false,Attack:true));Check(b.ObjectiveEvents.Last().Attack,"held");b.Focused=focus;input.Apply(new(false,0,false,"",0,Walk:false));Check(!b.ObjectiveEvents.Last().Attack,"release");}});
        foreach(string mode in new[]{"easy","medium","hard","god"})
        Test("v20 closed loop aim then burst with delayed feedback "+mode,()=>
        {var s=CombatSettings(mode);var aim=new EnemyAim(.1,s,1);var e=CombatEnemy() with{Origin=new(300,100,36),AimPoint=new(300,100,48),HeadPoint=new(300,100,64)};double yaw=0,pitch=0;bool fired=false;var pending=new List<(long At,int X,int Y)>();for(int n=0;n<500;n++){long t=n*20;foreach(var x in pending.Where(x=>x.At<=t).ToArray()){yaw=PulseSteering.Normalize(yaw-x.X*.1);pitch+=x.Y*.1;pending.Remove(x);}var a=aim.Tick(GunWorld(),CombatPose(t,new((float)pitch,(float)yaw,0)),new[]{e with{ObservedAtMs=t}},t,Clear);Check(a.Error=="",a.Error);if(a.Command!.MouseDx!=0 || a.Command.MouseDy!=0)pending.Add((t+40,a.Command.MouseDx,a.Command.MouseDy));if(a.Command.Attack){Check(a.ErrorDeg<=a.FireConeDeg && pending.Count==0,"settled cone");fired=true;break;}}Check(fired,"fires "+mode);});
        Test("v20 rear turn converges with delayed actual mouse feedback",()=>
        {var s=CombatSettings("hard");s.AutoFire="off";var aim=new EnemyAim(.1,s,1);var enemy=CombatEnemy() with{Origin=new(-300,0,36),HeadPoint=new(-300,0,53),AimPoint=new(-300,0,53)};double yaw=0;var pending=new List<(long At,int X)>();for(int n=0;n<240;n++){long t=n*20;foreach(var x in pending.Where(x=>x.At<=t).ToArray()){yaw=PulseSteering.Normalize(yaw-x.X*.1);pending.Remove(x);}var a=aim.Tick(GunWorld(),CombatPose(t,new(0,(float)yaw,0)),new[]{enemy with{ObservedAtMs=t}},t,Clear);Check(a.Active && a.Error=="",a.Error);if(a.Command!.MouseDx!=0)pending.Add((t+40,a.Command.MouseDx));Check(!a.Command.Attack,"no premature fire");}Check(Math.Abs(PulseSteering.Normalize(180-yaw))<1,"rear converged "+yaw);});
    }
}
