using System.Text;
namespace CSBot;
internal static partial class ReaderTests
{
    private static byte[] PlayerEntity(int id,int message=100,float time=10,ProbeVector? origin=null)
    {
        var b=new byte[EnemyReader.HeaderSize];int state=EnemyReader.State;
        void I(int offset,int value)=>BitConverter.GetBytes(value).CopyTo(b,offset);
        I(0,id);I(4,1);I(state+4,id);I(state+12,message);BitConverter.GetBytes(time).CopyTo(b,state+8);
        var p=origin??new ProbeVector(200,100,36);BitConverter.GetBytes(p.X).CopyTo(b,state+16);BitConverter.GetBytes(p.Y).CopyTo(b,state+20);BitConverter.GetBytes(p.Z).CopyTo(b,state+24);
        I(state+40,1);BitConverter.GetBytes((short)3).CopyTo(b,state+58);return b;
    }
    private static FakeMemory EnemyMemory()
    {
        var m=WorldMemory();uint h=m.Modules["hw.dll"],c=FakeMemory.Client,root=0x30000000;
        m.ByteBlocks[h+EnemyReader.EntityCode]=EnemyReader.EntitySignature(h);m.ByteBlocks[h+EnemyReader.MaxCode]=EnemyReader.MaxSignature(h);m.ByteBlocks[h+EnemyReader.ClockCode]=EnemyReader.ClockSignature(h);
        m.UInts[c+WorldStateReader.EngineTable+53*4]=h+EnemyReader.EntityCode;m.UInts[h+EnemyReader.EntityRoot]=root;m.Ints[h+EnemyReader.EntityLimit]=1024;m.Ints[h+EnemyReader.MaxClients]=2;m.ByteBlocks[h+EnemyReader.Clock]=BitConverter.GetBytes(10.05);
        m.ByteBlocks[root+EnemyReader.Stride]=PlayerEntity(1);m.ByteBlocks[root+2*EnemyReader.Stride]=PlayerEntity(2);
        var team=new byte[18];BitConverter.GetBytes((short)2).CopyTo(team,0);Encoding.ASCII.GetBytes("CT").CopyTo(team,2);m.ByteBlocks[c+WorldStateReader.TeamArray+2*104]=team;
        return m;
    }
    private static WorldState AimWorld()=>World() with{LocalEntityIndex=1};
    private static List<byte> BuyKeys(BuyCoordinator buy,WorldState w,int money=10000)
    {var keys=new List<byte>();for(int n=0;n<200;n++){var a=buy.Tick(w,money,n*200);if(a.Command?.TapScan is >0)keys.Add(a.Command.TapScan);if(n>0 && !a.Busy)break;}return keys;}
    private static void RunV19Tests()
    {
        Test("v19 planted bomb stays planted while radar draw flag blinks",()=>
        {var m=WorldMemory(planted:true);var reader=new WorldStateReader(m);string? key=null;for(int n=0;n<20;n++){var b=m.ByteBlocks[FakeMemory.Client+WorldStateReader.BombData];BitConverter.GetBytes(n%2).CopyTo(b,16);BitConverter.GetBytes(99999-n).CopyTo(b,20);Check(reader.TryRead(0,out var w,out var e) && w.BombPlanted,e);string next=MissionPlanner.GoalKey(w);Check(key==null || key==next,"no site/post flip");key=next;}});
        Test("v19 pickup counter zero clears planted state without timer latch",()=>
        {var m=WorldMemory(planted:true);BitConverter.GetBytes(0).CopyTo(m.ByteBlocks[FakeMemory.Client+WorldStateReader.BombData],20);Check(new WorldStateReader(m).TryRead(0,out var w,out var e) && !w.BombPlanted,e);});
        Test("v19 dropped not planted bomb is not treated as planted",()=>
        {var m=WorldMemory(planted:true);BitConverter.GetBytes((short)0).CopyTo(m.ByteBlocks[FakeMemory.Client+WorldStateReader.BombData],24);Check(new WorldStateReader(m).TryRead(0,out var w,out var e) && !w.BombPlanted,e);});
        Test("v19 radar blink mutation during snapshot no longer cancels world",()=>
        {var m=WorldMemory(planted:true);uint address=FakeMemory.Client+WorldStateReader.BombData;int reads=0;m.BeforeBytes=a=>{if(a==address && ++reads==2){BitConverter.GetBytes(0).CopyTo(m.ByteBlocks[address],16);BitConverter.GetBytes(99998).CopyTo(m.ByteBlocks[address],20);}};Check(new WorldStateReader(m).TryRead(0,out var w,out var e) && w.BombPlanted,e);});
        Test("v19 logical pickup mutation still cancels world snapshot",()=>
        {var m=WorldMemory(planted:true);uint address=FakeMemory.Client+WorldStateReader.BombData;int reads=0;m.BeforeBytes=a=>{if(a==address && ++reads==2)BitConverter.GetBytes(0).CopyTo(m.ByteBlocks[address],20);};Check(!new WorldStateReader(m).TryRead(0,out _,out _),"pickup race rejected");});
        Test("v19 wrong bomb handler or invalid counter refused",()=>
        {var m=WorldMemory();m.ByteBlocks[FakeMemory.Client+BombHudProfile.DropRva][106]^=1;Check(!new WorldStateReader(m).TryRead(0,out _,out _),"profile");m=WorldMemory();BitConverter.GetBytes(-1).CopyTo(m.ByteBlocks[FakeMemory.Client+WorldStateReader.BombData],20);Check(!new WorldStateReader(m).TryRead(0,out _,out _),"counter");});
        Test("v19 buyzone icon read independently of C4",()=>
        {var m=WorldMemory(c4:false);var b=m.ByteBlocks[FakeMemory.Client+WorldStateReader.Icons];Encoding.ASCII.GetBytes("buyzone").CopyTo(b,52);BitConverter.GetBytes(33).CopyTo(b,76);Check(new WorldStateReader(m).TryRead(0,out var w,out var e) && w.InBuyZone && !w.HasC4,e);});
        Test("v19 autostart uses stable focus without F8",()=>
        {var g=new AutoStartGate(500);for(int n=0;n<10;n++)Check(!g.Observe(true,false,n*50),"wait");Check(g.Observe(true,false,500),"automatic");});
        Test("v19 focus/manual input/gap reset autostart readiness",()=>
        {foreach(int mode in new[]{0,1,2}){var g=new AutoStartGate(250);g.Observe(true,false,0);g.Observe(true,false,100);Check(!g.Observe(mode!=0,mode==1,mode==2?1000:200),"reset");Check(!g.Observe(true,false,mode==2?1050:250),"new wait");}});
        Test("v19 key pulse allowlist excludes Shift console Escape and F8",()=>
        {Check(!WindowsControl.AllowedTap(0x2A) && !WindowsControl.AllowedTap(0x36) && !WindowsControl.AllowedTap(0x42) && !WindowsControl.AllowedTap(0x29) && !WindowsControl.AllowedTap(1),"no prohibited pulses");});
        Test("v19 key pulse releases movement and does not fire",()=>
        {var b=new FakeControlBackend();using var input=new WindowsControl(b,false);input.Arm();input.Apply(new(true,0,false,"",0,Walk:false));input.Apply(new(false,0,false,"",-1,Walk:false,TapScan:0x30));Check(b.KeyEvents.SequenceEqual(new[]{true,false}) && b.Taps.SequenceEqual(new byte[]{0x30}) && b.ObjectiveEvents.Count==0,"isolated menu key");});
        Test("v19 key pulse stops on missing focus",()=>
        {var b=new FakeControlBackend();using var input=new WindowsControl(b,false);input.Arm();b.Focused=false;input.Apply(new(false,0,false,"",-1,TapScan:0x30));Check(b.Taps.Count==0,"no key outside game");});
        Test("v19 invalid key pulse is rejected",()=>
        {var b=new FakeControlBackend();using var input=new WindowsControl(b,false);input.Arm();bool refused=false;try{input.Apply(new(false,0,false,"",0,TapScan:0x2A));}catch(ArgumentException){refused=true;}Check(refused && b.Taps.Count==0,"Shift not emitted");});
        Test("v19 T and CT stock menu sequences select team rifle",()=>
        {foreach(int team in new[]{1,2}){var s=new BotSettings{BuyArmor="off",BuyAmmo="off"};var b=new BuyCoordinator(s);b.SetBindingsForTest(true);var keys=BuyKeys(b,World(team) with{InBuyZone=true});Check(keys.SequenceEqual(new byte[]{0x30,0x05,team==1?(byte)0x03:(byte)0x04,0x0B}),"rifle menu");Check(BuyKeys(b,World(team) with{InBuyZone=true}).Count==0,"once per visit/life");}});
        Test("v19 armor and ammo menu sequence respects budget",()=>
        {var b=new BuyCoordinator(new());b.SetBindingsForTest(true);var keys=BuyKeys(b,World() with{InBuyZone=true},800);Check(keys.SequenceEqual(new byte[]{0x30,0x09,0x02,0x0B,0x30,0x07,0x0B}),"650 armor then primary ammo; no unaffordable rifle");});
        Test("v19 autobuy only uses F1 and off never presses keys",()=>
        {var b=new BuyCoordinator(new(){BuyMode="autobuy"});b.SetBindingsForTest(true);Check(BuyKeys(b,World() with{InBuyZone=true}).SequenceEqual(new byte[]{0x3B}),"autobuy");b=new(new(){BuyMode="off"});b.SetBindingsForTest(true);Check(BuyKeys(b,World() with{InBuyZone=true}).Count==0,"off");});
        Test("v19 buy does not trigger outside zone or without verified bindings",()=>
        {var b=new BuyCoordinator(new());Check(!b.Tick(World() with{InBuyZone=true},10000,0).Busy,"unverified");b.SetBindingsForTest(true);Check(!b.Tick(World(),10000,0).Busy,"zone");Check(!b.Tick(World(planted:true) with{InBuyZone=true},10000,0).Busy,"planted");});
        Test("v19 interrupted menu closes and respawn allows another purchase",()=>
        {var b=new BuyCoordinator(new(){BuyArmor="off",BuyAmmo="off"});b.SetBindingsForTest(true);var w=World() with{InBuyZone=true};Check(b.Tick(w,10000,0).Command?.TapScan==0x30,"open");b.Cancel(true);Check(b.Tick(w,10000,10).Command?.TapScan==0x0B,"close after return");Check(BuyKeys(b,w).Count>0,"new life");});
        Test("v19 money unchanged is not reported as purchase success",()=>
        {var b=new BuyCoordinator(new(){BuyMode="autobuy"});b.SetBindingsForTest(true);var w=World() with{InBuyZone=true};b.Tick(w,800,0);Check(b.Tick(w,800,100).Busy,"wait");Check(b.Tick(w,800,1000).Mode.StartsWith("buy-not-confirmed"),"no success fabricated");});
        Test("v19 menu bindings checked and missing binding only disables buy",()=>
        {var c=new GameConfig{RootFile="test"};var b=new BuyCoordinator(new());b.Configure(c);Check(!b.BindingReady,"missing");foreach(var (key,value) in new[]{("b","buy"),("1","slot1"),("2","slot2"),("3","slot3"),("4","slot4"),("6","slot6"),("8","slot8"),("0","slot10")})c.Bindings[key]=value;b.Configure(c);Check(b.BindingReady,"stock");});
        Test("v19 entity profile reads fresh enemy without inventing remote HP",()=>
        {var m=EnemyMemory();Check(new EnemyReader(m).TryRead(AimWorld(),MissionPose(),new(),out var e,out var reason),reason);Check(e.Count==1 && e[0].Index==2 && e[0].Team==2 && e[0].AimPoint.Z==48,"enemy chest; remote health zero not treated as known HP");});
        Test("v19 stale dormant dead spectator hidden or wrong-index entities excluded",()=>
        {foreach(int mode in Enumerable.Range(0,7)){var m=EnemyMemory();var b=m.ByteBlocks[0x30000000+2*EnemyReader.Stride];int state=EnemyReader.State;switch(mode){case 0:BitConverter.GetBytes(99).CopyTo(b,state+12);break;case 1:BitConverter.GetBytes(9f).CopyTo(b,state+8);break;case 2:BitConverter.GetBytes((short)0).CopyTo(b,state+58);break;case 3:BitConverter.GetBytes(1).CopyTo(b,state+176);break;case 4:BitConverter.GetBytes(128).CopyTo(b,state+60);break;case 5:BitConverter.GetBytes(3).CopyTo(b,0);break;case 6:BitConverter.GetBytes(float.NaN).CopyTo(b,state+16);break;}Check(new EnemyReader(m).TryRead(AimWorld(),MissionPose(),new(),out var e,out var reason) && e.Count==0,reason);}});
        Test("v19 friendly and unknown TeamInfo never become enemies",()=>
        {foreach(short team in new short[]{0,1,2}){var m=EnemyMemory();var b=m.ByteBlocks[FakeMemory.Client+WorldStateReader.TeamArray+2*104];BitConverter.GetBytes(team).CopyTo(b,0);Array.Clear(b,2,16);Encoding.ASCII.GetBytes(team==1?"TERRORIST":team==2?"TERRORIST":"").CopyTo(b,2);Check(new EnemyReader(m).TryRead(AimWorld(),MissionPose(),new(),out var e,out var reason) && e.Count==0,reason);}});
        Test("v19 wrong entity signature or root returns unavailable not guessed targets",()=>
        {var m=EnemyMemory();m.ByteBlocks[m.Modules["hw.dll"]+EnemyReader.EntityCode][24]^=1;Check(!new EnemyReader(m).TryRead(AimWorld(),MissionPose(),new(),out var e,out _) && e.Count==0,"profile");m=EnemyMemory();m.UInts[m.Modules["hw.dll"]+EnemyReader.EntityRoot]=0;Check(!new EnemyReader(m).TryRead(AimWorld(),MissionPose(),new(),out e,out _) && e.Count==0,"root");});
        Test("v19 client frame changes during entity snapshot reject all targets",()=>
        {var m=EnemyMemory();int reads=0;uint address=0x30000000+EnemyReader.Stride;m.BeforeBytes=a=>{if(a==address && ++reads==2)BitConverter.GetBytes(101).CopyTo(m.ByteBlocks[address],EnemyReader.State+12);};Check(!new EnemyReader(m).TryRead(AimWorld(),MissionPose(),new(),out var e,out _) && e.Count==0,"frame");});
        Test("v19 enemy aim ignores walls friendly entities and outside FOV",()=>
        {var s=new BotSettings{CombatReactionMs=0,AutoFire="off",DifficultyTuning="off",RearTurn="off"};var f=new EnemyAim(.1,s,1);var enemy=new EnemyState(2,2,new(200,50,36),new(200,50,48),100,10);Check(!f.Tick(AimWorld(),MissionPose(),new[]{enemy},0,(_,_)=>false).Active,"wall");Check(!f.Tick(AimWorld(),MissionPose(),new[]{enemy with{Team=1}},10,(_,_)=>true).Active,"friend");Check(!f.Tick(AimWorld(),MissionPose(),new[]{enemy with{AimPoint=new(-200,0,48)}},20,(_,_)=>true).Active,"behind");});
        Test("v19 enemy aim steers yaw and pitch without attack or movement",()=>
        {var f=new EnemyAim(.1,new(){CombatReactionMs=0,AutoFire="off",DifficultyTuning="off",RearTurn="off"},1);var e=new EnemyState(2,2,new(200,50,36),new(200,50,70),100,10);var a=f.Tick(AimWorld(),MissionPose(),new[]{e},0,(_,_)=>true);Check(a.Active && a.Command!.MouseDx<0 && a.Command.MouseDy<0 && !a.Command.Attack && !a.Command.Forward && !a.Command.Use,"aim only");});
        Test("v19 negative m_pitch reverses only vertical enemy steering",()=>
        {var e=new EnemyState(2,2,new(200,50,36),new(200,50,70),100,10);var a=new EnemyAim(.1,new(){CombatReactionMs=0,AutoFire="off",DifficultyTuning="off",RearTurn="off"},1).Tick(AimWorld(),MissionPose(),new[]{e},0,(_,_)=>true).Command!;var b=new EnemyAim(.1,new(){CombatReactionMs=0,AutoFire="off",DifficultyTuning="off",RearTurn="off"},-1).Tick(AimWorld(),MissionPose(),new[]{e},0,(_,_)=>true).Command!;Check(a.MouseDy==-b.MouseDy && a.MouseDx==b.MouseDx,"sign");});
        Test("v19 lost target releases aim and disabled mode sends nothing",()=>
        {var s=new BotSettings{CombatReactionMs=0,AutoFire="off",DifficultyTuning="off",RearTurn="off"};var f=new EnemyAim(.1,s,1);var e=new EnemyState(2,2,new(200,50,36),new(200,50,48),100,10);Check(f.Tick(AimWorld(),MissionPose(),new[]{e},0,(_,_)=>true).Active,"acquire");Check(!f.Tick(AimWorld(),MissionPose(),Array.Empty<EnemyState>(),25,(_,_)=>true).Active,"lost");s.EnemyAim="off";Check(!f.Tick(AimWorld(),MissionPose(),new[]{e},50,(_,_)=>true).Active,"off");});
        Test("v19 aim steering converges with delayed two-axis feedback",()=>
        {var f=new EnemyAim(.1,new(){CombatReactionMs=0,AutoFire="off",DifficultyTuning="off",RearTurn="off"},1);var e=new EnemyState(2,2,new(300,100,36),new(300,100,90),100,10);double yaw=0,pitch=0;var pending=new List<(long At,int X,int Y)>();EnemyAimStep? a=null;for(int n=0;n<100;n++){long now=n*25;foreach(var item in pending.Where(x=>x.At<=now).ToArray()){yaw-=item.X*.1;pitch+=item.Y*.1;pending.Remove(item);}a=f.Tick(AimWorld(),MissionPose(angles:new((float)pitch,(float)yaw,0)),new[]{e},now,(_,_)=>true);Check(a.Error=="",a.Error);if(a.Command!.MouseDx!=0 || a.Command.MouseDy!=0)pending.Add((now+50,a.Command.MouseDx,a.Command.MouseDy));}Check(Math.Abs(yaw-18.435)<2 && pitch<-4,"converges");});
        Test("v19 new mode settings reject invalid values",()=>
        {foreach(string text in new[]{"BuyMode=console","BuyArmor=yes","EnemyAim=auto","AutoResumeMs=0","AimFovDeg=361","AimMaxStateAgeMs=10000"}){bool failed=false;try{BotSettings.Parse(text);}catch(FormatException){failed=true;}Check(failed,text);}});
        Test("v19 noShift controller uses run alignment threshold and no walk hint",()=>
        {var s=new BotSettings{RunMaxErrorDeg=8};var c=new TravelController(new[]{new ProbeVector(300,0,36)},(a,b)=>new(true,"clear",b),.1,TravelOptions.RunVerified,settings:s,noShift:true);var a=c.Tick(MissionPose(angles:new(0,12,0)),0,true);Check(!a.Forward && !a.Walk,"align before W-only running");});
        Test("v19 static visibility checks both world and brush model",()=>
        {var map=BspMap.FromBytes(SyntheticBsp());Check(map.WorldPointSegmentClear(new(1,0,0),new(2,0,0)),"world clear");Check(!map.PointSegmentClear(new(1,0,0),new(2,0,0),1),"brush blocks");});
    }
    private static byte[] FileRva(string path,uint rva,int length,out uint image)
    {
        byte[] b=File.ReadAllBytes(path);int pe=BitConverter.ToInt32(b,0x3c),optional=pe+24;image=BitConverter.ToUInt32(b,optional+28);int table=optional+BitConverter.ToUInt16(b,pe+20);
        for(int i=0;i<BitConverter.ToUInt16(b,pe+6);i++){int at=table+i*40;uint start=BitConverter.ToUInt32(b,at+12),size=BitConverter.ToUInt32(b,at+16);if(rva>=start && rva+length<=start+size)return b.AsSpan(checked((int)(BitConverter.ToUInt32(b,at+20)+rva-start)),length).ToArray();}throw new Exception("RVA not backed by supplied file");
    }
    private static void RunV19ClientFileTests(string path)
    {
        Test("v19 BombDrop/Pickup complete signature matches supplied client PE",()=>
        {var actual=FileRva(path,BombHudProfile.DropRva,183,out uint image);Check(actual.SequenceEqual(BombHudProfile.Signature(image)),"exact real handler");Check(BitConverter.ToInt32(actual,110)==1 && BitConverter.ToInt32(actual,126)==99999,"message sets blink flag and repeat counter separately");});
    }
    private static void RunV19EngineFileTests(string path)
    {
        Test("v19 entity maxclients and clock profiles match supplied engine PE",()=>
        {var b=FileRva(path,EnemyReader.EntityCode,55,out uint image);Check(b.SequenceEqual(EnemyReader.EntitySignature(image)),"real entity function");Check(FileRva(path,EnemyReader.MaxCode,12,out _).SequenceEqual(EnemyReader.MaxSignature(image)),"maxclients");Check(FileRva(path,EnemyReader.ClockCode,23,out _).SequenceEqual(EnemyReader.ClockSignature(image)),"clock");Check(BitConverter.ToUInt32(b,35)==image+EnemyReader.EntityRoot && BitConverter.ToUInt32(b,24)==image+EnemyReader.EntityLimit,"independent root/count operands");});
        Test("v19 real engine copies current state origin to rendered origin",()=>
        {var b=FileRva(path,0x1EE0C,24,out _);Check(b.AsSpan(0,6).SequenceEqual(Convert.FromHexString("8b8ec0020000")) && b.AsSpan(18,6).SequenceEqual(Convert.FromHexString("898e480b0000")),"curstate origin offset 0x2c0 confirmed by engine");});
    }
}
