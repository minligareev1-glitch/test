# v21 validation — current version

- Linux x64, .NET SDK 8.0.408. Release main/test builds with `-warnaserror`: zero warnings/errors.
- **324 self-contained tests; 346 with supplied de_dust2 BSP; separate client.dll run 326; separate hw.dll run 327.** Independent runs, not cumulative or live-game tests.
- 27 new self-contained cases: Maps-source multiple-pair discovery without registry; unchanged registry not rewritten; graph/BSP revalidation and fingerprint updates; missing graph and graph-only files; isolated corrupt graph/BSP; missing bomb zones, clip hulls, solid-node and dynamic brush rejection; invalid names, nonrecursive scanning and mixed-case matching; ambiguous case pairs on case-sensitive filesystem; three malformed/null/invalid-entry registry preservation cases; retention of unrelated entries; strict load until validated registration; no fallback map; retained single-map and new all-map CLI; missing Maps no writes; quoted raw/hex/address/state invalid-level diagnostics.
- One new supplied-BSP integration test registers the actual de_dust2 pair from a fresh temporary Maps/Navigation layout, loads it with strict checks and verifies the next scan reports unchanged. The existing 21 BSP additions remain. Temporary synthetic graph bytes test registration mechanics, not authorship or in-game movement.
- Actual main CLI `--register-maps /asset/root` executed offline against shipped pair: found=1, unchanged=1, skipped=0, errors=0. Actual `--check-settings` succeeds with 101 settings and default medium. These CLI paths do not attach to the game or send input.
- AutoMissionCli startup wiring is compiled and inspected: registration happens before process attachment/input. The whole Windows supervisor/native SendInput is **not** executed here. Actual focus/death, bots, bullets/hits/headshots, C4 and arbitrary-map traversal remain unverified.
- At user request the original uploaded de_dust2.bsp is now bundled (SHA256 15945389528d113562ede0a2c80647ebfa799079ed1c05a25379bcf84e4e9286). No other BSP, proprietary DLL, uploaded config or user log is bundled. Existing graph license/attribution preserved separately; no claim it covers the BSP.
- Archive QA: ZIP CRC and source manifest hashes checked, clean-extraction Release main/test builds and actual-BSP suite rerun. SHA256SUMS excludes itself and generated build outputs. Bundled BSP hash checked independently against original upload.
- Invalid-level raw diagnostics improve evidence only; the earlier reported Invalid level name is not claimed fixed without its actual raw bytes. No BSP-free mode, graph generator, live directory watcher or support for every map mechanic is claimed.

Reproduce from project root:
```sh
dotnet build CSBot.sln -c Release -warnaserror
dotnet build Tests/CSBot.ReaderTests.csproj -c Release -warnaserror
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll --bsp Maps/de_dust2.bsp
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll --client /path/to/client.dll
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll --engine /path/to/hw.dll
dotnet run --project CSBot/CSBot.csproj -c Release -- --register-maps .
dotnet run --project CSBot/CSBot.csproj -c Release -- --check-settings config.txt
```
Optional test flags are separate invocations. `register-maps.cmd` is an offline Windows convenience wrapper; scripts were not executed in Windows here. AUTO scans once per launch, including preview; no manual register command is required for normal operation. Restart after changing assets.

## Historical results below

# v20 validation — historical version

- Environment: Linux x64, .NET SDK 8.0.408. Main solution and test project built Release with `-warnaserror`: zero warnings/errors.
- **297 self-contained tests; 318 with the supplied de_dust2 BSP; separate client.dll run 299; separate hw.dll run 300.** These are independent runs, not cumulative live tests.
- 50 new self-contained test cases: all difficulty profiles and bounds, tuning on/off and 101-field config; body/head selection and God no fallback; exact rear 180°, rear off/radius, God all-angle elevated target, yaw wrap; reaction/stability/target-switch timing and hard damage response; fresh/frozen/future/missing snapshots; firearm allowlist; pending mouse prevents fire; AutoFire off; unknown teams, friendly and walls; death/lost target/disabled/time rollback; distance-based head cone; bounded bursts/rest/semiauto taps; conservative friendly/other-player shot corridor and release on crossing; checked primary/secondary taps; observed close muzzleflash priority; read known allies; head estimate and crouch/bounds fallback; W duty for four modes without changing mouse; HP/armor damage timing; fake owned trigger release on neutral/focus loss; delayed-feedback aim-to-fire convergence for all four modes and rear-turn convergence.
- Existing v19 fixture that previously rejected AimFovDeg=360 now rejects 361, since 360 is intentionally supported. Historical aim-only tests explicitly disable auto-fire/reaction/rear extension so they still test the old operation, rather than accidentally exercising defaults for new combat.
- Main CLI `--check-settings` invoked for each of easy/medium/hard/god: all four report effective profile settings and valid configuration without opening process/input. Source-linked tests also apply and validate all profiles. Solution build uses x64 output subdirectory; test project uses normal Release/net8.0 output.
- Existing 21 BSP additions exercise navigation, static geometry and checked post-plant positions; new rear/aim/fire tests use deterministic fake feedback and visibility callbacks, not live targets. Supplied client/engine files are checked as PE data, never executed. Proprietary BSP/DLL, uploaded game CFG and logs are not redistributed.
- Latest supplied v19 log reports `enemy-aim ... no autofire`, BUY HUD money/weapon changes and later respawn waiting. It supports the need to add fire, not a claim that v20 fire was tested in-game.
- **NOT executed here:** hl.exe/CS 1.6, native Windows SendInput, batch scripts in Windows, end-to-end supervisor, live entity availability, actual bullets/hits/kills, stock menu delivery, death/respawn and C4 success. Head points are approximate bounds-based estimates, not bone/hitbox verification. No all-threat, zero-latency, friendly-fire-free or guaranteed-headshot claim. Ammo/reload/recoil/scope/actual damage telemetry is not implemented.
- Archive QA: ZIP CRC, source hashes and clean-extraction Release builds plus supplied-BSP test run. `SHA256SUMS.txt` excludes itself, generated build outputs and user files.

Reproduce from project root:
```sh
dotnet build CSBot.sln -c Release -warnaserror
dotnet build Tests/CSBot.ReaderTests.csproj -c Release -warnaserror
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll --bsp /path/to/de_dust2.bsp
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll --client /path/to/client.dll
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll --engine /path/to/hw.dll
dotnet run --project CSBot/CSBot.csproj -c Release -- --check-settings config.txt
```
Optional test flags are separate invocations. `run-auto-bot.cmd` executes automatically on Windows after foreground/fresh-state checks. Use `run-state-preview.cmd` for inspection without input.

## Historical results below

# v19 validation — historical version

- .NET SDK 8.0.408, Linux x64; Release main/test builds with -warnaserror: zero warnings/errors.
- **247 autonomous tests; 268 with supplied de_dust2 BSP; separate client.dll run 249; separate hw.dll run 250.** Counts are independent, not cumulative live tests.
- 33 new autonomous cases: planted HUD stable under alternating radar display flag and display-count decrement; real pickup clears without a time latch; dropped C4 not planted; draw-only snapshot mutation accepted while logical mutation refused; handler/counter validation; buyzone icon; automatic focus readiness and reset; tap allowlist/no Shift/F8/console, focus and release behavior; T/CT rifle menus, armor/ammo budgets, autobuy/off, missing zone/binds, interrupted menu and repeated life, no fabricated purchase success; checked enemy snapshots, stale/dormant/hidden/spectator/invalid/friendly exclusion, signature/root/frame rejection; visibility/FOV filtering, two-axis enemy steering without attack, m_pitch sign, target loss, delayed-feedback convergence; settings bounds; W-only alignment and world+brush visibility.
- Existing CFG Shift-unbind regression intentionally changed: Shift no longer required. Remaining old reader/movement/input/BSP tests preserved. Fake world fixture now includes the real BombDrop display counter and exact handler signature; artificial enemy fixtures test the proposed checked runtime layout, not live opponents.
- Real supplied client PE: existing fingerprint/TeamInfo tests plus full 183-byte BombDrop/Pickup signature, separate display flag and repeat-counter writes confirmed.
- Real supplied engine PE: existing fingerprint/map profile plus exact GetEntityByIndex (55), GetMaxClients (12), GetClientTime (23) bytes; pointer/count operands; actual curstate XYZ read at 0x2C0 copied to render origin at 0xB48. Read as data, not executed.
- Existing 21 BSP integration additions/legacy map tests exercise v18 navigation. New point visibility world+brush helper tested on synthetic partition; real enemy visibility, current packet semantics and aim still require in-game verification.
- User log demonstrates goal thrashing site/post-plant and later a watchdog/focus stop, not proof of which watchdog condition fired. Static supplied-client drawing code proves +16 toggles; it cannot be used as persistent planted flag. v19 fixes interpretation instead of indefinitely latching old C4 state or disabling input safety.
- Main Windows supervisor, native SendInput, .cmd, stock buy menus, actual money/item delivery, C4 success and live targeting have **NOT** been executed here. Unit fake input cannot establish native key delivery; PE signatures cannot establish live net-state availability. No live traversal/buy/combat success claim.

Reproduce:
```sh
dotnet build CSBot.sln -c Release -warnaserror
dotnet build Tests/CSBot.ReaderTests.csproj -c Release -warnaserror
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll --bsp /path/to/de_dust2.bsp
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll --client /path/to/client.dll
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll --engine /path/to/hw.dll
```
Optional flags are separate invocations. Proprietary files/user logs not bundled. Archive hashes in SHA256SUMS.txt exclude the manifest itself. New default run-auto-bot.cmd executes automatically; use run-state-preview.cmd when only inspecting sensors.

## Historical results below

# v18 validation — historical version

- Linux x64 .NET SDK 8.0.408; main and test Release builds with `-warnaserror`: zero warnings/errors.
- **214 self-contained tests; 235 with supplied de_dust2 BSP**. Independent `--client` and `--engine` runs: **215** each. Counts are separate runs, not cumulative live-game tests.
- 25 new self-contained cases: death/spectator waiting, fresh respawn frames, stale time/gap/frozen/invalid/context/teleport resets, repeated respawn; neutral key release without rearming and focus fault refusal; plan epoch/context/pose rejection; directed weighted multi-goal field, allowed nodes, temporary penalties, invalid costs and cancellation; checked farthest lookahead and bounded checks, safe simplification/refusal, adaptive controller; planted T navigation/off; cover hold/relocate/patrol/reset; new settings bounds.
- Six new BSP integration cases: one-time graph preparation, T/CT both zones, uploaded corner pose, CT exact bomb approach, reachable cover/patrol and relocation, repeat cached planning. Every returned segment independently checked with another WalkGeometry instance. Both requested cover and patrol were available in the selected site-A scenario; this is not proof for all map positions.
- Offline measured example: cold build 693.1 ms, 5500 directed standing edges; cached full site routes 11.21–11.81 ms; cover/patrol 1.05–10.53 ms. CPU timings include local runtime conditions, not Windows/game latency guarantees.
- Existing GetLevelName and TeamInfo real-file PE checks preserved unchanged. DLLs read as data, never executed. Old LifeEvidence regression tests remain for history; AUTO now uses RespawnLifecycle.
- Main Windows supervisor is compiled, **not executed end-to-end** here. Helpers and fake backend are unit-tested; actual focus transitions, death/respawn, SendInput delivery, HUD bomb validity, movement and post-plant tactics require local game testing. Static standing-hull checks do not prove full GoldSrc physics or account for players/dynamic obstacles.

Reproduce from the project root:
```sh
dotnet build CSBot.sln -c Release -warnaserror
dotnet build Tests/CSBot.ReaderTests.csproj -c Release -warnaserror
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll --bsp /path/to/de_dust2.bsp
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll --client /path/to/client.dll
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll --engine /path/to/hw.dll
```
Optional flags are separate invocations. Proprietary BSP/DLL/user logs are not bundled. Archive source list is hashed in SHA256SUMS.txt; excludes the hash file itself.

## Historical results below

# v17 validation — historical version

- Release main/test builds with -warnaserror: zero warnings/errors, Linux x64 .NET 8.0.408.
- **189 self-contained tests; 204 with the supplied BSP**. Separate `--client supplied-client.dll` run has **190** tests (one additional real-PE check); `--engine supplied-hw.dll` also has **190**. Optional flags are separate runs.
- 12 new TeamInfo regressions: legacy getter=0 while active T; explicit CT and T without C4; legacy conflicts ignored; unknown/spectator never inferred from C4; numeric/text disagreement rejected; no adjacent-row fallback; index31->entity32; full handler signature corruption; name changes during snapshot; unreadable/unterminated/control-containing name; diagnostic legacy read optional; active TeamInfo chooses plant/defuse FSM branch.
- Static supplied-client PE test: exact fingerprint, section-based RVA resolution; 99-byte handler equals relocatable signature; literals CT/TERRORIST and virtual TeamInfo slot target checked; old getter's separate address confirmed; every relocated operand checked against independently stated RVAs.
- Existing map reader, route, objectives, timing, sample, input-release and BSP tests preserved. Fake world fixture now uses actual TeamInfo number/name and legacy zero, rather than populating the obsolete field with the desired answer.
- Uploaded logs confirm v16 reads map=de_dust2 and loads expected BSP/graph. They do NOT yet confirm v17 TeamInfo values or live planting/defusing/input success. No game executed here.

Reproduce:
```sh
dotnet build CSBot.sln -c Release -warnaserror
dotnet build Tests/CSBot.ReaderTests.csproj -c Release -warnaserror
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll --bsp /path/to/de_dust2.bsp
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll --client /path/to/client.dll
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll --engine /path/to/hw.dll
```
BSP, DLL and uploaded logs are not bundled. Start state-preview and compare team with the real scoreboard before execution.

## Historical results below

# v16 validation — historical version

- Clean Release main/test builds with -warnaserror: zero warnings/errors, .NET 8.0.408 on Linux x64.
- **177 self-contained tests; 192 with supplied BSP**. Independently running `--engine supplied-hw.dll` gives **178 tests**, including one check against actual PE bytes. Counts are separate runs, not 192 live tests.
- 14 new synthetic regressions: exact logged FF1508C9AA04 prefix at relocated function; different module bases; signed readiness branch; no stale map below state3; unreadable state; full-signature corruption; rejecting unrelated FF15; truncated code/buffer; exact 40-byte name reads; connection/callback changes; other map names; malformed map text; module bounds.
- Static supplied-PE regression: exact DLL SHA256, section-based RVA-to-file mapping, complete 27-byte function at RVA19950 equals the expected profile at preferred base, rebasing all four address operands reproduces the reported runtime prefix. No game code execution.
- Existing 163 self-contained / 178 BSP tests preserved. No edits to objectives, input ownership, route mechanics or pause/retry policy.
- Not live-tested: actual map reads after this patch, Windows SendInput, CT bomb-message delivery, plant/defuse success. Start state-preview; do not interpret static/buffer tests as successful game traversal.

Reproduce (in project root):
```sh
dotnet build CSBot.sln -c Release -warnaserror
dotnet build Tests/CSBot.ReaderTests.csproj -c Release -warnaserror
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll --bsp /path/to/de_dust2.bsp
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll --engine /path/to/hw.dll
```
The optional --bsp / --engine arguments are separate invocations. Proprietary BSP and DLL not bundled.

## Historical results below

# v15 validation — historical version

- Release main and test builds with -warnaserror: zero warnings / errors (Linux .NET SDK 8.0.408, x64).
- **163 self-contained tests; 178 with user-supplied de_dust2.bsp** (15 BSP integration tests). Earlier graph, CFG, movement, feedback, landing and input regressions preserved.
- New fake-memory tests: map-name normalization / path traversal; B8, A1 and E9 map return stubs; engine address bounds; checked team-code signature; team, C4 icon flash, weapon ID6 and planted HUD coordinates; invalid icon/bomb/weapon states; non-atomic icon/weapon changes rejected. These tests reproduce the implementation's proposed layout, not a running game.
- Pure FSM tests: T prerequisites, rate-limited selection and active-weapon acknowledgement; bounded plant hold; CT range/line/ground prerequisites, yaw/pitch convergence before E, inverted pitch; bounded use hold and no timer-based success; horizon feedback maintained across navigation ticks; objectives disabled.
- Fake input tests: attack/use released on neutral, focus, watchdog, stop, disposal and finished; partial objective failure releases; releasing W does not interrupt held E; two-axis input. No real user32 was invoked.
- Life evidence tests: alive context before death; two advancing death snapshots; stale zeroes and changed map context not terminal evidence.
- Added real-BSP integration: T live-origin mission to a zone; CT approach to a synthetic planted C4 position with every hull edge checked; map catalog loading and rejecting unknown/hash-mismatched files.
- New supervisor code reviewed for neutral waiting / stale-plan rejection / unlimited retry / adaptive calibrated pulse cap. Complete Windows supervisor loop, .cmd execution, real SendInput and in-game memory/HUD protocol **not tested here**.
- New map/team/objective addresses derived statically from the supplied DLL files. GetLevelName runtime callback stub still requires in-game preview verification. CT availability/clearing semantics of BombDrop are not proven by synthetic tests.
- No live traversal, planting or defusing success claimed. Static hull checks do not establish full GoldSrc physical traversability; other players/dynamic obstacles are not modeled.

Reproduce:
```sh
dotnet build CSBot.sln -c Release -warnaserror
dotnet build Tests/CSBot.ReaderTests.csproj -c Release -warnaserror
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll
dotnet Tests/bin/Release/net8.0/CSBot.ReaderTests.dll --bsp /path/to/de_dust2.bsp
```

## Historical validation below — older modes/versions, not AUTO policy

# v14 validation

## Builds and test scope

- Main / test project clean Release builds with -warnaserror: zero warnings/errors.
- 132 self-contained tests; 144 with supplied de_dust2 BSP (12 additional integration tests).
- Prior fake-memory, numeric/CFG, graph, BSP, pulse-feedback and guard regressions preserved.
- Pure input backend tests verify forward and mouse in same update, walk/run transitions without releasing forward between modes, managed release and watchdog faults. Real user32 is NOT invoked.
- Combined controller: running on clear straight, walk-only profile, heading-clearance refusal / finite brake wait, lateral-margin requirement, sharp-corner slow mode, checked straight lookahead.
- Supported-air grace: external floor evidence required; deadline 120ms. Exact frametime failure is logged separately.
- Synthetic heading forecasts reject walls / missing floor. Old standing-hull, floor/step/drop/corridor tests retained.
- Fast pulse tests converge on delayed constant and count-dependent response models. No claim that those models reproduce Windows pointer acceleration exactly.
- Idealized kinematic trip: cautious 17575ms, combined 4875ms, 28 updates with both forward and mouse. This is a test-only simulation, NOT a CS1.6 benchmark and NOT evidence of in-game traversal success.
- Actual BSP: preview/route checks, user-position anchor regression, standing support at T spawn, geometry-permitted combined input near T spawn, both-site routes.

## Code behavior / safety scope

- CLI default motion=balanced; legacy constructor tests default to cautious unless options explicitly supplied.
- Small corrections can retain W; balanced releases owned Shift for ordinary in-game running only with heading / side clearance and route restrictions.
- Calibrated fast pulses use shorter settle windows; initial pulse still conservative; no overlapping unobserved pulse stream.
- High yaw error / calibration wait / unsafe heading can still require stationary turning.
- Sample/read/focus/death/watchdog stops retained. No input in preview. F8 and explicit execution/local-session confirmation still required.
- Ground grace is restricted to BSP-supported <=8-unit gaps / |Vz|<=100, <=120ms, no forward/mouse commands during it. Not airborne navigation.
- Stopping distance is a heuristic, not a physical guarantee. No dynamic player/brush state, map/team/UI automatic recognition.

## Not tested here

Actual Windows SendInput delivery, real timer scheduling under load, actual live memory/prediction stability, braking/corners/slopes and full CS1.6 traversal. Batch scripts reviewed but not executed on Windows. No game assets were run.

## Uploaded-log regressions in v11

- First log: no observed yaw response after a single mouse packet; movement continued. This identifies the controller stop condition, not the underlying Windows/game input failure.
- Fast modes now brake after 250ms missing response, retry only after >=450ms and speed <=10, at most two same-direction <=8-count packets. Remain braked until observed response. Missing response after budget, or inability to brake within deadline, stops. Cautious behavior is unchanged.
- Added tests: dropped initial packet recovery, permanent failure bounded to 3 total packets, no retry at speed, controller releasing W while waiting. Existing delayed/variable gain and cautious no-response tests retained.
- Actual BSP reproduces second log pose (655.812,643.250,36.03125): heading 89.3903 blocked, desired 90.4219 clear, direct route clear. Old 1.5-degree deadband prevented steering. Conditional 0.2-degree deadband sends correction. A synthetic yaw-feedback sequence at this fixed BSP pose permits forward only when actual heading forecast becomes clear.
- This regression is not an in-game traversal, full-route playback, or physical character simulation. Does not establish that all corners are passable.
- v11 had no live replanning. v12 adds the opt-in recovery described below. No dynamic obstacle avoidance, random strafing, jumping, or restart after a safety STOP.

Uploaded logs and proprietary game files are not bundled.

## v12 recovery

- Explicit --recovery replan, enabled by run-live-recover.cmd. Normal run-live-walk remains stop-on-error. CLI --recovery-limit 0 means continuous selected-failure recovery; positive 1..1000 limits total attempts. Internal test constructor uses a finite default, CLI explicitly passes its selected limit.
- Allowlist: rejected path, blocked heading, stuck, no mouse response, turn timeout. Other failures retain terminal behavior.
- Immediately neutral input, then floor support / speed <=10 / 400ms stable position. Background planner has its own mutable geometry/navigation caches; shared graph/map are read-only. Main loop keeps all read/focus/death/watchdog checks running. No key/mouse writes in the worker.
- Poll task rather than blocking; reject >2-unit displacement, validate latest live attachment before resume, reinitialize pulse calibration. No-route results retry; unlimited mode delays subsequent attempts >=2s. Max 10s per attempt; planner exception/timeout terminal.
- Recovery route snapshot replaces live-plan.json only after successful revalidation, marked recovered=true / armed=true. Initial pre-arm snapshot remains armed=false until recovery.
- 10 additional autonomous tests: allowlist, brake/stability/actual origin, pending worker/timeout, finite budget, budget across resumes, stale plan rejection, floor reset, planner exception, neutral key release, continuous no-route retries with backoff.
- Additional supplied-BSP test from last logged pre-stop pose (56.519,-540.630,36.03125): safe route found via anchor 521, 41 nodes; every segment rechecked by standing hull. Exact final stop pose was not in uploaded log. This is an offline route check, not a game traversal or a real Windows async/watchdog integration test.

## v13 checked step landing pause

- Uploaded v12 log confirms recovery=replan / walk. Final stop is sample guard onGround=-1, velocity=(0.919,130.001,-4), position=(177.634,-31.223,52.031). BSP floor at this XY is ~36.04: ~15.99 units below, outside the old 8-unit grace.
- New policy is seeded only on the verified F8 arming pose and observed while armed in combined replan mode. Recently verified grounded state (<250ms), <=18.1 total drop from takeoff height, <=2-unit upward displacement, Vz [-180,1], speed <=290, <=500ms airborne. Ground flag alone cannot terminate policy without static support; landing also checks time/height.
- Geometry verifies horizontal current-height hull trace and sampled floor corridor over 0.25s of velocity, max72.5 units, current/projection support <=18.1, slope through SnapToFloor, total drop from fixed takeoff height, walkable floor between samples. Conservative heuristic, not exact game physics.
- CLI emits only neutral input while waiting; on grounded landing, enters existing recovery and resets controller/calibration when new route accepted. Guard's default120ms remains unchanged; only externally checked step pause requests500ms. Read freshness250ms, death/context/focus/watchdog remain active.
- 8 new autonomous tests: recent takeoff evidence; total time bound; jump/high fall rejection; cumulative drop; ground support/late landing; geometry gap/wall/deep fall and valid16-unit descent; freshness/death preservation under extended grace; one-shot landing completion.
- One extra actual-BSP regression uses exact last grounded/first airborne positions from uploaded log, then synthetic falling samples to a supported lower floor. Every airborne sample passes geometry/guard, landing permits safe route planning. Synthetic sequence is NOT a recorded full descent and NOT evidence of in-game success.
- Main and tests build Release -warnaserror with zero warnings/errors. No real user32, Windows timers or in-game movement tested here.

## v14 configuration and steering scope

- 55 bounded typed parameters in root config.txt, comments and ranges; legacy values in Examples/config-legacy.txt. --settings FILE loaded before process/input creation. --check-settings runs without any game/process/input access. Explicit CLI motion/dpc/recovery-limit override file values. Batch scripts pass settings path but no longer override Motion when arg4 absent.
- Strict parser: BOM/comments, case-insensitive keys, dot/comma decimals; rejects unknown/duplicate keys, non-finite/fractional-int/out-of-range values and incompatible timings/limits. Report all settings and effective overrides in log, include settings snapshot in plan JSON. No live file reload.
- Shipped profile differs from conservative constructor defaults: loop15ms, turn cap16deg, near cap6deg, error fraction0.8, measured settle40ms/quiet20ms. First pulse <=8 counts and sign/gain/abrupt-response guards unchanged. These are candidate tuning values, NOT measured in-game performance.
- RunVerified profile prefers ordinary W/noShift with error/heading/momentum/side clearance, bypasses only balanced long-flat-straight eligibility, not geometry checks. Walk remains deliberate Shift; actual speed is game/weapon-dependent.
- Controller resets steering budget/reversal/cap on changed target index, preserving pending pulse validation and learned gain. Distinct pulse-budget (recoverable) and reversal (terminal) diagnostics. Old uploaded generic error cannot by itself distinguish the two causes.
- 15 new autonomous tests: shipped parse/report; human syntax; invalid/unsafe values; coupled values; configured mouse behavior; pending feedback survives reset; actual controller waypoint-budget scope; same-target finite budget/recovery policy; separate reversal limit; preferred-run safety; run threshold/probe settings; progress/focus; tightened landing bounds; recovery stabilization; shipped accelerated feedback convergence with delayed constant/count-dependent gain.
- Prior 129 tests retained with legacy constructor defaults, plus new shipped-profile tests. Main/test builds Release -warnaserror, zero warnings/errors. Config checker executed on sandbox without game.
- No live Windows/input performance test; no guarantee all settings combinations reproduce safe physical game traversal. Script invocation reviewed, not executed on Windows.
