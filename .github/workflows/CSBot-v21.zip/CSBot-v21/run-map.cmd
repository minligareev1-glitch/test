@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>&1
if errorlevel 1 (
  echo Install .NET 8 SDK first. See README.md.
  pause
  exit /b 1
)
set "BSP=Maps\de_dust2.bsp"
if not "%~1"=="" set "BSP=%~1"
if not exist "%BSP%" (
  echo Copy your de_dust2.bsp to Maps\de_dust2.bsp
  echo Or run: run-map.cmd "C:\path\to\cstrike\maps\de_dust2.bsp"
  pause
  exit /b 2
)
dotnet run --project "CSBot\CSBot.csproj" -c Release -- --map-check "Navigation\de_dust2.graph" "%BSP%" --json "map-check.json" > "map-report.log" 2>&1
if errorlevel 1 goto failed
rem EXAMPLE coordinates from earlier movement log. NOT live player coordinates.
dotnet run --project "CSBot\CSBot.csproj" -c Release -- --map-route "Navigation\de_dust2.graph" "%BSP%" -832 -704 164.031 a --team t --json "route-t-a.json" >> "map-report.log" 2>&1
if errorlevel 1 goto failed
dotnet run --project "CSBot\CSBot.csproj" -c Release -- --map-route "Navigation\de_dust2.graph" "%BSP%" -832 -704 164.031 b --team t --json "route-t-b.json" >> "map-report.log" 2>&1
if errorlevel 1 goto failed
type "map-report.log"
echo.
echo DRY RUN only. No keyboard or mouse input. See README.md for limits.
pause
exit /b 0
:failed
type "map-report.log"
pause
exit /b 1
