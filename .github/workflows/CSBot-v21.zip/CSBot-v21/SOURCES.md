# Основания для профиля v4

1. Присланный пользователем client.dll: экспортированные функции и статически
   прослеженные обращения. SHA-256 и фрагменты указаны в STATIC_ANALYSIS.md.
2. Присланный пользователем hw.dll: проверены PE32-заголовки, секции и размер образа;
   новый указатель взят из client.dll.
3. Valve Half-Life SDK, playermove_s:
   https://github.com/ValveSoftware/halflife/blob/master/pm_shared/pm_defs.h
4. Valve Half-Life SDK, ref_params_s (для различия origin симуляции и камеры):
   https://github.com/ValveSoftware/halflife/blob/master/common/ref_params.h

SDK использован для сопоставления типов и смещений. Сам SDK-код и DLL игры в
архив не включены. Это не универсальный профиль всех сборок GoldSrc.

Ранее проверенные и отвергнутые кандидаты View происходили из:
https://github.com/KleskBY/CS-1.6-External-cheat
Они оставлены лишь как опциональная диагностика старого режима, не как позиция.

# Дополнения v5

YaPB graph definitions (Path, PathLink, StorageHeader):
https://github.com/yapb/yapb/blob/master/inc/graph.h
Storage loader and ULZ usage:
https://github.com/yapb/yapb/blob/master/inc/storage.h
https://github.com/yapb/yapb/blob/master/src/storage.cpp
ULZ reference implementation (Unlicense):
https://github.com/yapb/ystl/blob/master/ystl/ulz.h
YaPB graph database licensing:
https://github.com/yapb/graph/blob/master/README.md
https://github.com/yapb/graph/blob/master/LICENSE-GRAPH

В отличие от программного кода YaPB, данные базы graph в текущем репозитории
распространяются по CC BY-SA 4.0. Условия и атрибуция включены отдельно.

## v6: BSP / goals

- Valve GoldSrc BSP v30 structures (reference only; implementation written independently):
  https://github.com/ValveSoftware/halflife/blob/master/utils/common/bspfile.h
- `de_dust2.bsp`, supplied by user: 2057288 bytes;
  SHA256 `15945389528d113562ede0a2c80647ebfa799079ed1c05a25379bcf84e4e9286`.
  Used for offline verification only; not redistributed in this archive.
- `nav-report.log`, supplied by user: confirms v5 CLI successfully loaded the graph and wrote its 0→66 route. This log does not test live movement.
- A/B labels grounded in the map entity keys `target=tgt_a` and `target=tgt_b`.
  Exact trigger volume membership tested against brush submodel hull 0 after bounds check.

## v7: standing hull / live movement

- GoldSrc BSP clipnodes and per-model hull heads, reference structures (independent C# implementation):
  https://github.com/ValveSoftware/halflife/blob/master/utils/common/bspfile.h
- Movement, step traces, grounded state and slope-normal reference:
  https://github.com/ValveSoftware/halflife/blob/master/pm_shared/pm_shared.c
- GoldSrc state flags (`FL_DUCKING`, `FL_FROZEN`):
  https://github.com/ValveSoftware/halflife/blob/master/common/const.h
- Supplied DLL fingerprints / PM_Move+PM_Init instruction evidence: see STATIC_ANALYSIS.md and MOVEMENT_READER.md.
- Windows INPUT layout / SendInput implemented through P/Invoke. Only PROCESS_VM_READ/QUERY requested from the game process; no remote writes, code calls or injection.
- No live server/map/team-state address is asserted known. Live mode requires manual local de_dust2 confirmation; JSON leaves liveMapVerified=false.
- Nav graph unchanged from v5; v7 walk examples are derived CC BY-SA 4.0 waypoint-route data.

## v8 CFG fix

Attached config.cfg inspected only for mouse settings, W/Shift bindings and exec directives.
Nominal sensitivity*m_yaw = 3.23*.022 = .07106. userconfig.cfg was not attached, so its overrides are unknown.
Parser is read-only; original config.cfg, identifiers and unrelated config values are not bundled.

## v9 user regression

User-supplied live-preview.log, live-walk.log and live-plan.json: rear attachment anchor 919; position (-816.8281,-789.4453,164.03125); steady position with yaw near -4.73/+9.27 and alternating mouse commands; managed stop at turn timeout.
The uploaded logs/plan are not bundled; derived standalone waypoint example is included without process/user identifiers.

## v10 combined motion

User-supplied v9 live-walk.log: frequent stationary settling/pulse phases, all forward commands walk-only, final combined ground/frame guard reason. Exact last failing fields were not logged, so final ground-vs-frametime cause remains unknown.
Updated behavior is implemented in TravelOptions / TravelController / PulseSteering / WindowsControl / WalkGeometry; no external movement or input-bypass code added.
Uploaded logs/plan and game files not redistributed. Simulated timings in tests are not live CS performance measurements.

## v12 guarded recovery
Original C# state machine, allowlisted navigation failures, background planning from live origin; no new external code or assets. User logs inform regressions but are not bundled.

## v13 step-descent pause
Original C# bounded passive-landing state machine and BSP corridor checks, informed by supplied onGround=-1 log and supplied BSP. No new external code or assets.

## v14 tuning
Original typed config parser, controller parameter wiring and segment-scoped steering bookkeeping. No new external code or assets. Root config.txt is a newly generated bot settings file, not an uploaded game config.


## v15 AUTO and objective profile

Original C# read-only world sensor, map registry, mission planner, objective FSM, persistent supervisor and owned-input extensions; no third-party cheat or injected-bot code copied. Static evidence from supplied client.dll/hw.dll and official HLSDK APIProxy.h/cdll_int.h (links in STATIC_ANALYSIS.md). Supplied v14 live-walk.log ends with a 31.83-degree yaw response after a -119-count packet and the old 30-degree feedback stop. New recovery policy resets feedback and reduces the calibrated packet cap; this is not proof of corrected real mouse delivery.

No additional nav assets, game binaries, uploaded CFG or logs redistributed. Root config.txt is newly generated bot tuning. Auto-generated route JSON is derived navigation data; see CC BY-SA attribution for graph-based examples. Earlier sections describe their version only; v15 AUTO adds experimental map/team/HUD fields and no longer uses the old terminal-failure allowlist.


## v16 GetLevelName correction

Only supplied hw.dll and the user's exact reported address/prefix were needed; no new external source/code downloaded. RVA19950 full function and level-buffer writes were inspected as PE data. Tests independently map the actual PE function and check its rebased bytes; DLL is never executed or included in the source archive. This supersedes v15's unsupported-stub limitation for the exact supplied build; unknown profiles remain a neutral wait.


## v17 TeamInfo correction

User-supplied auto-bot.log/world-state.log establish successful map read and expected BSP/graph load, with persistent team=0 preventing arming. Static analysis of the supplied client.dll traced registered TeamInfo wrapper, viewport virtual slot and actual string/numeric writes to a field distinct from the old HUD_GetPlayerTeam export. Independent PE tests cover actual bytes, literals and operands; original C# world reader now uses that field with number/name consistency checks. No external code or new assets downloaded; no DLL execution. Uploaded logs and proprietary binaries not redistributed.

## v19 read-only profiles and layout

- Supplied client.dll: BombDrop/Pickup code RVA50FB0, radar draw RVA4D301..4D37B; display phase at +16 differs from message type +24 and display counter +20. Code inspected as bytes/disassembly, never executed. Full profile validated in offline PE tests.
- Supplied hw.dll: GetEntityByIndex RVA19590 / GetMaxClients RVA19460 / GetClientTime RVA195D0; current-state origin copy RVA1EE0C. Profiles fail closed; no calls into the game.
- GoldSrc SDK cl_entity_t/entity_state_t definitions: https://github.com/ValveSoftware/halflife/blob/master/common/cl_entity.h and https://github.com/ValveSoftware/halflife/blob/master/common/entity_state.h . Layout used with separate evidence from the supplied PE; SDK headers/proprietary DLLs are not copied into this archive.
- Menu purchasing targets stock CS 1.6 weapon selection and prices. This is a keyboard sequence, not authoritative inventory/buy-time telemetry. No other cheat project code was newly imported for v19.


## v20 combat and difficulty

Original C# difficulty profiles, bounded trigger FSM, geometric shot-corridor helper, reaction/damage timing and two-axis steering integration. Existing checked enemy reader now includes known teammates for corridor checks. SDK entity_state_t fields angles, mins/maxs and effects supply approximate head position and muzzle-flash/facing hints; they are not bone/hitbox or authoritative attacker telemetry. No additional downloaded cheat code, injection, remote game calls or new assets. Supplied v19 log shows `enemy-aim ... no autofire`, buy HUD changes and subsequent respawn wait; it is not evidence of v20 combat success.


## v21 map registration and user-provided asset

Original Maps-source scanning, pair preflight, case-insensitive matching, atomic registry update and invalid-level raw diagnostics. No new external code or assets downloaded. At the user's explicit request, the previously supplied de_dust2.bsp (SHA256 15945389528d113562ede0a2c80647ebfa799079ed1c05a25379bcf84e4e9286) IS NOW included as Maps/de_dust2.bsp in this user's project archive. Earlier version-specific statements about excluding BSP describe those historical archives only. The BSP is a user-provided game asset; no claim that the YaPB graph license covers it. No client.dll/hw.dll or uploaded game config/logs are included. Existing YaPB graph attribution/license remains in Navigation/ATTRIBUTION.md and Licenses/.
