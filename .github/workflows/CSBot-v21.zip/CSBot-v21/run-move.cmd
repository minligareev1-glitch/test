@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>&1
if errorlevel 1 (
  echo Install .NET 8 SDK first. See README.md.
  pause
  exit /b 1
)
dotnet run --project "CSBot\CSBot.csproj" -c Release -- --debug --probe-move --interval-ms 100 --log "move-probe.log" %*
set "result=%errorlevel%"
echo.
echo Exit code: %result%
pause
exit /b %result%
