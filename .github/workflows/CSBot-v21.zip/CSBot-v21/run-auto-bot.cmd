@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>&1
if errorlevel 1 exit /b 2
echo CSBot v21 AUTO START: local CS 1.6 vs bots only. No F8 or confirmation prompt.
echo Switching to the live foreground game enables input automatically after fresh-state checks.
echo Death waits for respawn. F9 exits. Focus loss releases input; focus return resumes automatically.
echo Close game menus/chat before returning focus. Bot never presses Shift.
set "GAMECFGARG="
if not "%~1"=="" set "GAMECFGARG=--config "%~1""
dotnet run --project "CSBot\CSBot.csproj" -c Release -- --auto-bot --settings "%~dp0config.txt" --assets "%~dp0." %GAMECFGARG% --log "auto-bot.log" --json "auto-plan.json" --execute
set "RESULT=%errorlevel%"
pause
exit /b %RESULT%
