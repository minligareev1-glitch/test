namespace CSBot;

internal sealed record HullTrace(bool Clear, bool StartSolid, double Fraction, ProbeVector End, ProbeVector Normal, int Contents = -1);
internal sealed partial class BspMap
{
    private sealed record ClipNode(int Plane, int Front, int Back);
    private ClipNode[] _clip = Array.Empty<ClipNode>();
    public bool HasClipHulls => _clip.Length>0;
    private void LoadClipNodes(byte[] bytes,int offset,int length)
    {
        // Keep v6 synthetic/no-collision fixtures loadable; walking explicitly refuses absent hulls.
        if(length==0) return;
        if(length%8!=0 || length/8>32767) throw new InvalidDataException("Некорректный clipnode lump");
        _clip=new ClipNode[length/8];
        bool Valid(int c)=>c>=0 ? c<_clip.Length : c>=-15;
        for(int i=0;i<_clip.Length;i++)
        {
            int o=offset+i*8, plane=BitConverter.ToInt32(bytes,o);
            int a=BitConverter.ToInt16(bytes,o+4), b=BitConverter.ToInt16(bytes,o+6);
            if(plane<0 || plane>=_planes.Length || !Valid(a) || !Valid(b)) throw new InvalidDataException("Некорректная ссылка clipnode");
            _clip[i]=new(plane,a,b);
        }
        var colors=new byte[_clip.Length];
        for(int root=0;root<_clip.Length;root++)
        {
            var todo=new Stack<(int Id,bool Exit)>(); todo.Push((root,false));
            while(todo.TryPop(out var n))
            {
                if(n.Id<0) continue;
                if(n.Exit) { colors[n.Id]=2; continue; }
                if(colors[n.Id]==2) continue;
                if(colors[n.Id]==1) throw new InvalidDataException("Цикл clipnode");
                colors[n.Id]=1; todo.Push((n.Id,true)); todo.Push((_clip[n.Id].Back,false)); todo.Push((_clip[n.Id].Front,false));
            }
        }
        foreach(var m in Models)
            if(m.ClipHeads==null || m.ClipHeads.Any(h=>!Valid(h))) throw new InvalidDataException("Некорректный clip head");
    }
    public int HullContents(ProbeVector p,int model=0,int hull=1)
    {
        if(!p.IsFinite || model<0 || model>=Models.Count || hull is <1 or >3 || !HasClipHulls)
            throw new ArgumentException("Нужны BSP clip hull, model и конечная точка");
        int id=Models[model].ClipHeads![hull-1];
        while(id>=0) { var node=_clip[id]; id=Side(_planes[node.Plane],p)>=0?node.Front:node.Back; }
        return id;
    }
    // Clip hulls already encode the Minkowski-expanded player volume; do NOT expand them again.
    // Traversal is near-first and yields first non-empty interval plus the entry plane normal.
    public HullTrace TraceHull(ProbeVector a,ProbeVector b,int model=0,int hull=1)
    {
        int start=HullContents(a,model,hull);
        if(start!=-1) return new(false,true,0,a,default,start); // refuse water/sky/etc as well as solid
        var todo=new Stack<(int Id,double Lo,double Hi,ProbeVector Normal)>();
        todo.Push((Models[model].ClipHeads![hull-1],0,1,default));
        int visits=0;
        ProbeVector At(double t)=>new((float)(a.X+t*((double)b.X-a.X)),(float)(a.Y+t*((double)b.Y-a.Y)),(float)(a.Z+t*((double)b.Z-a.Z)));
        while(todo.TryPop(out var span))
        {
            if(++visits>1_000_000) throw new InvalidDataException("Clip trace budget exceeded");
            if(span.Id<0)
            {
                if(span.Id==-1) continue;
                double safe=Math.Max(0,span.Lo-0.04/Math.Max(0.04,NavGraph.Distance(a,b)));
                return new(false,false,span.Lo,At(safe),span.Normal,span.Id);
            }
            var node=_clip[span.Id]; var plane=_planes[node.Plane];
            double da=Side(plane,At(span.Lo)), db=Side(plane,At(span.Hi));
            if(da>=0 && db>=0) todo.Push((node.Front,span.Lo,span.Hi,span.Normal));
            else if(da<0 && db<0) todo.Push((node.Back,span.Lo,span.Hi,span.Normal));
            else
            {
                double t=span.Lo+(span.Hi-span.Lo)*da/(da-db);
                bool back=da<0;
                var normal=back ? new ProbeVector(-plane.Normal.X,-plane.Normal.Y,-plane.Normal.Z):plane.Normal;
                todo.Push((back?node.Front:node.Back,t,span.Hi,normal));
                todo.Push((back?node.Back:node.Front,span.Lo,t,span.Normal));
            }
        }
        return new(true,false,1,b,default);
    }
}
