namespace CSBot;
internal sealed record MissionRoute(string Kind,List<int> Nodes,List<ProbeVector> Targets)
{ public double ComputeMs {get;init;} public int RawTargets {get;init;} public double AttachDistance {get;init;} }
internal static class MissionPlanner
{
    public static BombZone Site(LoadedMap asset,string preferred)=>asset.Map.BombZones().FirstOrDefault(z=>z.Label==preferred)??asset.Map.BombZones().First();
    public static string GoalKey(WorldState w)=>$"{w.Map}/{w.Team}/"+(w.BombPlanted?FormattableString.Invariant($"bomb:{w.Bomb.X:F1},{w.Bomb.Y:F1},{w.Bomb.Z:F1}"):"site");
    public static MissionRoute? Build(LoadedMap asset,WorldState world,ProbeVector origin,BotSettings settings)
    {
        var walk=new WalkGeometry(asset.Map);var nav=new MapNavigation(asset.Graph,asset.Map);string team=world.Team==1?"t":"ct";
        if(world.Team==2 && world.BombPlanted)
        {
            var raised=new ProbeVector(world.Bomb.X,world.Bomb.Y,world.Bomb.Z+72);
            if(!walk.SnapToFloor(raised,108,out var goal))return null;
            var route=nav.PlanToPoint(origin,goal,team,walk);
            return route.HasValue?new("defuse-approach",route.Value.Route.Nodes,route.Value.Targets):null;
        }
        var planned=nav.PlanToZone(origin,Site(asset,settings.ObjectiveSite),team,walk);
        return planned==null?null:new("site-approach",planned.Route.Nodes,planned.Route.Nodes.Select(id=>asset.Graph.Nodes[id].Origin).ToList());
    }
}
