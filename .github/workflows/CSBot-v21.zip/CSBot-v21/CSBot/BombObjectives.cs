namespace CSBot;
internal sealed record ObjectiveStep(bool Navigate,string Mode,TravelCommand? Command=null,string Error="");

internal sealed class BombObjectives(double seed,BotSettings settings,int pitchSign=1)
{
    private PulseSteering? _yaw,_pitch;
    private long _selectAt=long.MinValue,_holdAt=-1,_aimAt=-1,_coolUntil;
    private string _kind="";
    public void Reset(){_yaw=null;_pitch=null;_selectAt=long.MinValue;_holdAt=-1;_aimAt=-1;_coolUntil=0;_kind="";}
    private ObjectiveStep Navigate(string mode){if(_kind!="horizon")Reset();return new(true,mode);}
    private ObjectiveStep Neutral(string mode)=>new(false,mode,new(false,0,false,"",-1,Mode:mode));
    private ObjectiveStep Aim(MoveSample sample,double yaw,double pitch,long now,string kind,bool useWhenAligned)
    {
        if(_kind!=kind)
        {
            Reset();_kind=kind;
            var cfg=settings.Copy();cfg.MouseMaxCounts=Math.Min(cfg.MouseMaxCounts,32);cfg.MouseTurnMaxDeg=Math.Min(cfg.MouseTurnMaxDeg,6);cfg.MouseNearTurnMaxDeg=Math.Min(cfg.MouseNearTurnMaxDeg,cfg.MouseTurnMaxDeg);
            _yaw=new(seed,true,cfg);_pitch=new(seed,true,cfg);_aimAt=now;
        }
        double dyaw=PulseSteering.Normalize(yaw-sample.Angles.Y),dpitch=pitch-sample.Angles.X;
        var horizontal=_yaw!.Tick(sample.Angles.Y,dyaw,now,Math.Abs(dyaw)>settings.ObjectiveAimToleranceDeg);
        var vertical=_pitch!.Tick(-sample.Angles.X,-dpitch,now,Math.Abs(dpitch)>settings.ObjectiveAimToleranceDeg);
        string error=horizontal.StopReason!=""?horizontal.StopReason:vertical.StopReason;
        if(error!="")return new(false,"objective-feedback",Error:error);
        bool aligned=Math.Abs(dyaw)<=settings.ObjectiveAimToleranceDeg && Math.Abs(dpitch)<=settings.ObjectiveAimToleranceDeg && !horizontal.Waiting && !vertical.Waiting;
        if(!aligned && now-_aimAt>settings.ObjectiveAimTimeoutMs)return new(false,"objective-aim-timeout",Error:"objective aiming did not converge");
        bool use=aligned && useWhenAligned;
        if(use)
        {
            _aimAt=now;
            if(_holdAt<0)_holdAt=now;
            if(now-_holdAt>settings.DefuseHoldMs){_holdAt=-1;_coolUntil=now+500;use=false;}
            if(now<_coolUntil)use=false;
        }
        else _holdAt=-1;
        string phase=use?"defuse-hold-use":kind+"-aim";
        return new(false,phase,new(false,horizontal.MouseDx,false,"",-1,Mode:phase,MouseDy:vertical.MouseDx*pitchSign,Use:use));
    }
    public ObjectiveStep Tick(WorldState world,MoveSample sample,long now,bool inPlantZone,bool bombLineOfSight)
    {
        if(settings.AutoObjectives!="on")return Navigate("objectives-disabled");
        if(world.Team==1)
        {
            if(world.BombPlanted){if(settings.PostPlantMode!="off")return Navigate("post-plant-"+settings.PostPlantMode);Reset();return Neutral("planted-HUD-state-observed");}
            if(!inPlantZone)return Navigate("navigate-to-plant-site");
            if(!world.HasC4){Reset();return Neutral("at-site-without-C4");}
            if(!world.CanPlant){Reset();return Neutral("wait-HUD-plant-permission");}
            if(sample.OnGround<0 || sample.Velocity.Length>10){_holdAt=-1;return Neutral("plant-brake");}
            if(world.WeaponId!=6)
            {
                _holdAt=-1;
                bool select=_selectAt==long.MinValue || now-_selectAt>=800;if(select)_selectAt=now;
                return new(false,"select-C4",new(false,0,false,"",-1,Mode:"select-C4",SelectC4:select));
            }
            if(now<_coolUntil)return Neutral("plant-retry-wait");
            if(_holdAt<0)_holdAt=now;
            if(now-_holdAt>settings.PlantHoldMs){_holdAt=-1;_coolUntil=now+500;return Neutral("plant-window-ended-not-confirmed");}
            return new(false,"plant-hold-attack",new(false,0,false,"",-1,Mode:"plant-hold-attack",Attack:true));
        }
        if(world.Team==2 && world.BombPlanted)
        {
            if(NavGraph.Distance(sample.Origin,world.Bomb)>settings.DefuseRadius){return Navigate("navigate-to-planted-bomb");}
            if(!bombLineOfSight){_holdAt=-1;return Neutral("defuse-wait-line-of-sight");}
            if(sample.OnGround<0 || sample.Velocity.Length>10){_holdAt=-1;return Neutral("defuse-brake");}
            var eye=new ProbeVector(sample.Origin.X+sample.ViewOffset.X,sample.Origin.Y+sample.ViewOffset.Y,sample.Origin.Z+sample.ViewOffset.Z);
            double x=world.Bomb.X-eye.X,y=world.Bomb.Y-eye.Y,z=world.Bomb.Z+4-eye.Z;
            double yaw=Math.Atan2(y,x)*180/Math.PI,pitch=Math.Clamp(-Math.Atan2(z,Math.Sqrt(x*x+y*y))*180/Math.PI,-80,80);
            return Aim(sample,yaw,pitch,now,"defuse",true);
        }
        return Navigate("navigate-to-site");
    }
    public ObjectiveStep Flatten(MoveSample sample,long now)=>Aim(sample,sample.Angles.Y,0,now,"horizon",false);
}
