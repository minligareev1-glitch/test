using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace CSBot;

internal sealed record BspModel(ProbeVector Min, ProbeVector Max, int HeadNode, int[]? ClipHeads = null);
internal sealed record BombZone(string Label, string Target, int Model, ProbeVector Min, ProbeVector Max);
internal sealed partial class BspMap
{
    public const string SuppliedDust2Sha256 = "15945389528d113562ede0a2c80647ebfa799079ed1c05a25379bcf84e4e9286";
    private sealed record Plane(ProbeVector Normal, float Distance);
    private sealed record Node(int Plane, int Front, int Back);
    private readonly Plane[] _planes;
    private readonly Node[] _nodes;
    private readonly int[] _contents;
    public IReadOnlyList<BspModel> Models { get; }
    public IReadOnlyList<Dictionary<string, string>> Entities { get; }
    public string Sha256 { get; }
    public int FileSize { get; }
    public bool MatchesSuppliedDust2 => Sha256 == SuppliedDust2Sha256;

    private BspMap(byte[] data)
    {
        if (data.Length < 124 || data.Length > 128 * 1024 * 1024 || BitConverter.ToInt32(data, 0) != 30)
            throw new InvalidDataException("Поддерживается GoldSrc BSP v30; неверный заголовок/размер");
        int I(int o) => BitConverter.ToInt32(data, o);
        float F(int o) => BitConverter.ToSingle(data, o);
        ProbeVector V(int o) => new(F(o), F(o+4), F(o+8));
        var lumps = new (int Offset, int Length)[15];
        for (int i = 0; i < 15; i++)
        {
            int o = I(4+i*8), n = I(8+i*8);
            if (o < 0 || n < 0 || (long)o+n > data.Length || (n > 0 && o < 124))
                throw new InvalidDataException("Lump за пределами BSP: " + i);
            lumps[i] = (o,n);
        }
        int Count(int i, int stride, int maximum)
        {
            var l = lumps[i];
            if (l.Length == 0 || l.Length % stride != 0 || l.Length / stride > maximum)
                throw new InvalidDataException("Некорректный размер lump " + i);
            return l.Length / stride;
        }
        _planes = new Plane[Count(1,20,32767)];
        for (int i=0; i<_planes.Length; i++)
        {
            int o=lumps[1].Offset+i*20; var normal=V(o); float distance=F(o+12);
            double magnitude=NavGraph.Distance(normal,default);
            if (!normal.IsFinite || !float.IsFinite(distance) || magnitude < 0.99 || magnitude > 1.01)
                throw new InvalidDataException("Некорректная плоскость BSP");
            _planes[i]=new(normal,distance);
        }
        _contents = new int[Count(10,28,8192)];
        for (int i=0; i<_contents.Length; i++)
        {
            int c=I(lumps[10].Offset+i*28);
            if (c is > -1 or < -15) throw new InvalidDataException("Неизвестный тип leaf BSP");
            _contents[i]=c;
        }
        _nodes = new Node[Count(5,24,32767)];
        bool ValidChild(int c) => c >= 0 ? c < _nodes.Length : -1-c < _contents.Length;
        for (int i=0; i<_nodes.Length; i++)
        {
            int o=lumps[5].Offset+i*24, plane=I(o);
            int front=BitConverter.ToInt16(data,o+4), back=BitConverter.ToInt16(data,o+6);
            if (plane < 0 || plane >= _planes.Length || !ValidChild(front) || !ValidChild(back))
                throw new InvalidDataException("Некорректная ссылка BSP node");
            _nodes[i]=new(plane,front,back);
        }
        // Check ALL nodes, including brush submodels; reject cycles without recursive stack growth.
        var colors = new byte[_nodes.Length];
        for (int root=0; root<_nodes.Length; root++)
        {
            var stack=new Stack<(int Id, bool Exit)>(); stack.Push((root,false));
            while (stack.TryPop(out var step))
            {
                if (step.Id < 0) continue;
                if (step.Exit) { colors[step.Id]=2; continue; }
                if (colors[step.Id]==1) throw new InvalidDataException("Цикл BSP node");
                if (colors[step.Id]==2) continue;
                colors[step.Id]=1; var n=_nodes[step.Id];
                stack.Push((step.Id,true)); stack.Push((n.Back,false)); stack.Push((n.Front,false));
            }
        }
        var models = new BspModel[Count(14,64,4096)];
        for (int i=0; i<models.Length; i++)
        {
            int o=lumps[14].Offset+i*64; var min=V(o); var max=V(o+12); int head=I(o+36);
            if (!min.IsFinite || !max.IsFinite || min.X>max.X || min.Y>max.Y || min.Z>max.Z || !ValidChild(head))
                throw new InvalidDataException("Некорректный BSP model");
            models[i]=new(min,max,head,new[]{I(o+40),I(o+44),I(o+48)});
        }
        Models=models;
        LoadClipNodes(data,lumps[9].Offset,lumps[9].Length);
        if (lumps[0].Length>2*1024*1024) throw new InvalidDataException("Слишком большой entity lump");
        Entities=ParseEntities(Encoding.Latin1.GetString(data,lumps[0].Offset,lumps[0].Length).TrimEnd('\0'));
        Sha256=Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant(); FileSize=data.Length;
    }
    public static BspMap Load(string path)
    {
        if (new FileInfo(path).Length > 128*1024*1024) throw new InvalidDataException("BSP превышает 128 MiB");
        return new BspMap(File.ReadAllBytes(path));
    }
    // Also used for synthetic tests. No code or assets from the BSP are executed.
    internal static BspMap FromBytes(byte[] bytes) => new(bytes);

    private static List<Dictionary<string,string>> ParseEntities(string text)
    {
        int i=0;
        string? Token()
        {
            while (i<text.Length)
            {
                if (char.IsWhiteSpace(text[i])) { i++; continue; }
                if (text[i]=='/' && i+1<text.Length && text[i+1]=='/')
                { while(i<text.Length && text[i]!='\n') i++; continue; }
                break;
            }
            if (i==text.Length) return null;
            char c=text[i++];
            if (c is '{' or '}') return c.ToString();
            if (c!='"') throw new InvalidDataException("Некорректный entity token");
            int start=i;
            while (i<text.Length && text[i]!='"') i++;
            if (i==text.Length) throw new InvalidDataException("Незакрытая entity строка");
            return text[start..i++]; // Preserve literal backslashes in WAD paths.
        }
        var result=new List<Dictionary<string,string>>();
        string? token;
        while ((token=Token())!=null)
        {
            if (token!="{") throw new InvalidDataException("Ожидалась entity");
            var entity=new Dictionary<string,string>(StringComparer.Ordinal);
            while ((token=Token())!="}")
            {
                if (token==null || token=="{") throw new InvalidDataException("Незакрытая entity");
                string? value=Token();
                if (value==null || value is "{" or "}") throw new InvalidDataException("Нет значения entity");
                entity[token]=value;
            }
            result.Add(entity);
            if (result.Count>8192) throw new InvalidDataException("Слишком много entities");
        }
        return result;
    }
    private double Side(Plane plane, ProbeVector p) =>
        (double)plane.Normal.X*p.X+(double)plane.Normal.Y*p.Y+(double)plane.Normal.Z*p.Z-plane.Distance;

    public int PointContents(ProbeVector point, int model=0)
    {
        if (!point.IsFinite || model<0 || model>=Models.Count) throw new ArgumentException("Некорректная точка/model");
        int id=Models[model].HeadNode;
        while (id>=0) { var node=_nodes[id]; id=Side(_planes[node.Plane],point)>=0 ? node.Front : node.Back; }
        return _contents[-1-id];
    }
    // Exact BSP partition traversal for a ZERO-RADIUS segment against world hull 0 only.
    // NOT a player hull trace, floor/step/jump test, or collision test against brush entities.
    public bool WorldPointSegmentClear(ProbeVector a, ProbeVector b)=>PointSegmentClear(a,b,0);
    public bool PointSegmentClear(ProbeVector a, ProbeVector b,int model)
    {
        if (!a.IsFinite || !b.IsFinite || model<0 || model>=Models.Count) throw new ArgumentException("Некорректный отрезок");
        var stack=new Stack<(int Id, ProbeVector A, ProbeVector B)>(); stack.Push((Models[model].HeadNode,a,b));
        int budget=0;
        while(stack.TryPop(out var item))
        {
            if (++budget>1_000_000) throw new InvalidDataException("BSP trace budget exceeded");
            if (item.Id<0) { if (_contents[-1-item.Id]==-2) return false; continue; }
            var node=_nodes[item.Id]; var plane=_planes[node.Plane];
            double d=Side(plane,item.A), e=Side(plane,item.B);
            if (d>=0 && e>=0) stack.Push((node.Front,item.A,item.B));
            else if (d<0 && e<0) stack.Push((node.Back,item.A,item.B));
            else
            {
                double f=d/(d-e);
                var mid=new ProbeVector((float)(item.A.X+f*((double)item.B.X-item.A.X)),
                    (float)(item.A.Y+f*((double)item.B.Y-item.A.Y)),(float)(item.A.Z+f*((double)item.B.Z-item.A.Z)));
                stack.Push((d<0?node.Back:node.Front,item.A,mid));
                stack.Push((d<0?node.Front:node.Back,mid,item.B));
            }
        }
        return true;
    }
    public List<BombZone> BombZones()
    {
        var zones=new List<BombZone>();
        foreach (var e in Entities.Where(e=>e.GetValueOrDefault("classname")=="func_bomb_target"))
        {
            string model=e.GetValueOrDefault("model","");
            if (!model.StartsWith('*') || !int.TryParse(model.AsSpan(1),out int index) || index<=0 || index>=Models.Count)
                throw new InvalidDataException("Некорректная bomb brush model");
            foreach (string key in new[]{"origin","angles"})
                if (e.TryGetValue(key,out string? value) && (!TryVector(value,out var v) || v!=default))
                    throw new InvalidDataException("Преобразованная bomb model не поддерживается");
            string target=e.GetValueOrDefault("target","");
            string label=target switch { "tgt_a"=>"a", "tgt_b"=>"b", _=>"unknown" };
            var m=Models[index]; zones.Add(new(label,target,index,m.Min,m.Max));
        }
        return zones;
    }
    public bool InsideZone(ProbeVector p, BombZone zone) =>
        p.X>=zone.Min.X && p.X<=zone.Max.X && p.Y>=zone.Min.Y && p.Y<=zone.Max.Y &&
        p.Z>=zone.Min.Z && p.Z<=zone.Max.Z && PointContents(p,zone.Model)==-2;
    public static bool TryVector(string text,out ProbeVector v)
    {
        v=default; var parts=text.Split((char[]?)null,StringSplitOptions.RemoveEmptyEntries);
        if(parts.Length!=3 || !float.TryParse(parts[0],NumberStyles.Float,CultureInfo.InvariantCulture,out float x) ||
            !float.TryParse(parts[1],NumberStyles.Float,CultureInfo.InvariantCulture,out float y) ||
            !float.TryParse(parts[2],NumberStyles.Float,CultureInfo.InvariantCulture,out float z)) return false;
        v=new(x,y,z); return v.IsFinite;
    }
}
