namespace CSBot;

/// <summary>
/// Separate client fields observed in reader_ingame.log. These are candidate
/// RVAs for that build, NOT a portable CBasePlayer layout or proof of HUD identity.
/// </summary>
internal static class GameOffsets
{
    public const uint ClientHealthDirectRva = 0x11D640;
    public const uint ClientArmorDirectRva = 0x11EF0C;
    public const uint ClientMoneyDirectRva = 0x1213C4;

    // Diagnostic only: not required for reading the separate fields.
    public const uint ClientCandidatePointerRva = 0x4B530;
    public const uint CandidateHealthOffset = 0x14;
    public const uint CandidateMoneyOffset = 0x3D98;
    public const uint CandidateArmorOffset = 0x18E0;

    // Raw probe only. Does NOT become the player's position automatically.
    public const uint HwRawXyzRva = 0x7CD13C;
}
