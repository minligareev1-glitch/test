namespace CSBot;
internal static class RouteLookahead
{
    public static int Select(IReadOnlyList<ProbeVector> points,ProbeVector from,int index,double radius,int scan,Func<ProbeVector,ProbeVector,WalkCheck> check,int budget=int.MaxValue)
    {
        int tested=0;
        for(int i=Math.Min(points.Count-1,index+scan);i>index;i--)
        {
            if(NavGraph.Distance(from,points[i])>radius)continue;
            if(tested++>=budget)break;
            if(check(from,points[i]).Safe)return i;
        }
        return index;
    }
    public static List<ProbeVector> Simplify(ProbeVector origin,IReadOnlyList<ProbeVector> points,BotSettings s,Func<ProbeVector,ProbeVector,WalkCheck> check,CancellationToken token)
    {
        var result=new List<ProbeVector>();int index=0;var from=origin;
        while(index<points.Count)
        {
            token.ThrowIfCancellationRequested();
            int chosen=Select(points,from,index,s.NavPathLookahead,s.NavPathScanNodes,check);
            if(!check(from,points[chosen]).Safe)throw new InvalidDataException("Unsafe shortcut or graph attachment");
            if(NavGraph.Distance(from,points[chosen])>.1)result.Add(points[chosen]);
            from=points[chosen];index=chosen+1;
        }
        if(result.Count==0 && points.Count>0)result.Add(points[^1]);
        return result;
    }
}
