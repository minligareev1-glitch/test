namespace CSBot;
internal static class BombHudProfile
{
    public const uint DropRva=0x50FB0;
    public static byte[] Signature(uint client)
    {
        byte[] bytes=Convert.FromHexString("8b44240c8b4c24105051e8c1a9000083c408e8f9ab0000d91d00c0a201e8eeab0000d91d04c0a201e8e3ab0000d91d08c0a201e8f8a9000032d2663d010066a318c0a201750a8b4424048890454700008b0d5cd4a1015657890d0cc0a201bf1c419e0183c9ff33c0c70510c0a20101000000f2aef7d12bf9c70514c0a2019f8601008bc18bf7bf1cc0a201c1e902f3a58bc883e103f3a45f88152cc0a2015ec333c0c7050cc0a201000080bfa310c0a201a314c0a201c3");
        foreach(int at in new[]{25,36,47,64,82,90,95,106,122,135,154,164,173,178})BitConverter.GetBytes(unchecked(BitConverter.ToUInt32(bytes,at)-0x01900000+client)).CopyTo(bytes,at);
        return bytes;
    }
    public static bool Present(byte[] record)=>BitConverter.ToInt16(record,24)==1 && BitConverter.ToInt32(record,20)>0;
    public static bool Same(byte[] a,byte[] b)=>a.AsSpan(0,12).SequenceEqual(b.AsSpan(0,12)) && BitConverter.ToInt16(a,24)==BitConverter.ToInt16(b,24) && (BitConverter.ToInt32(a,20)>0)==(BitConverter.ToInt32(b,20)>0);
}
