namespace CSBot;
internal sealed record BuyStep(bool Busy,string Mode,TravelCommand? Command=null);
// Keyboard-only CS 1.6 stock buy menu. Never sends console commands or game calls.
internal sealed class BuyCoordinator(BotSettings s)
{
    private readonly Queue<byte> _keys=new();private long _next;private bool _attempted,_leftZone,_observing,_menuOpen,_closePending;private int _money,_weapon;
    public bool BindingReady {get;private set;}
    public string BindingIssue {get;private set;}="";
    public void Configure(GameConfig? cfg)
    {
        BindingReady=false;
        if(s.BuyMode=="off"){BindingIssue="disabled";return;}
        var required=s.BuyMode=="autobuy"?new[]{("F1","autobuy")}:new[]{("b","buy"),("1","slot1"),("2","slot2"),("3","slot3"),("4","slot4"),("6","slot6"),("8","slot8"),("0","slot10")};
        foreach(var (key,command) in required)
            if(cfg?.Bindings.GetValueOrDefault(key)!=command){BindingIssue=$"CFG binding {key}={command} not verified";return;}
        BindingReady=true;BindingIssue="";
    }
    internal void SetBindingsForTest(bool ready)=>BindingReady=ready;
    public void Cancel(bool resetLife=false)
    {
        _closePending|=_menuOpen;_menuOpen=false;_keys.Clear();_observing=false;
        if(resetLife){_attempted=false;_leftZone=false;}
    }
    private void Menu(params byte[] keys)
    { _keys.Enqueue(0x30);foreach(byte key in keys)_keys.Enqueue(key);_keys.Enqueue(0x0B); }
    public BuyStep Tick(WorldState w,int money,long now)
    {
        TravelCommand Key(byte scan)=>new(false,0,false,"",-1,Mode:"buy-key",Walk:false,TapScan:scan);
        if(!BindingReady || s.BuyMode=="off")return new(false,"buy-skipped: "+BindingIssue);
        if(_closePending){_closePending=false;_next=now+s.BuyKeyIntervalMs;return new(true,"buy-close-interrupted-menu",Key(0x0B));}
        if(!w.InBuyZone || w.BombPlanted || w.Team is not (1 or 2))
        {
            _leftZone=true;Cancel();
            if(_closePending){_closePending=false;return new(true,"buy-close-on-zone-exit",Key(0x0B));}
            return new(false,"not-in-buy-zone");
        }
        if(_keys.Count>0)
        {
            if(now<_next)return new(true,"buy-menu-wait");
            byte scan=_keys.Dequeue();_menuOpen=s.BuyMode=="menu" && scan!=0x0B;_next=now+s.BuyKeyIntervalMs;
            if(_keys.Count==0){_observing=true;_next=now+s.BuyObserveMs;}
            return new(true,"buy-menu-step",Key(scan));
        }
        if(_observing)
        {
            if(now<_next)return new(true,"buy-wait-HUD");
            _observing=false;
            return new(false,money<_money || w.WeaponId!=_weapon?"buy-HUD-change-observed":"buy-not-confirmed: funds/time/menu may reject purchase");
        }
        if(_leftZone){_attempted=false;_leftZone=false;}
        if(_attempted || money<0 || money>16000)return new(false,"buy-idle");
        _attempted=true;_money=money;_weapon=w.WeaponId;
        if(s.BuyMode=="autobuy")_keys.Enqueue(0x3B);
        else
        {
            int remaining=money;int price=w.Team==1?2500:3100;
            if(remaining>=price){Menu(0x05,w.Team==1?(byte)0x03:(byte)0x04);remaining-=price;} // B 4 2=T AK47, B 4 3=CT M4A1
            if(s.BuyArmor=="on" && remaining>=650)
            {bool helmet=remaining>=1000;Menu(0x09,helmet?(byte)0x03:(byte)0x02);remaining-=helmet?1000:650;}
            if(s.BuyAmmo=="on" && remaining>=60)Menu(0x07); // B 6 primary ammo
        }
        if(_keys.Count==0)return new(false,"buy-insufficient-budget");
        _next=now;return Tick(w,money,now);
    }
}
