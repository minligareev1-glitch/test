using System.Text;

namespace CSBot;

internal sealed record NavLink(int To, int StoredDistance, ushort Flags, ProbeVector JumpVelocity);
internal sealed record NavNode(int Id, int Flags, ProbeVector Origin, float Radius, List<NavLink> Links);
internal sealed record NavRoute(List<int> Nodes, double Cost);

internal sealed class NavGraph
{
    public required List<NavNode> Nodes { get; init; }
    public string Author { get; init; } = "";
    public string ModifiedBy { get; init; } = "";
    public int BspSizeHint { get; init; }
    public const int GoalFlag = 1 << 4;
    private const int SpecialNodes = (1 << 0) | (1 << 1) | (1 << 2) | (1 << 5) | (1 << 9);
    private const int TOnly = 1 << 29, CtOnly = 1 << 30;

    public static NavGraph Load(string file)
    {
        long fileSize = new FileInfo(file).Length;
        if (fileSize < 24 || fileSize > 8 * 1024 * 1024)
            throw new InvalidDataException("Недопустимый размер .graph");
        var bytes = File.ReadAllBytes(file);
        if (bytes.Length < 24 || bytes.Length > 8 * 1024 * 1024)
            throw new InvalidDataException("Недопустимый размер .graph");
        int I(int offset) => BitConverter.ToInt32(bytes, offset);
        int magic = I(0), version = I(4), options = I(8), count = I(12), packed = I(16), unpacked = I(20);
        if (magic != 0x59415042 || version != 2 || (options & 8) == 0)
            throw new InvalidDataException("Поддерживается только YaPB graph v2 (magic YAPB-data)");
        if (count is < 1 or > 4096 || unpacked != count * 220 || packed < 1 ||
            24L + packed + ((options & 64) != 0 ? 68 : 0) != bytes.Length)
            throw new InvalidDataException("Некорректный заголовок/размеры graph v2");
        byte[] raw = DecodeUlz(bytes.AsSpan(24, packed).ToArray(), unpacked);
        int R(int off) => BitConverter.ToInt32(raw, off);
        float F(int off) => BitConverter.ToSingle(raw, off);
        ProbeVector V(int off) => new(F(off), F(off + 4), F(off + 8));
        var nodes = new List<NavNode>(count);
        for (int i = 0; i < count; i++)
        {
            int offset = i * 220;
            var origin = V(offset + 8);
            float radius = F(offset + 44);
            if (R(offset) != i || !origin.IsFinite || !float.IsFinite(radius) || radius < 0)
                throw new InvalidDataException("Некорректный узел " + i);
            var links = new List<NavLink>(8);
            for (int k = 0; k < 8; k++)
            {
                int linkOffset = offset + 56 + k * 20;
                int to = BitConverter.ToInt16(raw, linkOffset + 18);
                if (to == -1) continue;
                int distance = R(linkOffset + 12);
                ushort flags = BitConverter.ToUInt16(raw, linkOffset + 16);
                var velocity = V(linkOffset);
                if (to < 0 || to >= count || distance < 0 || !velocity.IsFinite)
                    throw new InvalidDataException($"Некорректная связь {i} -> {to}");
                links.Add(new NavLink(to, distance, flags, velocity));
            }
            nodes.Add(new NavNode(i, R(offset + 4), origin, radius, links));
        }
        string author = "", modified = ""; int bspSize = 0;
        if ((options & 64) != 0)
        {
            int extension = 24 + packed;
            author = CString(bytes, extension, 32);
            bspSize = I(extension + 32);
            modified = CString(bytes, extension + 36, 32);
        }
        return new NavGraph { Nodes = nodes, Author = author, ModifiedBy = modified, BspSizeHint = bspSize };
    }

    private static string CString(byte[] data, int offset, int size) =>
        Encoding.UTF8.GetString(data, offset, size).Split('\0')[0];

    // ULZ token format; checked implementation, adapted from Unlicense ystl/ulz.h.
    public static byte[] DecodeUlz(byte[] source, int outputSize)
    {
        if (outputSize < 0 || outputSize > 4 * 1024 * 1024) throw new InvalidDataException("ULZ output limit");
        var result = new byte[outputSize]; int ip = 0, op = 0;
        int VarInt()
        {
            long value = 0;
            for (int shift = 0; shift <= 28; shift += 7)
            {
                if (ip >= source.Length) throw new InvalidDataException("Оборван ULZ varint");
                int b = source[ip++]; value += (long)b << shift;
                if (value > int.MaxValue) throw new InvalidDataException("Переполнение ULZ varint");
                if (b < 128) return (int)value;
            }
            throw new InvalidDataException("Слишком длинный ULZ varint");
        }
        while (ip < source.Length)
        {
            int token = source[ip++]; int run = token >> 5;
            if (run != 0)
            {
                if (run == 7) run = checked(run + VarInt());
                if (run > source.Length - ip || run > result.Length - op)
                    throw new InvalidDataException("Неверная длина ULZ literal");
                source.AsSpan(ip, run).CopyTo(result.AsSpan(op)); ip += run; op += run;
                if (ip == source.Length) break;
            }
            int length = (token & 15) + 4;
            if (length == 19) length = checked(length + VarInt());
            if (source.Length - ip < 2 || length > result.Length - op)
                throw new InvalidDataException("Неверная длина ULZ match");
            int distance = ((token & 16) << 12) + source[ip] + (source[ip + 1] << 8); ip += 2;
            if (distance <= 0 || distance > op) throw new InvalidDataException("Неверная ULZ back-reference");
            for (int n = 0; n < length; n++) { result[op] = result[op - distance]; op++; }
        }
        if (ip != source.Length || op != result.Length) throw new InvalidDataException("Неполная распаковка ULZ");
        return result;
    }

    public bool AllowedNode(int id, string team, bool allowSpecial)
    {
        int flags = Nodes[id].Flags;
        if (!allowSpecial && (flags & SpecialNodes) != 0) return false;
        if ((flags & TOnly) != 0 && team != "t") return false;
        if ((flags & CtOnly) != 0 && team != "ct") return false;
        return true;
    }

    public NavRoute? FindRoute(int from, int to, string team = "any", bool allowSpecial = false, Func<int, NavLink, bool>? edgeAllowed = null)
    {
        if (team is not ("any" or "t" or "ct")) throw new ArgumentException("team must be t, ct or any");
        if (from < 0 || to < 0 || from >= Nodes.Count || to >= Nodes.Count)
            throw new ArgumentException("ID узла за пределами графа");
        if (!AllowedNode(from, team, allowSpecial) || !AllowedNode(to, team, allowSpecial)) return null;
        var score = Enumerable.Repeat(double.PositiveInfinity, Nodes.Count).ToArray();
        var previous = Enumerable.Repeat(-1, Nodes.Count).ToArray();
        var open = new PriorityQueue<(int Id, double G), double>();
        score[from] = 0; open.Enqueue((from, 0), Distance(Nodes[from].Origin, Nodes[to].Origin));
        while (open.TryDequeue(out var current, out _))
        {
            if (current.G > score[current.Id]) continue;
            if (current.Id == to)
            {
                var route = new List<int>();
                for (int id = to; id != -1; id = previous[id]) route.Add(id);
                route.Reverse(); return new NavRoute(route, score[to]);
            }
            foreach (var link in Nodes[current.Id].Links)
            {
                // Unknown link flags are not implicitly executable, even with allow-special.
                if ((link.Flags & ~1) != 0 || (!allowSpecial && (link.Flags & 1) != 0) ||
                    !AllowedNode(link.To, team, allowSpecial) ||
                    (edgeAllowed != null && !edgeAllowed(current.Id, link))) continue;
                double cost = Math.Max(link.StoredDistance, Distance(Nodes[current.Id].Origin, Nodes[link.To].Origin));
                double tentative = current.G + cost;
                if (tentative >= score[link.To]) continue;
                score[link.To] = tentative; previous[link.To] = current.Id;
                open.Enqueue((link.To, tentative), tentative + Distance(Nodes[link.To].Origin, Nodes[to].Origin));
            }
        }
        return null;
    }

    public static double Distance(ProbeVector a, ProbeVector b)
    {
        double x = (double)a.X - b.X, y = (double)a.Y - b.Y, z = (double)a.Z - b.Z;
        return Math.Sqrt(x*x + y*y + z*z);
    }
}
