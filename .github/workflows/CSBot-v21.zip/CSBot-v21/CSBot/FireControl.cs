namespace CSBot;
internal sealed class FireControl
{
    private long _until,_restUntil;public bool Firing {get;private set;}
    public void Reset(){_until=_restUntil=0;Firing=false;}
    public void Stop(long now,int pauseMs)
    {if(Firing){Firing=false;_restUntil=now+pauseMs;}}
    public bool Prepare(long now,bool eligible,int pauseMs)
    {
        if(Firing && (!eligible || now>=_until))Stop(now,pauseMs);
        return now>=_restUntil;
    }
    public bool Tick(long now,bool eligible,int burstMs,int pauseMs)
    {
        if(!Prepare(now,eligible,pauseMs) || !eligible)return false;
        if(!Firing){Firing=true;_until=now+burstMs;}
        return true;
    }
    public static bool Firearm(int weapon)=>weapon is 1 or 3 or 5 or 7 or 8 or 10 or 11 or 12 or 13 or 14 or 15 or 16 or 17 or 18 or 19 or 20 or 21 or 22 or 23 or 24 or 26 or 27 or 28 or 30;
    public static bool SemiAutomatic(int weapon)=>weapon is 1 or 3 or 11 or 16 or 17 or 18 or 21 or 26;
    public static bool CorridorClear(ProbeVector eye,ProbeVector point,IReadOnlyList<EnemyState> players,int local,int target)
    {
        foreach(var p in players)
        {
            if(p.Index==local || p.Index==target)continue;
            var min=p.BoundsMin??new ProbeVector(-16,-16,-36);var max=p.BoundsMax??new ProbeVector(16,16,36);
            if(Intersects(eye,point,new(p.Origin.X+min.X-3,p.Origin.Y+min.Y-3,p.Origin.Z+min.Z-3),new(p.Origin.X+max.X+3,p.Origin.Y+max.Y+3,p.Origin.Z+max.Z+3)))return false;
        }
        return true;
    }
    private static bool Intersects(ProbeVector a,ProbeVector b,ProbeVector min,ProbeVector max)
    {
        if(!a.IsFinite || !b.IsFinite || !min.IsFinite || !max.IsFinite)return true;
        double near=0,far=1;
        foreach(var (start,delta,lo,hi) in new[]{((double)a.X,(double)b.X-a.X,(double)min.X,(double)max.X),((double)a.Y,(double)b.Y-a.Y,(double)min.Y,(double)max.Y),((double)a.Z,(double)b.Z-a.Z,(double)min.Z,(double)max.Z)})
        {
            if(Math.Abs(delta)<1e-8){if(start<lo || start>hi)return false;continue;}
            double x=(lo-start)/delta,y=(hi-start)/delta;if(x>y)(x,y)=(y,x);
            near=Math.Max(near,x);far=Math.Min(far,y);if(near>far)return false;
        }
        return true;
    }
}
