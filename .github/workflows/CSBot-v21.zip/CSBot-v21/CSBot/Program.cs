using System.ComponentModel;
using System.Text;

namespace CSBot;

internal static class Program
{
    private static volatile bool _stop;

    public static int Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        System.Globalization.CultureInfo.DefaultThreadCurrentCulture = System.Globalization.CultureInfo.InvariantCulture;
        if (BotSettings.TryRun(args,out int settingsExit))return settingsExit;
        if (MapCatalog.TryRun(args,out int catalogExit))return catalogExit;
        if (AutoMissionCli.TryRun(args,out int autoExit))return autoExit;
        if (GameConfig.TryRun(args, out int cfgExit)) return cfgExit;
        if (LiveNavigationCli.TryRun(args, out int liveExit)) return liveExit;
        if (MapCli.TryRun(args, out int mapExit)) return mapExit;
        if (NavCli.TryRun(args, out int navExit)) return navExit;
        if (args.Contains("--help") || args.Contains("-h"))
        {
            Console.WriteLine("CSBot — диагностический ридер CS 1.6 (Windows x64, .NET 8)");
            Console.WriteLine("--auto-bot [--assets ROOT] [--settings config.txt] [--config GAME_CFG] [--execute --confirm-local-bots]");
            Console.WriteLine("--register-maps [ROOT]                     проверить все BSP из Maps и зарегистрировать пары");
            Console.WriteLine("--register-map NAME [ROOT]                 зарегистрировать BSP + граф YaPB");
            Console.WriteLine("--check-settings FILE.txt                  проверить настройки бота без игры");
            Console.WriteLine("--inspect-config FILE.cfg                  расчёт настроек мыши без игры");
            Console.WriteLine("--live-nav GRAPH BSP --site a|b --team t|ct [--motion balanced|run|walk|cautious] [--config FILE] [--settings config.txt] [--execute --confirm-local-dust2] [--degrees-per-count N]");
            Console.WriteLine("--walk-plan GRAPH BSP X Y Z a|b [--team t|ct] [--json FILE]");
            Console.WriteLine("--map-check FILE.graph FILE.bsp [--json report.json] проверка карты");
            Console.WriteLine("--map-route FILE.graph FILE.bsp X Y Z a|b [--team t|ct] [--json FILE]");
            Console.WriteLine("--nav-info FILE.graph                    сведения и целевые узлы (без игры)");
            Console.WriteLine("--nav-route FILE.graph FROM TO [options] маршрут между ID узлов (без игры)");
            Console.WriteLine("  options: --team t|ct|any --allow-special --json route.json");
            Console.WriteLine("--debug          дамп кандидатов перед поиском");
            Console.WriteLine("--probe-xyz      логировать сырой XYZ-кандидат; это НЕ позиция игрока");
            Console.WriteLine("--probe-move     читать playermove по профилю присланной DLL с проверкой инструкций");
            Console.WriteLine("--probe-view     читать три кандидата 48-байтовой View и проверять базис");
            Console.WriteLine("--interval-ms N  интервал опроса 20..5000 мс (по умолчанию 500)");
            Console.WriteLine("--pid 1234       выбрать конкретный hl.exe");
            Console.WriteLine("--log reader.log дублировать вывод в UTF-8 файл");
            Console.WriteLine("--once           один снимок состояния или одна попытка поиска; затем выход");
            Console.WriteLine("D                новый диагностический дамп; R — повторный поиск; Ctrl+C — выход");
            return 0;
        }
        if (!OperatingSystem.IsWindows())
        { Console.Error.WriteLine("Чтение процесса доступно только в Windows."); return 1; }

        bool debug = false, probeXyz = false, probeView = false, probeMove = false, once = false;
        int intervalMs = 500;
        int? pid = null;
        string? logPath = null;
        try
        {
            for (int i = 0; i < args.Length; i++)
            {
                switch (args[i].ToLowerInvariant())
                {
                    case "--debug": debug = true; break;
                    case "--probe-xyz": probeXyz = true; break;
                    case "--probe-view": probeView = true; break;
                    case "--probe-move": probeMove = true; break;
                    case "--interval-ms":
                        if (++i >= args.Length || !int.TryParse(args[i], out intervalMs) || intervalMs < 20 || intervalMs > 5000)
                            throw new ArgumentException("После --interval-ms нужно число от 20 до 5000");
                        break;
                    case "--once": once = true; break;
                    case "--pid":
                        if (++i >= args.Length || !int.TryParse(args[i], out int value) || value <= 0)
                            throw new ArgumentException("После --pid нужен положительный PID");
                        pid = value;
                        break;
                    case "--log":
                        if (++i >= args.Length) throw new ArgumentException("После --log нужен путь к файлу");
                        logPath = args[i];
                        break;
                    default: throw new ArgumentException("Неизвестный аргумент: " + args[i]);
                }
            }
        }
        catch (ArgumentException ex) { Console.Error.WriteLine(ex.Message + ". См. --help"); return 2; }

        StreamWriter? file = null;
        try
        {
            if (logPath != null) file = new StreamWriter(logPath, append: true, encoding: new UTF8Encoding(false))
                { AutoFlush = true };
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        { Console.Error.WriteLine("Не удалось открыть лог: " + ex.Message); return 2; }
        using var logFile = file;
        void Log(string text)
        {
            string line = $"[{DateTimeOffset.Now:yyyy-MM-dd HH:mm:ss.fff zzz}] {text}";
            Console.WriteLine(line);
            logFile?.WriteLine(line);
        }

        Console.CancelKeyPress += (_, e) => { e.Cancel = true; _stop = true; };
        Log("CSBot v15 — ридер движения и офлайн-планировщик de_dust2. Только чтение памяти.");
        Log("ВАЖНО: прямые поля ещё нужно проверить по HUD. Спавн, Alive и позиция не определяются.");
        Log("Зайди на локальную карту, выбери команду и дождись спавна. HP=0 допустим, но не доказывает смерть или отсутствие карты.");
        Log("D — дамп, R — повторный поиск, Ctrl+C — выход.");

        while (!_stop)
        {
            try
            {
                using var mem = ProcessMemory.Attach("hl", pid);
                if (mem == null)
                {
                    Log("[..] Процесс игры не найден.");
                    if (once) return 3;
                    Pause(2000);
                    continue;
                }
                Log($"[+] Открыт PID={mem.ProcessId}, reader={IntPtr.Size * 8}-bit, target=32-bit");
                foreach (string name in new[] { "hl.exe", "hw.dll", "client.dll", "sw.dll", "mp.dll" })
                {
                    if (mem.Modules.TryGetValue(name, out uint address))
                        Log($"{name,-12} base=0x{address:X8}, size=0x{mem.ModuleSizes.GetValueOrDefault(name):X}");
                    else Log(name + ": не загружен");
                }
                if (debug || probeMove) LogClientFingerprint(mem, Log);
                var reader = new GameReader(mem, Log) { ProbeRawXyz = probeXyz, ProbeView = probeView, ProbeMovement = probeMove };
                if (debug) reader.DebugDump();
                if (!reader.DiscoverLocalPlayer())
                {
                    Log("[?] Профиль пока недоступен: " + reader.LastFailure);
                    if (once) return 3;
                    Pause(2000);
                    continue;
                }
                Log("[?] Подключён профиль адресов из лога: " + reader.Source);
                while (!_stop && !mem.HasExited)
                {
                    if (!reader.TryReadState(out var state))
                    {
                        Log("[!] Потерян кандидат: " + reader.LastFailure);
                        if (once) return 4;
                        break;
                    }
                    Log($"HP={state.Health} Armor={Field(state.Armor)} Money={Field(state.Money)} " +
                        "XYZ=? [ПОЗИЦИЯ И СПАВН НЕ ПОДТВЕРЖДЕНЫ; поля проверить по HUD]");
                    if (once) return 0;
                    bool rediscover = false;
                    while (!Console.IsInputRedirected && Console.KeyAvailable)
                    {
                        var key = Console.ReadKey(intercept: true).Key;
                        if (key == ConsoleKey.D) reader.DebugDump();
                        if (key == ConsoleKey.R) rediscover = true;
                    }
                    if (rediscover) { Log("[*] Повторный поиск по запросу"); break; }
                    Pause(intervalMs);
                }
                if (!_stop) Pause(1000);
            }
            catch (Exception ex) when (ex is Win32Exception or InvalidOperationException or NotSupportedException)
            {
                Log("[!] " + ex.Message);
                if (ex is Win32Exception native) Log("Win32=" + native.NativeErrorCode);
                if (once) return 5;
                Pause(2000);
            }
        }
        Log("Остановлено.");
        return 0;
    }

    private static void LogClientFingerprint(ProcessMemory mem, Action<string> log)
    {
        const string expected = "b474ecfbb6f2fc6c4aa48fceb0b5735dfe2cb23ce06ba0a1008137cd228c714a";
        if (!mem.ModulePaths.TryGetValue("client.dll", out string? path))
        { log("ClientFileHash: ? путь client.dll пока недоступен"); return; }
        try
        {
            using var stream = File.OpenRead(path);
            string actual = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(stream)).ToLowerInvariant();
            log($"ClientFileHash={actual}; MatchesSuppliedFile={actual == expected}");
            if (actual != expected) log("[!] client.dll на диске отличается от исследованной. Достоверность профиля не установлена.");
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        { log("ClientFileHash: ? " + ex.Message); }
    }

    private static string Field(int? value) => value?.ToString() ?? "?";
    private static void Pause(int milliseconds)
    {
        for (int elapsed = 0; elapsed < milliseconds && !_stop;)
        {
            int chunk = Math.Min(100, milliseconds - elapsed);
            Thread.Sleep(chunk);
            elapsed += chunk;
        }
    }
}
