namespace CSBot;
internal sealed class AutoStartGate(int delayMs)
{
    private long _since=-1,_last=-1;
    public void Reset(){_since=-1;_last=-1;}
    public bool Observe(bool focused,bool busy,long now)
    {
        if(!focused || busy){Reset();return false;}
        if(_since<0 || now<=_last || now-_last>250)_since=now;
        _last=now;return now-_since>=delayMs;
    }
}
