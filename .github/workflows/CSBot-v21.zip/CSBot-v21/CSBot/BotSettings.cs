using System.Globalization;
using System.Reflection;
namespace CSBot;

[AttributeUsage(AttributeTargets.Property)]
internal sealed class TuningAttribute(double minimum,double maximum,string description):Attribute
{
    public double Minimum=>minimum;public double Maximum=>maximum;public string Description=>description;
}
internal sealed class BotSettings
{
    [Tuning(0,0,"balanced: бег на безопасных прямых; run: приоритет бега при проверенном запасе; walk: Shift; cautious: раздельное управление")] public string Motion {get;set;}="balanced";
    [Tuning(0,2,"0: оценка из игрового config.cfg; иначе начальные градусов на один отсчёт мыши")] public double DegreesPerCount {get;set;}=0;
    [Tuning(10,100,"Пауза цикла combined, мс; геометрия и ОС добавляют своё время")] public int LoopMs {get;set;}=25;
    [Tuning(20,100,"Пауза осторожного режима, мс")] public int CautiousLoopMs {get;set;}=50;
    [Tuning(5,35,"При большей ошибке направления поворот на месте")] public double MoveMaxErrorDeg {get;set;}=25;
    [Tuning(0.2,3,"Обычный допуск угла")] public double YawToleranceDeg {get;set;}=1.5;
    [Tuning(0.05,1,"Точный допуск у стены")] public double PrecisionToleranceDeg {get;set;}=0.2;
    [Tuning(3,16,"Радиус промежуточной точки, игровые единицы")] public double WaypointRadius {get;set;}=10;
    [Tuning(2,6,"Радиус конечной точки")] public double GoalRadius {get;set;}=4;
    [Tuning(1,3,"Допуск высоты waypoint")] public double WaypointHeightTolerance {get;set;}=3;
    [Tuning(32,256,"Максимальная длина проверенного среза прямых точек")] public double LookaheadUnits {get;set;}=160;
    [Tuning(0,4,"Сколько следующих точек можно проверить для среза")] public int LookaheadNodes {get;set;}=2;
    [Tuning(2,16,"Максимальное боковое отклонение промежуточной точки")] public double LookaheadLateral {get;set;}=12;
    [Tuning(1,12,"Допуск высоты для прямого lookahead")] public double LookaheadHeight {get;set;}=8;
    [Tuning(16,64,"Минимальная длина прогноза текущего направления")] public double ForecastMinUnits {get;set;}=24;
    [Tuning(64,160,"Максимальная длина прогноза")] public double ForecastMaxUnits {get;set;}=100;
    [Tuning(0.1,0.4,"Горизонт реакции в прогнозе инерции")] public double ForecastReactionSeconds {get;set;}=0.18;
    [Tuning(800,2400,"Делитель speed^2 в эвристике запаса торможения")] public double ForecastBrakeDivisor {get;set;}=1600;
    [Tuning(2,15,"Предельная ошибка направления для бега")] public double RunMaxErrorDeg {get;set;}=8;
    [Tuning(32,160,"Минимальный остаток пути для бега balanced")] public double RunMinDistance {get;set;}=70;
    [Tuning(1,18,"Предельная разница высоты цели для бега balanced")] public double RunMaxHeightDelta {get;set;}=4;
    [Tuning(5,45,"Предельный следующий поворот для бега balanced")] public double RunMaxNextTurnDeg {get;set;}=20;
    [Tuning(32,160,"Проверка свободного пути для бега")] public double RunProbeUnits {get;set;}=96;
    [Tuning(1,12,"Дополнительные направления по сторонам для проверки бега")] public double RunSideAngleDeg {get;set;}=6;
    [Tuning(20,120,"Порог скорости раннего торможения у цели")] public double CornerBrakeSpeed {get;set;}=60;
    [Tuning(0.4,1,"Множитель длины прогноза для раннего торможения")] public double CornerBrakeFactor {get;set;}=0.65;
    [Tuning(3000,60000,"Таймаут одного поворота, мс")] public int TurnTimeoutMs {get;set;}=30000;
    [Tuning(500,5000,"Ожидание безопасного направления перед перепланированием, мс")] public int BlockedTimeoutMs {get;set;}=1200;
    [Tuning(500,10000,"Окно проверки застревания, мс")] public int ProgressTimeoutMs {get;set;}=1800;
    [Tuning(2,32,"Необходимое продвижение за окно")] public double ProgressUnits {get;set;}=8;
    [Tuning(1,20,"Максимальный целевой угол отдельного импульса после калибровки")] public double MouseTurnMaxDeg {get;set;}=12;
    [Tuning(0.5,10,"Максимальный импульс при небольшой ошибке")] public double MouseNearTurnMaxDeg {get;set;}=3;
    [Tuning(5,45,"Граница небольшой ошибки")] public double MouseNearErrorDeg {get;set;}=25;
    [Tuning(0.2,0.9,"Доля оставшегося угла на импульс combined")] public double MouseFastFraction {get;set;}=0.65;
    [Tuning(0.1,0.6,"Доля угла cautious")] public double MouseSlowFraction {get;set;}=0.35;
    [Tuning(1,8,"Первый пробный импульс: защитный предел 8")] public int MouseFirstMaxCounts {get;set;}=8;
    [Tuning(8,256,"Лимит отсчётов откалиброванного импульса")] public int MouseMaxCounts {get;set;}=128;
    [Tuning(20,150,"Минимальное ожидание измеренного отклика combined")] public int MouseSettleMs {get;set;}=60;
    [Tuning(10,100,"Тишина yaw перед оценкой отклика combined")] public int MouseQuietMs {get;set;}=25;
    [Tuning(80,250,"Ожидание первого отклика и cautious")] public int MouseInitialSettleMs {get;set;}=120;
    [Tuning(40,150,"Тишина для первого отклика и cautious")] public int MouseInitialQuietMs {get;set;}=80;
    [Tuning(1,1.3,"Запас измеренного gain; больше даёт меньшую команду")] public double MouseGainMargin {get;set;}=1.1;
    [Tuning(40,1000,"Лимит импульсов на текущую waypoint-точку, не на весь маршрут")] public int MousePulseBudget {get;set;}=180;
    [Tuning(3,10,"Лимит смен знака на текущую точку")] public int MouseMaxReversals {get;set;}=6;
    [Tuning(200,500,"Когда отпустить W при отсутствии отклика")] public int MouseRetryBrakeMs {get;set;}=250;
    [Tuning(400,800,"Когда разрешить небольшой повтор после торможения")] public int MouseRetryAfterMs {get;set;}=450;
    [Tuning(600,1000,"Нет отклика после последнего повтора: STOP/replan")] public int MouseNoResponseMs {get;set;}=700;
    [Tuning(900,2000,"Общий предел ожидания отклика одной попытки")] public int MouseResponseTimeoutMs {get;set;}=1000;
    [Tuning(0,3,"Максимум повторов потерянного импульса")] public int MouseRetryCount {get;set;}=2;
    [Tuning(0,1000,"0: неограниченные попытки перепланирования; иначе общий лимит")] public int RecoveryLimit {get;set;}=0;
    [Tuning(150,1000,"Стабильная наземная позиция до перепланирования")] public int RecoveryStableMs {get;set;}=400;
    [Tuning(500,5000,"Пауза между повторными попытками непрерывного режима")] public int RecoveryBackoffMs {get;set;}=2000;
    [Tuning(3000,15000,"Предел ожидания планировщика/стабилизации")] public int RecoveryTimeoutMs {get;set;}=10000;
    [Tuning(150,500,"Максимальная пассивная пауза приземления; верхний защитный предел 500")] public int LandingPauseMs {get;set;}=500;
    [Tuning(100,180,"Допустимая скорость падения при коротком сходе со ступеньки")] public double LandingMaxFallSpeed {get;set;}=180;
    [Tuning(0,0,"Автоматические действия с бомбой: on/off")] public string AutoObjectives {get;set;}="on";
    [Tuning(0,0,"Предпочитаемая зона установки a/b; неизвестные метки: первая brush-зона")] public string ObjectiveSite {get;set;}="a";
    [Tuning(2,8,"Допуск наведения для +use, градусы")] public double ObjectiveAimToleranceDeg {get;set;}=5;
    [Tuning(2000,15000,"Окно попытки наведения на бомбу")] public int ObjectiveAimTimeoutMs {get;set;}=8000;
    [Tuning(3000,6000,"Окно удержания attack при подтверждённой C4")] public int PlantHoldMs {get;set;}=5000;
    [Tuning(10500,14000,"Окно удержания use; это не подтверждение успеха defuse")] public int DefuseHoldMs {get;set;}=11500;
    [Tuning(40,64,"Максимальное расстояние от центра игрока до бомбы для попытки defuse")] public double DefuseRadius {get;set;}=60;
    [Tuning(100,2000,"Свежие наземные кадры после возрождения, мс")] public int RespawnWarmupMs {get;set;}=150;
    [Tuning(0,250,"Дополнительная стабилизация AUTO, мс")] public int AutoReplanStableMs {get;set;}=0;
    [Tuning(0,1000,"Пауза AUTO после ошибки навигации, мс")] public int AutoRetryMs {get;set;}=0;
    [Tuning(50,2000,"Повтор при отсутствии маршрута, мс")] public int AutoNoRouteRetryMs {get;set;}=350;
    [Tuning(128,768,"Радиус подключения к графу")] public double NavAttachRadius {get;set;}=384;
    [Tuning(4,32,"Число кандидатов подключения")] public int NavAttachCandidates {get;set;}=12;
    [Tuning(16,256,"Предпочтительный первый отрезок")] public double NavPreferredAdvance {get;set;}=96;
    [Tuning(0,256,"Штраф начального разворота")] public double NavHeadingPenalty {get;set;}=80;
    [Tuning(64,768,"Максимальная длина проверенного сокращения пути")] public double NavPathLookahead {get;set;}=384;
    [Tuning(4,64,"Глубина поиска дальней точки")] public int NavPathScanNodes {get;set;}=24;
    [Tuning(0,0,"После установки: cover/patrol/off")] public string PostPlantMode {get;set;}="cover";
    [Tuning(64,512,"Минимальное расстояние от C4")] public double PostPlantMinDistance {get;set;}=160;
    [Tuning(128,1024,"Максимальное расстояние от C4")] public double PostPlantMaxDistance {get;set;}=640;
    [Tuning(1000,20000,"Удержание укрытия перед сменой, мс")] public int PostPlantHoldMs {get;set;}=5000;
    [Tuning(32,256,"Минимальная смена позиции")] public double PostPlantRelocateDistance {get;set;}=96;
    [Tuning(0,0,"Закупка menu/autobuy/off")] public string BuyMode {get;set;}="menu";
    [Tuning(0,0,"Покупать броню on/off")] public string BuyArmor {get;set;}="on";
    [Tuning(0,0,"Покупать основные патроны on/off")] public string BuyAmmo {get;set;}="on";
    [Tuning(100,500,"Интервал клавиш меню закупки, мс")] public int BuyKeyIntervalMs {get;set;}=180;
    [Tuning(300,2000,"Ожидание изменения денег/оружия после закупки, мс")] public int BuyObserveMs {get;set;}=700;
    [Tuning(0,0,"Боевой модуль on/off; стрельба отдельно AutoFire")] public string EnemyAim {get;set;}="on";
    [Tuning(10,360,"Полный угол поиска цели, градусы")] public double AimFovDeg {get;set;}=100;
    [Tuning(128,16384,"Максимальная дистанция наведения")] public double AimMaxDistance {get;set;}=1800;
    [Tuning(10,200,"Интервал снимков игроков, мс")] public int AimScanMs {get;set;}=40;
    [Tuning(100,750,"Предельный возраст сетевого состояния, мс")] public int AimMaxStateAgeMs {get;set;}=350;
    [Tuning(250,3000,"Стабильный фокус до автоматического возобновления, мс")] public int AutoResumeMs {get;set;}=500;
    [Tuning(0,0,"Профиль easy/medium/hard/god")] public string Difficulty {get;set;}="medium";
    [Tuning(0,0,"Применять скорости мыши, опроса и дальности профиля on/off")] public string DifficultyTuning {get;set;}="on";
    [Tuning(0,0,"Автоматическая стрельба по проверенной цели on/off")] public string AutoFire {get;set;}="on";
    [Tuning(0,0,"Искать и разворачиваться к противнику сзади on/off")] public string RearTurn {get;set;}="on";
    [Tuning(0,16384,"0: радиус задней полусферы из профиля")] public double RearAwarenessRadius {get;set;}=0;
    [Tuning(-1,2000,"-1: задержка реакции из профиля; 0 без добавленной задержки")] public int CombatReactionMs {get;set;}=-1;
    [Tuning(0,5,"0: допуск профиля; дополнительно ограничен геометрическим углом цели")] public double FireToleranceDeg {get;set;}=0;
    [Tuning(0,1000,"0: длина очереди из профиля")] public int FireBurstMs {get;set;}=0;
    [Tuning(0,2000,"0: пауза между очередями из профиля")] public int FirePauseMs {get;set;}=0;
    [Tuning(-1,500,"-1: выдержка точного прицела из профиля")] public int FireStableMs {get;set;}=-1;
    [Tuning(0,500,"0: максимальный возраст снимка для огня из профиля")] public int FireFreshMs {get;set;}=0;
    [Tuning(2,8,"Радиус приближённой головы для угла допуска стрельбы")] public double HeadAimRadius {get;set;}=4;
    [Tuning(4,16,"Радиус зоны тела для угла допуска стрельбы")] public double BodyAimRadius {get;set;}=8;
    public BotSettings Copy()=>(BotSettings)MemberwiseClone();
    private static IEnumerable<PropertyInfo> Fields=>typeof(BotSettings).GetProperties().Where(p=>p.GetCustomAttribute<TuningAttribute>()!=null);
    public static BotSettings Parse(string text)
    {
        var result=new BotSettings();var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);int lineNumber=0;
        var fields=Fields.ToDictionary(p=>p.Name,StringComparer.OrdinalIgnoreCase);
        foreach(string raw in text.Split('\n'))
        {
            lineNumber++;string line=raw.Trim().TrimStart('\uFEFF');
            int comment=line.IndexOfAny(new[]{'#',';'});if(comment>=0)line=line[..comment].Trim();
            if(line.Length==0)continue;
            int equals=line.IndexOf('=');if(equals<1)throw new FormatException($"config.txt line {lineNumber}: expected Key=Value");
            string key=line[..equals].Trim(),value=line[(equals+1)..].Trim();
            if(!fields.TryGetValue(key,out var field))throw new FormatException($"config.txt line {lineNumber}: unknown key {key}");
            if(!seen.Add(key))throw new FormatException($"config.txt line {lineNumber}: duplicate {key}");
            var spec=field.GetCustomAttribute<TuningAttribute>()!;
            if(field.PropertyType==typeof(string)){field.SetValue(result,value.ToLowerInvariant());continue;}
            if(!double.TryParse(value.Replace(',','.'),NumberStyles.AllowLeadingSign|NumberStyles.AllowDecimalPoint,CultureInfo.InvariantCulture,out double number) || !double.IsFinite(number) || number<spec.Minimum || number>spec.Maximum || (field.PropertyType==typeof(int) && number!=Math.Truncate(number)))
                throw new FormatException($"config.txt line {lineNumber}: {key} must be {spec.Minimum}..{spec.Maximum}");
            if(field.PropertyType==typeof(int))field.SetValue(result,(int)number);else field.SetValue(result,number);
        }
        result.Validate();return result;
    }
    public void Validate()
    {
        _=TravelOptions.Parse(Motion);
        if(Difficulty is not ("easy" or "medium" or "hard" or "god") || DifficultyTuning is not ("on" or "off") || AutoFire is not ("on" or "off") || RearTurn is not ("on" or "off"))throw new FormatException("Invalid difficulty/fire/rear mode");
        if(BuyMode is not ("menu" or "autobuy" or "off") || BuyArmor is not ("on" or "off") || BuyAmmo is not ("on" or "off") || EnemyAim is not ("on" or "off"))throw new FormatException("Invalid buy/aim mode");
        if(PostPlantMode is not ("cover" or "patrol" or "off") || PostPlantMinDistance>=PostPlantMaxDistance || NavPreferredAdvance>NavAttachRadius)throw new FormatException("Invalid post-plant mode/radii or navigation advance");
        if(AutoObjectives is not ("on" or "off") || ObjectiveSite is not ("a" or "b"))throw new FormatException("AutoObjectives=on|off; ObjectiveSite=a|b");
        if(DegreesPerCount>0 && DegreesPerCount<.001)throw new FormatException("DegreesPerCount: 0 (auto) or .001..2");
        if(PrecisionToleranceDeg>YawToleranceDeg || RunMaxErrorDeg>MoveMaxErrorDeg || ForecastMinUnits>ForecastMaxUnits || GoalRadius>WaypointRadius || MouseNearTurnMaxDeg>MouseTurnMaxDeg)
            throw new FormatException("config.txt: incompatible angle, radius or forecast limits");
        if(MouseQuietMs>MouseSettleMs || MouseInitialQuietMs>MouseInitialSettleMs || MouseRetryBrakeMs>=MouseRetryAfterMs || MouseRetryAfterMs>=MouseNoResponseMs || MouseNoResponseMs>=MouseResponseTimeoutMs || RecoveryStableMs+RecoveryBackoffMs>=RecoveryTimeoutMs)
            throw new FormatException("config.txt: incompatible waiting/retry intervals");
    }
    public static BotSettings Load(string path)
    {
        if(new FileInfo(path).Length>65536)throw new FormatException("config.txt exceeds 64 KiB");
        return Parse(File.ReadAllText(path));
    }
    public void Report(Action<string> log)
    {
        foreach(var field in Fields)log($"SETTING {field.Name}={Convert.ToString(field.GetValue(this),CultureInfo.InvariantCulture)}");
    }
    public static bool TryRun(string[] args,out int exit)
    {
        exit=0;if(args.Length==0 || args[0]!="--check-settings")return false;
        try
        {
            if(args.Length!=2)throw new ArgumentException("--check-settings FILE");
            var settings=Load(args[1]);var profile=DifficultyProfile.Resolve(settings);profile.Apply(settings);settings.Validate();settings.Report(Console.WriteLine);Console.WriteLine($"Effective AUTO profile={profile.Name}; reactionMs={profile.Reaction(settings)}; target={profile.AimPart}; W-duty={profile.MoveDuty}; fireFreshMs={profile.Fresh(settings)}; AUTO forces Motion=run. Settings OK; no game/process/input accessed.");
        }
        catch(Exception ex) when(ex is IOException or UnauthorizedAccessException or ArgumentException or FormatException)
        {Console.Error.WriteLine(ex.Message);exit=2;}
        return true;
    }
}
