namespace CSBot;

internal sealed record LandingDecision(bool Waiting=false,bool Landed=false,string StopReason="");

// Only bounded passive step descent, not jumping or airborne control.
internal sealed class StepLandingPause(Func<ProbeVector,ProbeVector,float,WalkCheck> clearance,Func<ProbeVector,bool> supported,BotSettings? settings=null)
{
    public const int MaxAirMs=500;
    private readonly BotSettings _s=settings??new();
    private long _lastGroundAt=long.MinValue,_airAt;
    private float _takeoffZ;
    private bool _air;
    public LandingDecision Observe(MoveSample s,long now)
    {
        LandingDecision Stop(string reason)=>new(StopReason:"step landing refused: "+reason);
        if(!s.Origin.IsFinite || !s.Velocity.IsFinite)return Stop("non-finite pose");
        if(s.OnGround>=0)
        {
            if(!supported(s.Origin))return _air?Stop("ground flag without verified BSP support"):new();
            if(_air && (now-_airAt>_s.LandingPauseMs || _takeoffZ-s.Origin.Z>18.1f || s.Origin.Z>_takeoffZ+2))
                return Stop("landing outside time/height bound");
            bool landed=_air;_air=false;_lastGroundAt=now;_takeoffZ=s.Origin.Z;
            return new(Landed:landed);
        }
        if(!_air)
        {
            if(_lastGroundAt==long.MinValue || now-_lastGroundAt>250)return Stop("no recent verified grounded pose");
            _air=true;_airAt=now;
        }
        if(now-_airAt>_s.LandingPauseMs)return Stop($"airborne pause exceeded {_s.LandingPauseMs}ms");
        if(s.Velocity.Z>1 || s.Velocity.Z< -_s.LandingMaxFallSpeed)return Stop("upward/jump or excessive falling velocity");
        if(s.Velocity.Length>290 || s.Origin.Z>_takeoffZ+2 || s.Origin.Z<_takeoffZ-18.1f)
            return Stop("outside bounded 18-unit step descent");
        var geometry=clearance(s.Origin,s.Velocity,_takeoffZ);
        if(!geometry.Safe)return Stop(geometry.Reason);
        return new(Waiting:true);
    }
}
