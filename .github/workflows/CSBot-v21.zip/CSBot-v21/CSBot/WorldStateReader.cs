using System.Text;
namespace CSBot;

internal sealed record WorldState(string Map,int Team,bool HasC4,bool CanPlant,int WeaponId,bool BombPlanted,ProbeVector Bomb)
{
    public bool InBuyZone {get;init;}
    public int LocalEntityIndex {get;init;}=-1;
    public string TeamName {get;init;}="";
    public string TeamSource {get;init;}="unspecified";
    public int LegacyTeam {get;init;}=-1;
}

// Read-only profile derived from the supplied client.dll handlers. Never calls game code.
internal sealed class WorldStateReader(IGameMemory memory)
{
    public const uint EngineTable=0x121BA0, TeamArray=0x12B31A, LegacyTeamArray=0x12B2F4, Icons=0x1212E0, WeaponPointer=0x11D5D8, Weapons=0x11A6B8, BombData=0x12C000;
    // Exact supplied hw.dll profile; all RVAs relative to the actual loaded image.
    public const uint LevelFunctionRva=0x19950, ConnectionStateRva=0x10255C0,
        LevelBufferRva=0x11CF27C, LevelRecordSlotRva=0x17C908, EmptyLevelRva=0x1ABAF4;
    public const int LevelBufferLength=40;
    public static byte[] LevelSignature(uint engine)
    {
        // call [recorder]; mov eax,[state]; cmp eax,3; mov eax,level;
        // jge return; mov eax,empty; ret. The recorder is NEVER invoked.
        byte[] code={0xFF,0x15,0,0,0,0,0xA1,0,0,0,0,0x83,0xF8,3,
            0xB8,0,0,0,0,0x7D,5,0xB8,0,0,0,0,0xC3};
        BitConverter.GetBytes(engine+LevelRecordSlotRva).CopyTo(code,2);
        BitConverter.GetBytes(engine+ConnectionStateRva).CopyTo(code,7);
        BitConverter.GetBytes(engine+LevelBufferRva).CopyTo(code,15);
        BitConverter.GetBytes(engine+EmptyLevelRva).CopyTo(code,22);
        return code;
    }
    public const uint TeamInfoCodeRva=0x290C7;
    public const int TeamStride=104,TeamNameLength=16;
    public static byte[] TeamInfoSignature(uint client)
    {
        // Actual TeamInfo: signed entity index *104, string buffer +12B31C,
        // CT->2 / TERRORIST->1 / other->0 at +12B31A. Relative calls/branches are fixed.
        var code=Convert.FromHexString("0FBFC06A108D14408D3490C1E6038D9E1CB3A201E8802A03005053E8195708006828419E0153E81E73080083C41485C0750B66C7861AB3A2010200EB26681C419E0153E80173080083C40885C0750B66C7861AB3A2010100EB0966C7861AB3A2010000");
        foreach(var (at,rva) in new (int,uint)[]{(16,TeamArray+2),(33,0xE4128),(53,TeamArray),(62,0xE411C),(82,TeamArray),(93,TeamArray)})
            BitConverter.GetBytes(client+rva).CopyTo(code,at);
        return code;
    }
    // Retained only to validate the supplied profile and diagnose the legacy getter.
    public static byte[] TeamSignature(uint client)=>new byte[]{0x8b,0x44,0x24,0x04,0x85,0xc0,0x7c,0x14,0x83,0xf8,0x40,0x7f,0x0f,0x8d,0x0c,0x40,0x8d,0x14,0x88,0x0f,0xbf,0x04,0xd5}.Concat(BitConverter.GetBytes(client+LegacyTeamArray)).Concat(new byte[]{0xc3}).ToArray();
    private bool In(string module,uint address,int length)=>memory.Modules.TryGetValue(module,out uint b) && memory.ModuleSizes.TryGetValue(module,out uint size) && address>=b && (ulong)address+(uint)length<=(ulong)b+size;
    private bool Bytes(uint address,int length,out byte[] data){data=new byte[length];return memory.ReadBytes(address,data);}
    public static string NormalizeMap(string path)
    {
        path=path.Replace('\\','/').ToLowerInvariant();
        if(path.StartsWith("maps/",StringComparison.Ordinal))path=path[5..];
        if(path.EndsWith(".bsp",StringComparison.Ordinal))path=path[..^4];
        if(path.Length is <1 or >32 || path.Any(c=>!char.IsAsciiLetterOrDigit(c) && c!='_' && c!='-'))throw new FormatException("Invalid level name: expected safe GoldSrc map name");
        return path;
    }
    public bool TryRead(int movementPlayerIndex,out WorldState state,out string reason)
    {
        state=new("",0,false,false,0,false,default);reason="";
        if(!memory.Modules.TryGetValue("client.dll",out uint client) || !memory.Modules.TryGetValue("hw.dll",out uint engine)){reason="modules not ready";return false;}
        if(movementPlayerIndex is <0 or >=32){reason="invalid local movement player index";return false;}
        var expected=TeamSignature(client);
        if(!Bytes(client+0x45350,expected.Length,out var code) || !code.SequenceEqual(expected)){reason="HUD_GetPlayerTeam signature differs";return false;}
        var teamInfoCode=TeamInfoSignature(client);
        if(!In("client.dll",client+TeamInfoCodeRva,teamInfoCode.Length) || !Bytes(client+TeamInfoCodeRva,teamInfoCode.Length,out var actualTeamInfo) || !actualTeamInfo.SequenceEqual(teamInfoCode))
        {reason="TeamInfo handler signature differs/unreadable; no team guessed";return false;}
        if(!memory.ReadUInt32(client+EngineTable+0x128,out uint function) || !In("hw.dll",function,6)){reason="GetLevelName pointer unavailable";return false;}
        uint entry=function,level=0,profileState=0;int connectionState=0,nameLength=64;
        for(int hop=0;hop<3;hop++)
        {
            if(!In("hw.dll",function,6) || !Bytes(function,6,out code)){reason="GetLevelName code unreadable";return false;}
            if(code[0]==0xe9){long target=(long)function+5+BitConverter.ToInt32(code,1);if(target<0 || target>uint.MaxValue)break;function=(uint)target;continue;}
            if(code[0]==0xff && code[1]==0x15 && function==engine+LevelFunctionRva)
            {
                var signature=LevelSignature(engine);
                if(!In("hw.dll",function,signature.Length) || !Bytes(function,signature.Length,out var fullCode))
                {reason="GetLevelName profile code unreadable; no map guessed";return false;}
                if(!fullCode.SequenceEqual(signature))
                {reason=$"GetLevelName profile signature differs at 0x{function:X} bytes={Convert.ToHexString(fullCode)}; no map guessed";return false;}
                profileState=engine+ConnectionStateRva;
                if(!In("hw.dll",profileState,4) || !memory.ReadInt32(profileState,out connectionState))
                {reason="GetLevelName connection state unreadable; no map guessed";return false;}
                // Mirror the verified signed state>=3 branch. Never read old map text in the empty-return branch.
                if(connectionState<3){reason=$"level not ready: GetLevelName state={connectionState} (<3); input remains neutral";return false;}
                level=engine+LevelBufferRva;nameLength=LevelBufferLength;
            }
            else if(code[0]==0xb8 && code[5]==0xc3)level=BitConverter.ToUInt32(code,1);
            else if(code[0]==0xa1 && code[5]==0xc3 && In("hw.dll",BitConverter.ToUInt32(code,1),4))memory.ReadUInt32(BitConverter.ToUInt32(code,1),out level);
            break;
        }
        if(level==0){reason=$"unsupported GetLevelName return stub at 0x{function:X} bytes={Convert.ToHexString(code)}; no map guessed";return false;}
        if(!In("hw.dll",level,nameLength) || !Bytes(level,nameLength,out var name))
        {reason=$"GetLevelName decoded but level buffer unreadable at 0x{level:X} length={nameLength}; no map guessed";return false;}
        int zero=Array.IndexOf(name,(byte)0);if(zero<0){reason="unterminated level name";return false;}
        string map;
        try{map=NormalizeMap(Encoding.ASCII.GetString(name,0,zero));}catch(FormatException ex){reason=$"{ex.Message}; raw={System.Text.Json.JsonSerializer.Serialize(Encoding.ASCII.GetString(name,0,zero))}; bytes={Convert.ToHexString(name.AsSpan(0,zero))}; level=0x{level:X}; connectionState={connectionState}; no map guessed";return false;}
        var bombProfile=BombHudProfile.Signature(client);
        if(!Bytes(client+BombHudProfile.DropRva,bombProfile.Length,out var actualDrop) || !actualDrop.SequenceEqual(bombProfile)){reason="BombDrop/Pickup profile differs; no bomb state guessed";return false;}
        int entityIndex=movementPlayerIndex+1;
        uint teamAddress=client+TeamArray+(uint)entityIndex*TeamStride;
        if(!Bytes(teamAddress,2,out var t) || !Bytes(teamAddress+2,TeamNameLength,out var teamText) || !Bytes(client+Icons,52*4,out var icons) || !Bytes(client+BombData,52,out var bomb) || !memory.ReadUInt32(client+WeaponPointer,out uint weapon))
        {reason="HUD team/icon/weapon/bomb snapshot unreadable";return false;}
        int team=BitConverter.ToInt16(t);if(team is <0 or >2){reason="TeamInfo number outside 0..2";return false;}
        int teamZero=Array.IndexOf(teamText,(byte)0);
        if(teamZero<0 || teamText.Take(teamZero).Any(c=>c<32 || c>126))
        {reason="invalid/unterminated TeamInfo name";return false;}
        string teamName=Encoding.ASCII.GetString(teamText,0,teamZero);
        int namedTeam=teamName.Equals("TERRORIST",StringComparison.OrdinalIgnoreCase)?1:teamName.Equals("CT",StringComparison.OrdinalIgnoreCase)?2:0;
        if(namedTeam!=team){reason=$"TeamInfo number/name disagree: entity={entityIndex}; number={team}; name={teamName}; no team guessed";return false;}
        // Legacy field is diagnostic only. Do not prefer it, the C4 icon, spawn position or adjacent rows.
        int legacyTeam=Bytes(client+LegacyTeamArray+(uint)entityIndex*TeamStride,2,out var legacy)?BitConverter.ToInt16(legacy):-1;
        int weaponId=0;
        if(weapon!=0)
        {
            long relative=(long)weapon-client-Weapons;
            if(relative<0 || relative%328!=0 || relative/328>31){reason="active weapon pointer outside checked weapon array";return false;}
            weaponId=(int)(relative/328);
        }
        bool has=false,plant=false,buyZone=false;
        for(int i=0;i<4;i++)
        {
            int at=i*52,end=Array.IndexOf(icons,(byte)0,at,24);if(end<0){reason="unterminated status icon";return false;}
            string icon=Encoding.ASCII.GetString(icons,at,end-at);
            if(icon=="buyzone" && BitConverter.ToInt32(icons,at+24)!=0)buyZone=true;
            if(icon=="c4" && BitConverter.ToInt32(icons,at+24)!=0)
            {
                int flash=BitConverter.ToInt32(icons,at+48);if(flash is <0 or >1){reason="invalid c4 flash state";return false;}
                has=true;plant=flash==1;
            }
        }
        int active=BitConverter.ToInt32(bomb,16),planted=BitConverter.ToInt16(bomb,24);
        if(active is <0 or >1 || planted is <0 or >1){reason="invalid HUD bomb flags";return false;}
        var point=new ProbeVector(BitConverter.ToSingle(bomb,0),BitConverter.ToSingle(bomb,4),BitConverter.ToSingle(bomb,8));
        int flashes=BitConverter.ToInt32(bomb,20);
        if(flashes is <0 or >99999){reason="invalid HUD bomb display counter";return false;}
        bool isPlanted=BombHudProfile.Present(bomb);
        if(isPlanted && (!point.IsFinite || Math.Abs(point.X)>32768 || Math.Abs(point.Y)>32768 || Math.Abs(point.Z)>32768)){reason="invalid bomb coordinates";return false;}
        // Reject context changes across the non-atomic set of reads.
        if(!Bytes(teamAddress,2,out var teamAgain) || !teamAgain.SequenceEqual(t) || !Bytes(teamAddress+2,TeamNameLength,out var teamTextAgain) || !teamTextAgain.SequenceEqual(teamText) || !Bytes(level,nameLength,out var levelAgain) || !levelAgain.SequenceEqual(name) || !Bytes(client+BombData,52,out var bombAgain) || !BombHudProfile.Same(bomb,bombAgain) || !Bytes(client+Icons,208,out var iconsAgain) || !iconsAgain.SequenceEqual(icons) || !memory.ReadUInt32(client+WeaponPointer,out uint weaponAgain) || weaponAgain!=weapon)
        {reason="world context changed during snapshot";return false;}
        if(!memory.ReadUInt32(client+EngineTable+0x128,out uint entryAgain) || entryAgain!=entry ||
            (profileState!=0 && (!memory.ReadInt32(profileState,out int stateAgain) || stateAgain!=connectionState)))
        {reason="level function/state changed during snapshot";return false;}
        state=new(map,team,has,plant,weaponId,isPlanted,point){InBuyZone=buyZone,LocalEntityIndex=entityIndex,TeamName=teamName,TeamSource="TeamInfo",LegacyTeam=legacyTeam};return true;
    }
}
