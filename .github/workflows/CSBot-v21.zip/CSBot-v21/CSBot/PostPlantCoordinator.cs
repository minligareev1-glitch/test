namespace CSBot;
internal sealed class PostPlantCoordinator
{
    private string _bomb="";private bool _arrived;private long _until;
    public int Revision {get;private set;}
    public ProbeVector? Previous {get;private set;}
    public bool Holding {get;private set;}
    public static bool Active(WorldState w,BotSettings s)=>s.AutoObjectives=="on" && s.PostPlantMode!="off" && w.Team==1 && w.BombPlanted;
    public void Reset(){_bomb="";_arrived=false;_until=0;Revision=0;Previous=null;Holding=false;}
    public void Observe(WorldState w,long now,BotSettings s)
    {
        if(!Active(w,s)){Reset();return;}
        string key=MissionPlanner.GoalKey(w);
        if(key!=_bomb){Reset();_bomb=key;}
        if(_arrived && now>=_until){Revision++;_arrived=false;Holding=false;}
    }
    public void Arrived(string kind,ProbeVector target,long now,BotSettings s)
    {
        if(_arrived)return;
        _arrived=true;Previous=target;Holding=kind=="post-plant-cover";_until=now+(Holding?s.PostPlantHoldMs:0);
    }
}
