namespace CSBot;

internal sealed record TravelCommand(bool Forward,int MouseDx,bool Finished,string StopReason,int TargetIndex, double DesiredYaw=0, double YawError=0, double MouseGain=0, string Mode="", bool Walk=true,int MouseDy=0,bool Attack=false,bool Use=false,bool SelectC4=false,byte TapScan=0);
internal sealed class LiveSampleGuard
{
    private MoveSample? _last;
    private long _lastChanged, _lastWall, _airSince=-1;
    public int Advances { get; private set; }
    public string Observe(MoveSample s,int hp,long now,bool permitSupportedAir=false,int airGraceMs=120)
    {
        if(hp<=0 || hp>500 || s.Dead!=0 || s.DeadFlag!=0 || s.Spectator!=0) return "dead/spectator/invalid HP";
        if(s.Server!=0) return $"not client movement: server={s.Server}";
        if(s.FrameTime<=0 || s.FrameTime>0.2f) return $"invalid frameTime={s.FrameTime:R}; onGround={s.OnGround}";
        if(s.OnGround<0)
        {
            if(!permitSupportedAir) return $"not grounded: onGround={s.OnGround}; vz={s.Velocity.Z:F3}";
            if(_airSince<0)_airSince=now;
            if(airGraceMs is <1 or >500 || now-_airSince>airGraceMs) return $"supported-air grace exceeded {airGraceMs}ms";
        }
        else _airSince=-1;
        if((s.Flags & ((1<<14)|(1<<12)))!=0) return "crouched or frozen: standing walking only";
        if(!s.Origin.IsFinite || !s.Angles.IsFinite || !s.Velocity.IsFinite || !float.IsFinite(s.Time)) return "non-finite sample";
        if(_last.HasValue)
        {
            var previous=_last.Value;
            if(now<=_lastWall || now-_lastWall>250) return "sampling gap exceeds 250ms";
            if(s.Pointer!=previous.Pointer || s.PlayerIndex!=previous.PlayerIndex || s.Time<previous.Time) return "movement context/time changed";
            if(NavGraph.Distance(s.Origin,previous.Origin)>64) return "position discontinuity >64 units";
            if(s.Time!=previous.Time) { _lastChanged=now; Advances++; }
            else if(now-_lastChanged>250) return "stale playermove time >250ms";
        }
        else _lastChanged=now;
        _last=s; _lastWall=now; return "";
    }
}

internal sealed class TravelController
{
    private readonly IReadOnlyList<ProbeVector> _targets;
    private readonly Func<ProbeVector,ProbeVector,WalkCheck> _walk;
    private readonly PulseSteering _steering;
    private readonly TravelOptions _options;
    private readonly BotSettings _s;
    private int _steeringTarget=-1;
    private readonly bool _noShift;private readonly bool _adaptiveLookahead;private ProbeVector? _lookPosition;private int _lookIndex=-1;
    private readonly Func<ProbeVector,double,double,WalkCheck> _predict;
    private float? _sampleTime;
    private bool _walkingAligned;
    private int _index;
    private long _progressSince=-1, _turnSince=-1, _blockedSince=-1;
    private ProbeVector _progressPosition;

    public TravelController(IReadOnlyList<ProbeVector> targets,Func<ProbeVector,ProbeVector,WalkCheck> walk,double degreesPerCount,TravelOptions? options=null,Func<ProbeVector,double,double,WalkCheck>? predict=null,BotSettings? settings=null,bool adaptiveLookahead=false,bool noShift=false)
    {
        if(targets.Count==0 || targets.Any(p=>!p.IsFinite) || !double.IsFinite(degreesPerCount) || degreesPerCount is <0.001 or >2)
            throw new ArgumentException("Invalid route/calibration");
        _noShift=noShift;_adaptiveLookahead=adaptiveLookahead;_s=settings??new();_targets=targets; _walk=walk; _options=options??TravelOptions.Cautious;
        _steering=new PulseSteering(degreesPerCount,_options.Combined,_s);
        _predict=predict??((from,yaw,distance)=>_walk(from,new((float)(from.X+Math.Cos(yaw*Math.PI/180)*distance),(float)(from.Y+Math.Sin(yaw*Math.PI/180)*distance),from.Z)));
    }
    private void AdvanceStraightLookahead(ProbeVector from)
    {
        if(_adaptiveLookahead)
        {
            if(_lookIndex==_index && _lookPosition is { } previous && NavGraph.Distance(previous,from)<16)return;
            _lookPosition=from;_lookIndex=_index;
            int far=RouteLookahead.Select(_targets,from,_index,_s.NavPathLookahead,_s.NavPathScanNodes,_walk,4);
            if(far!=_index){_index=far;_lookIndex=far;_progressSince=-1;}
            return;
        }
        int chosen=_index;
        for(int i=_index+1;i<Math.Min(_targets.Count,_index+_s.LookaheadNodes+1);i++)
        {
            var to=_targets[i]; double length=NavGraph.Distance(from,to);
            if(length>_s.LookaheadUnits) break;
            double dx=to.X-from.X,dy=to.Y-from.Y,den=dx*dx+dy*dy;
            if(den<1) continue;
            bool straight=true;
            for(int k=_index;k<i;k++)
            {
                var p=_targets[k];double t=((p.X-from.X)*dx+(p.Y-from.Y)*dy)/den;
                double distance=Math.Sqrt(Math.Pow(p.X-(from.X+t*dx),2)+Math.Pow(p.Y-(from.Y+t*dy),2));
                if(t<0 || t>1 || distance>_s.LookaheadLateral || Math.Abs(p.Z-(from.Z+t*(to.Z-from.Z))) >_s.LookaheadHeight) {straight=false;break;}
            }
            if(straight && _walk(from,to).Safe) chosen=i;
        }
        if(chosen!=_index) { _index=chosen;_progressSince=-1; }
    }
    private TravelCommand Combined(MoveSample s,long now,ProbeVector target,double yaw,double error,SteeringStep steering,bool turnNeeded)
    {
        TravelCommand Command(bool forward,bool walk,string phase)=>new(forward,steering.MouseDx,false,"",_index,yaw,error,steering.Gain,phase,_noShift?false:walk);
        double speed=s.Velocity.Length;
        double remaining=Math.Sqrt(Math.Pow(target.X-s.Origin.X,2)+Math.Pow(target.Y-s.Origin.Y,2));
        // First calibrate without moving. Large heading changes are intentionally stationary.
        bool canMove=!steering.HoldMovement && Math.Abs(error)<=(_noShift?_s.RunMaxErrorDeg:_s.MoveMaxErrorDeg) && (!steering.Waiting || _steering.LastMeasuredGain>0);
        if(!canMove)
        {
            _walkingAligned=false;_progressSince=-1;
            if(_turnSince<0)_turnSince=now;
            if(now-_turnSince>_s.TurnTimeoutMs) return new(false,0,false,"turn timeout: feedback did not converge",_index);
            return Command(false,true,"turn-"+steering.Mode);
        }
        _turnSince=-1;_walkingAligned=true;
        // Forecast actual heading rather than assuming that the avatar already faces its target.
        double distance=Math.Clamp(speed*_s.ForecastReactionSeconds+speed*speed/_s.ForecastBrakeDivisor,_s.ForecastMinUnits,_s.ForecastMaxUnits);
        bool headingSafe=_predict(s.Origin,s.Angles.Y,distance).Safe;
        double horizontalSpeed=Math.Sqrt((double)s.Velocity.X*s.Velocity.X+(double)s.Velocity.Y*s.Velocity.Y);
        if(headingSafe && horizontalSpeed>40)
        {
            double momentumYaw=Math.Atan2(s.Velocity.Y,s.Velocity.X)*180/Math.PI;
            headingSafe=_predict(s.Origin,momentumYaw,distance).Safe;
        }
        if(!headingSafe)
        {
            _progressSince=-1;
            if(_blockedSince<0)_blockedSince=now;
            if(now-_blockedSince>_s.BlockedTimeoutMs) return new(false,0,false,$"heading clearance blocked for >{_s.BlockedTimeoutMs}ms",_index);
            return Command(false,true,"heading-clearance-brake");
        }
        _blockedSince=-1;
        bool straightAhead=true;
        if(_index+1<_targets.Count)
        {
            var next=_targets[_index+1];double exit=Math.Atan2(next.Y-target.Y,next.X-target.X)*180/Math.PI;
            straightAhead=Math.Abs(Normalize(exit-yaw))<_s.RunMaxNextTurnDeg;
        }
        bool run=_options.RunOnClear && Math.Abs(error)<=_s.RunMaxErrorDeg && (_options.PreferRun ||
            (remaining>Math.Max(_s.RunMinDistance,distance+20) && straightAhead && Math.Abs(target.Z-s.Origin.Z)<=_s.RunMaxHeightDelta));
        if(run)
        {
            double ahead=Math.Max(_s.RunProbeUnits,distance);
            run=_predict(s.Origin,s.Angles.Y,ahead).Safe && _predict(s.Origin,s.Angles.Y-_s.RunSideAngleDeg,ahead).Safe &&
                _predict(s.Origin,s.Angles.Y+_s.RunSideAngleDeg,ahead).Safe;
        }
        if(_progressSince<0) { _progressSince=now;_progressPosition=s.Origin; }
        else if(NavGraph.Distance(_progressPosition,s.Origin) >=_s.ProgressUnits) {_progressSince=now;_progressPosition=s.Origin;}
        else if(now-_progressSince>_s.ProgressTimeoutMs) return new(false,0,false,$"stuck: less than {_s.ProgressUnits} units progress in {_s.ProgressTimeoutMs}ms",_index);
        bool brake=remaining<Math.Max(18,distance*_s.CornerBrakeFactor) && speed>_s.CornerBrakeSpeed;
        return Command(!brake,!run,(brake?"corner-brake":_noShift?"run-no-shift":run?"run":"walk")+"+"+steering.Mode);
    }
    public static double Normalize(double angle)=>((angle+180)%360+360)%360-180;
    public TravelCommand Tick(MoveSample s,long now,bool focused)
    {
        TravelCommand Stop(string reason)=>new(false,0,false,reason,_index);
        if(!focused) return Stop("game lost foreground focus");
        if(Math.Abs(s.Angles.X)>25) return Stop("pitch outside +/-25 degrees; look near horizon before arming");
        if(s.Velocity.Length>(_options.RunOnClear?290:180)) return Stop("excessive speed for selected motion profile");
        if(_sampleTime.HasValue && s.Time==_sampleTime.Value) return new(false,0,false,"",_index,MouseGain:_steering.Gain,Mode:"wait-fresh-sample");
        _sampleTime=s.Time;
        while(_index<_targets.Count)
        {
            var t=_targets[_index];
            double d=Math.Sqrt(Math.Pow(t.X-s.Origin.X,2)+Math.Pow(t.Y-s.Origin.Y,2));
            if(d>(_index==_targets.Count-1?_s.GoalRadius:_s.WaypointRadius) || Math.Abs(t.Z-s.Origin.Z)>_s.WaypointHeightTolerance) break;
            _index++; _progressSince=-1; _walkingAligned=false;
        }
        if(_index==_targets.Count) return new(false,0,true,"",_index);
        if(_options.Combined) AdvanceStraightLookahead(s.Origin);
        if(_steeringTarget!=_index){_steering.BeginSegment();_steeringTarget=_index;}
        var target=_targets[_index];
        var geometry=_walk(s.Origin,target);
        if(!geometry.Safe) return Stop("live path rejected: "+geometry.Reason);
        double yaw=Math.Atan2(target.Y-s.Origin.Y,target.X-s.Origin.X)*180/Math.PI;
        double error=Normalize(yaw-s.Angles.Y);
        // A normal 1.5-degree deadband can point into a wall on a narrow route.
        // Tighten only when the intended heading is verified safe; do not bypass hull checks.
        double tolerance=_options.Combined?_s.YawToleranceDeg:(_walkingAligned?6:2.5);
        bool precision=false;
        if(_options.Combined && Math.Abs(error)>_s.PrecisionToleranceDeg && Math.Abs(error)<=_s.YawToleranceDeg)
        {
            double distance=Math.Clamp(s.Velocity.Length*_s.ForecastReactionSeconds+s.Velocity.Length*s.Velocity.Length/_s.ForecastBrakeDivisor,_s.ForecastMinUnits,_s.ForecastMaxUnits);
            precision=!_predict(s.Origin,s.Angles.Y,distance).Safe && _predict(s.Origin,yaw,distance).Safe;
            if(precision)tolerance=_s.PrecisionToleranceDeg;
        }
        bool turnNeeded=Math.Abs(error)>tolerance;
        var steering=_steering.Tick(s.Angles.Y,error,now,turnNeeded,s.Velocity.Length);
        if(precision && steering.StopReason=="")steering=steering with{Mode="precision-"+steering.Mode};
        if(steering.StopReason!="") return Stop(steering.StopReason);
        if(_options.Combined)
            return Combined(s,now,target,yaw,error,steering,turnNeeded);
        if(steering.Waiting || turnNeeded)
        {
            _walkingAligned=false; _progressSince=-1;
            if(_turnSince<0) _turnSince=now;
            if(now-_turnSince>_s.TurnTimeoutMs) return Stop("turn timeout: feedback did not converge");
            return new(false,steering.MouseDx,false,"",_index,yaw,error,steering.Gain,steering.Mode);
        }
        _walkingAligned=true;
        _turnSince=-1;
        if(_progressSince<0) { _progressSince=now; _progressPosition=s.Origin; }
        else if(NavGraph.Distance(_progressPosition,s.Origin) >=_s.ProgressUnits) { _progressSince=now; _progressPosition=s.Origin; }
        else if(now-_progressSince>_s.ProgressTimeoutMs) return Stop($"stuck: less than {_s.ProgressUnits} units progress in {_s.ProgressTimeoutMs}ms");
        double remaining=Math.Sqrt(Math.Pow(target.X-s.Origin.X,2)+Math.Pow(target.Y-s.Origin.Y,2));
        // Release forward early near corners/endpoints, relying on normal game friction.
        if(remaining<32 && s.Velocity.Length>40) return new(false,0,false,"",_index,yaw,error,steering.Gain,"brake");
        return new(true,0,false,"",_index,yaw,error,steering.Gain,"walk");
    }
}
