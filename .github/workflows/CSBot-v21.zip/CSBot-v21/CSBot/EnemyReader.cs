using System.Text;
namespace CSBot;
internal sealed record EnemyState(int Index,int Team,ProbeVector Origin,ProbeVector AimPoint,int Message,float MessageTime)
{
    public ProbeVector? HeadPoint {get;init;}
    public ProbeVector? BoundsMin {get;init;}
    public ProbeVector? BoundsMax {get;init;}
    public double FacingYaw {get;init;}
    public bool MuzzleFlash {get;init;}
    public long ObservedAtMs {get;init;}=-1;
}
// Read-only supplied hw.dll profile + GoldSrc 32-bit cl_entity_t layout.
// No remote calls. Unknown/dormant/unreadable entries never become targets.
internal sealed class EnemyReader(IGameMemory memory)
{
    public const uint EntityCode=0x19590,MaxCode=0x19460,ClockCode=0x195D0,EntityRoot=0x1AFBFC,EntityLimit=0x102BDC0,MaxClients=0x11CF2A4,Clock=0x1056D58;
    public const int Stride=3000,State=0x2B0,HeaderSize=0x37C;
    public static byte[] EntitySignature(uint engine)
    {
        var b=Convert.FromHexString("8d44240450ff15b4c8e7018b44240883c40485c07c1e3b05c0bdd2027d168d04408b15fcfbea018d04808d04808d0c808d04cac333c0c3");
        foreach(int at in new[]{7,24,35})BitConverter.GetBytes(unchecked(BitConverter.ToUInt32(b,at)-0x01D00000+engine)).CopyTo(b,at);return b;
    }
    public static byte[] MaxSignature(uint engine)
    {var b=Convert.FromHexString("ff1570c8e701a1a4f2ec02c3");BitConverter.GetBytes(engine+0x17C870).CopyTo(b,2);BitConverter.GetBytes(engine+MaxClients).CopyTo(b,7);return b;}
    public static byte[] ClockSignature(uint engine)
    {var b=Convert.FromHexString("51ff15b8c8e701dd05586dd502d95c2400d944240059c3");BitConverter.GetBytes(engine+0x17C8B8).CopyTo(b,3);BitConverter.GetBytes(engine+Clock).CopyTo(b,9);return b;}
    private bool Bytes(uint address,int size,out byte[] bytes){bytes=new byte[size];return memory.ReadBytes(address,bytes);}
    private bool Matches(uint at,byte[] expected)=>Bytes(at,expected.Length,out var actual)&&actual.SequenceEqual(expected);
    private bool Entity(uint root,int index,out byte[] data)=>Bytes(checked(root+(uint)index*Stride),HeaderSize,out data) && BitConverter.ToInt32(data,0)==index && BitConverter.ToInt32(data,4)==1;
    public bool TryRead(WorldState world,MoveSample sample,BotSettings s,out List<EnemyState> enemies,out string reason)=>Read(world,sample,s,false,out enemies,out reason);
    public bool TryReadPlayers(WorldState world,MoveSample sample,BotSettings s,out List<EnemyState> players,out string reason)=>Read(world,sample,s,true,out players,out reason);
    private bool Read(WorldState world,MoveSample sample,BotSettings s,bool includeFriends,out List<EnemyState> enemies,out string reason)
    {
        enemies=new();reason="";
        if(world.Team is not (1 or 2) || world.LocalEntityIndex is <1 or >32){reason="local team/index not valid";return false;}
        if(!memory.Modules.TryGetValue("hw.dll",out uint h) || !memory.Modules.TryGetValue("client.dll",out uint c) ||
            !Matches(h+EntityCode,EntitySignature(h)) || !Matches(h+MaxCode,MaxSignature(h)) || !Matches(h+ClockCode,ClockSignature(h)) ||
            !Matches(c+WorldStateReader.TeamInfoCodeRva,WorldStateReader.TeamInfoSignature(c)))
        {reason="entity/client clock/TeamInfo signature differs";return false;}
        if(!memory.ReadUInt32(c+WorldStateReader.EngineTable+53*4,out uint callback) || callback!=h+EntityCode ||
            !memory.ReadUInt32(h+EntityRoot,out uint root) || root<0x10000 || (root&3)!=0 ||
            !memory.ReadInt32(h+EntityLimit,out int limit) || limit is <33 or >4096 || (ulong)root+(uint)limit*Stride>uint.MaxValue ||
            !memory.ReadInt32(h+MaxClients,out int max) || max is <1 or >32 || world.LocalEntityIndex>max ||
            !Bytes(h+Clock,8,out var clockBytes))
        {reason="entity root/client count/clock unavailable";return false;}
        double clock=BitConverter.ToDouble(clockBytes);if(!double.IsFinite(clock) || clock<0){reason="invalid client clock";return false;}
        if(!Entity(root,world.LocalEntityIndex,out var local)){reason="local entity snapshot unavailable";return false;}
        int message=BitConverter.ToInt32(local,State+12);if(message<=0){reason="local message number unavailable";return false;}
        for(int id=1;id<=max;id++)
        {
            if(id==world.LocalEntityIndex || !Entity(root,id,out var data))continue;
            int I(int offset)=>BitConverter.ToInt32(data,State+offset);
            float F(int offset)=>BitConverter.ToSingle(data,State+offset);
            var origin=new ProbeVector(F(16),F(20),F(24));float time=F(8);
            int hull=I(200),model=I(40),effects=I(60),spectator=I(176),number=I(4);
            if(number!=id || I(12)!=message || !float.IsFinite(time) || clock-time<-.1 || (clock-time)*1000>s.AimMaxStateAgeMs ||
                model<=0 || BitConverter.ToInt16(data,State+58) is not (2 or 3) || spectator!=0 || (effects&128)!=0 || hull is <0 or >1 ||
                !origin.IsFinite || Math.Abs(origin.X)>32768 || Math.Abs(origin.Y)>32768 || Math.Abs(origin.Z)>32768 || NavGraph.Distance(sample.Origin,origin)>s.AimMaxDistance)continue;
            uint address=c+WorldStateReader.TeamArray+(uint)id*WorldStateReader.TeamStride;
            if(!Bytes(address,18,out var team))continue;
            int teamId=BitConverter.ToInt16(team);int zero=Array.IndexOf(team,(byte)0,2,16);if(zero<0)continue;
            string name=Encoding.ASCII.GetString(team,2,zero-2);
            if((!includeFriends && teamId==world.Team) || teamId is not (1 or 2) || name!=(teamId==1?"TERRORIST":"CT"))continue;
            if(!Bytes(address,18,out var again) || !team.SequenceEqual(again) || !Entity(root,id,out var againEntity) || !data.SequenceEqual(againEntity))continue;
            var mins=new ProbeVector(F(124),F(128),F(132));var maxs=new ProbeVector(F(136),F(140),F(144));
            bool bounds=mins.IsFinite && maxs.IsFinite && mins.X is >=-32 and <=-8 && maxs.X is >=8 and <=32 && mins.Y is >=-32 and <=-8 && maxs.Y is >=8 and <=32 && mins.Z is >=-40 and <=-8 && maxs.Z is >=12 and <=40;
            if(!bounds){mins=new(-16,-16,hull==1?-18:-36);maxs=new(16,16,hull==1?18:36);}
            var head=new ProbeVector(origin.X,origin.Y,origin.Z+maxs.Z-8);
            enemies.Add(new(id,teamId,origin,new(origin.X,origin.Y,origin.Z+(hull==1?8:12)),message,time)
            {HeadPoint=head,BoundsMin=mins,BoundsMax=maxs,FacingYaw=F(32),MuzzleFlash=(effects&2)!=0});
        }
        if(!memory.ReadUInt32(h+EntityRoot,out uint rootAgain) || rootAgain!=root || !memory.ReadInt32(h+MaxClients,out int maxAgain) || maxAgain!=max ||
            !memory.ReadUInt32(c+WorldStateReader.EngineTable+53*4,out uint callbackAgain) || callbackAgain!=callback ||
            !Entity(root,world.LocalEntityIndex,out var localAgain) || BitConverter.ToInt32(localAgain,State+12)!=message ||
            !Bytes(h+Clock,8,out var clockAgain) || !double.IsFinite(BitConverter.ToDouble(clockAgain)) || BitConverter.ToDouble(clockAgain)<clock || BitConverter.ToDouble(clockAgain)-clock>.1)
        {enemies.Clear();reason="entity context changed during snapshot";return false;}
        return true;
    }
}
