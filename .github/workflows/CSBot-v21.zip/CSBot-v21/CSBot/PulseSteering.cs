namespace CSBot;

internal sealed record SteeringStep(int MouseDx,bool Waiting,string StopReason,string Mode,double Gain,bool HoldMovement=false);
internal sealed class PulseSteering
{
    private readonly bool _fast;
    private readonly BotSettings _s;
    private bool _pending;
    private int _dx, _pulses, _reversals, _lastSign, _retries;
    private double _startYaw, _lastYaw, _gain, _cap=4;
    private long _sentAt, _changedAt;
    public double Gain=>_gain;
    public double LastMeasuredGain {get;private set;}
    public PulseSteering(double seed,bool fast=false,BotSettings? settings=null) { _s=settings??new();_gain=seed;_fast=fast;BeginSegment(); }
    // Keep in-flight feedback and measured gain; only reset the budget for a new target.
    public void BeginSegment(){_pulses=0;_reversals=0;_lastSign=0;_cap=_fast?_s.MouseTurnMaxDeg:4;}
    public int PulseCount=>_pulses;
    public static double Normalize(double value)=>((value+180)%360+360)%360-180;
    public SteeringStep Tick(double yaw,double error,long now,bool turnNeeded,double motionSpeed=0)
    {
        SteeringStep Result(int dx,bool wait,string mode,string stop="",bool hold=false)=>new(dx,wait,stop,mode,_gain,hold);
        if(_pending)
        {
            double delta=Normalize(yaw-_startYaw);
            if(Math.Abs(Normalize(yaw-_lastYaw))>.02) _changedAt=now;
            _lastYaw=yaw;
            long age=now-_sentAt;
            if(Math.Abs(delta)<.03 && _fast && age>=_s.MouseRetryBrakeMs)
            {
                // A missing response is not permission for a burst. Brake first, then
                // retry within configured budget, each packet <=8 counts, waiting for feedback again.
                if(age>=_s.MouseRetryAfterMs && motionSpeed<=10 && _retries<_s.MouseRetryCount)
                {
                    _retries++;_dx=Math.Sign(_dx)*Math.Min(Math.Abs(_dx),8);
                    _startYaw=_lastYaw=yaw;_sentAt=_changedAt=now;
                    return Result(_dx,true,$"retry-pulse-{_retries}",hold:true);
                }
                if(age>_s.MouseResponseTimeoutMs || (_retries>=_s.MouseRetryCount && age>_s.MouseNoResponseMs))
                    return Result(0,true,"no-response","mouse input has no yaw response after bounded retry/brake",true);
                return Result(0,true,"retry-brake",hold:true);
            }
            if(age>_s.MouseNoResponseMs && Math.Abs(delta)<.03) return Result(0,true,"no-response","mouse input has no yaw response to isolated pulse");
            if(age>_s.MouseResponseTimeoutMs && now-_changedAt<(_fast?_s.MouseQuietMs:_s.MouseInitialQuietMs)) return Result(0,true,"unsettled","mouse response did not settle after isolated pulse");
            if(age<(_fast && LastMeasuredGain>0?_s.MouseSettleMs:_s.MouseInitialSettleMs) || now-_changedAt<(_fast && LastMeasuredGain>0?_s.MouseQuietMs:_s.MouseInitialQuietMs) || Math.Abs(delta)<.03) return Result(0,true,"settling",hold:_retries>0);
            if(delta*(-_dx)<=0) return Result(0,true,"wrong-sign","mouse yaw response has unexpected sign; no further pulses sent");
            double measured=Math.Abs(delta/_dx);
            if(!double.IsFinite(measured) || measured is <.0005 or >2)
                return Result(0,true,"invalid-gain","mouse yaw response outside supported range");
            if(Math.Abs(delta)>(_fast?30:15) || (LastMeasuredGain>0 && measured/LastMeasuredGain>4))
                return Result(0,true,"abrupt-response","mouse response changed abruptly; feedback reset required");
            LastMeasuredGain=measured;
            // A little extra gain makes the next command smaller, not larger.
            _gain=Math.Clamp(measured*_s.MouseGainMargin,.001,2); _pending=false;_retries=0;
        }
        if(!turnNeeded) { BeginSegment();return Result(0,false,"aligned"); }
        int sign=Math.Sign(error);
        if(_lastSign!=0 && sign!=_lastSign) {_reversals++;_cap=Math.Max(.5,_cap*.5);}
        _lastSign=sign;
        if(_reversals>=_s.MouseMaxReversals)return Result(0,false,"unstable",$"unstable mouse feedback: repeated reversals ({_reversals}); pulses={_pulses}");
        if(++_pulses>_s.MousePulseBudget)return Result(0,false,"pulse-budget",$"mouse pulse budget exhausted for current waypoint: pulses={_pulses}; reversals={_reversals}");
        // Unknown actual response: first pulse is deliberately tiny. No accumulated pulse stream.
        int limit=LastMeasuredGain==0?_s.MouseFirstMaxCounts:_s.MouseMaxCounts;
        double cap=_fast && Math.Abs(error)<=_s.MouseNearErrorDeg?Math.Min(_s.MouseNearTurnMaxDeg,_cap):_cap;
        double requestedAngle=Math.Min(cap,Math.Abs(error)*(_fast?_s.MouseFastFraction:_s.MouseSlowFraction));
        int counts=Math.Clamp((int)Math.Floor(requestedAngle/_gain),1,limit);
        _dx=-sign*counts;_startYaw=_lastYaw=yaw;_sentAt=_changedAt=now;_pending=true;
        return Result(_dx,true,"pulse");
    }
}
