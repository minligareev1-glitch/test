namespace CSBot;

internal readonly record struct ProbeVector(float X, float Y, float Z)
{
    public bool IsFinite => float.IsFinite(X) && float.IsFinite(Y) && float.IsFinite(Z);
    public double Length => Math.Sqrt((double)X * X + (double)Y * Y + (double)Z * Z);
    public double Dot(ProbeVector other) => (double)X * other.X + (double)Y * other.Y + (double)Z * other.Z;
    public override string ToString() => FormattableString.Invariant($"({X:F3},{Y:F3},{Z:F3})");
}

internal readonly record struct ViewFrame(ProbeVector Up, ProbeVector Right, ProbeVector Forward, ProbeVector Origin);
internal readonly record struct BasisCheck(bool Plausible, double UpLength, double RightLength,
    double ForwardLength, double MaxAbsDot);

internal static class ViewProbe
{
    // Diagnostic hypotheses based on the linked repository. Not a verified 2009-build profile.
    public static readonly (string Label, uint Rva)[] Candidates =
    {
        ("source-view", 0x12EAE0),
        ("legacy-comment", 0x12D9F0),
        ("readme-viewmatrix-hypothesis", 0x12EAF0)
    };
    public const uint Size = 48;

    public static ViewFrame Decode(byte[] buffer)
    {
        if (buffer.Length != Size) throw new ArgumentException("View requires exactly 48 bytes");
        ProbeVector Vector(int offset) => new(BitConverter.ToSingle(buffer, offset),
            BitConverter.ToSingle(buffer, offset + 4), BitConverter.ToSingle(buffer, offset + 8));
        return new ViewFrame(Vector(0), Vector(12), Vector(24), Vector(36));
    }

    public static BasisCheck CheckBasis(ViewFrame frame)
    {
        double up = frame.Up.Length, right = frame.Right.Length, forward = frame.Forward.Length;
        double dot = Math.Max(Math.Abs(frame.Up.Dot(frame.Right)),
            Math.Max(Math.Abs(frame.Up.Dot(frame.Forward)), Math.Abs(frame.Right.Dot(frame.Forward))));
        bool plausible = frame.Up.IsFinite && frame.Right.IsFinite && frame.Forward.IsFinite &&
            frame.Origin.IsFinite && Math.Abs(up - 1) <= 0.10 && Math.Abs(right - 1) <= 0.10 &&
            Math.Abs(forward - 1) <= 0.10 && dot <= 0.10;
        // A plausible orthonormal basis does NOT verify the origin, address, game state or player identity.
        return new BasisCheck(plausible, up, right, forward, dot);
    }
}
