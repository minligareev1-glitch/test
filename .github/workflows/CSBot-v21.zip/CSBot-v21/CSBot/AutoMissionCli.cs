using System.ComponentModel;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
namespace CSBot;

// Persistent supervisor: operational failures neutralize input and wait/replan.
// It never continues blind input with lost focus or untrusted state.
internal static class AutoMissionCli
{
    private static bool Expected(Exception ex)=>ex is InvalidDataException or IOException or UnauthorizedAccessException or ArgumentException or InvalidOperationException or Win32Exception or NotSupportedException or FormatException or OverflowException or JsonException;
    public static bool TryRun(string[] args,out int exit)
    {
        exit=0;if(args.Length==0 || args[0]!="--auto-bot")return false;
        try{exit=Run(args);}catch(Exception ex)when(Expected(ex)){Console.Error.WriteLine("Setup error (no blind input): "+ex.Message);exit=2;}
        return true;
    }
    private static int Run(string[] args)
    {
        string settingsPath=Path.GetFullPath("config.txt"),root=Path.GetFullPath("."),logPath="auto-bot.log",jsonPath="auto-plan.json";
        string? gameCfg=null;int? pid=null;bool execute=false;
        for(int i=1;i<args.Length;i++)
        {
            string Value(){if(++i>=args.Length)throw new ArgumentException("Missing option value");return args[i];}
            switch(args[i])
            {
                case "--settings":settingsPath=Path.GetFullPath(Value());break;
                case "--assets":root=Path.GetFullPath(Value());break;
                case "--config":gameCfg=Value();break;
                case "--log":logPath=Value();break;
                case "--json":jsonPath=Value();break;
                case "--pid":if(!int.TryParse(Value(),NumberStyles.None,CultureInfo.InvariantCulture,out int value) || value<=0)throw new ArgumentException("Invalid PID");pid=value;break;
                case "--execute":execute=true;break;
                case "--confirm-local-bots":break; // accepted only for old script compatibility; no confirmation required
                default:throw new ArgumentException("Unknown auto option: "+args[i]);
            }
        }
        var settings=BotSettings.Load(settingsPath);
        var difficulty=DifficultyProfile.Resolve(settings);difficulty.Apply(settings);settings.Validate();
        settings.Motion="run"; // v19 AUTO always requests W-only running; no Shift mode
        if(!OperatingSystem.IsWindows())throw new NotSupportedException("Windows x64 required; offline tests/check-settings work without game");
        using var log=new StreamWriter(logPath,false,new UTF8Encoding(false)){AutoFlush=true};
        void Log(string text){string line=$"[{DateTimeOffset.Now:O}] {text}";Console.WriteLine(line);log.WriteLine(line);}
        Log("CSBot v21 AUTO: automatic start/resume, no Shift, buy/combat autofire/difficulty, fixed bomb HUD; run preference, automatic map/team, read-only HUD objectives, pause/retry supervisor");settings.Report(Log);Log($"DIFFICULTY {difficulty.Name}; target={difficulty.AimPart}; reactionMs={difficulty.Reaction(settings)}; W-duty={difficulty.MoveDuty}; autoFire={settings.AutoFire}; rear={settings.RearTurn}");
        _=MapCatalog.RegisterMaps(root,Log); // Before any process/input ownership.
        using var cancellation=new CancellationTokenSource();
        ConsoleCancelEventHandler handler=(_,e)=>{e.Cancel=true;cancellation.Cancel();};Console.CancelKeyPress+=handler;
        ProcessMemory? mem=null;WindowsControl? input=null;CancellationTokenSource? planCancel=null;
        try
        {
            while(!cancellation.IsCancellationRequested && mem==null)
            {
                if(WindowsControl.KeyDown(0x78))return 0;
                mem=ProcessMemory.Attach("hl",pid);if(mem==null){Log("WAIT hl.exe; no input");Thread.Sleep(1000);}
            }
            if(mem==null)return 0;
            foreach(var (module,expected) in new[]{("client.dll","b474ecfbb6f2fc6c4aa48fceb0b5735dfe2cb23ce06ba0a1008137cd228c714a"),("hw.dll","319fd65a9151d42c451c9821a78a031d20da51fcc5db2f555de1651416469c3c")})
            {
                while(!mem.ModulePaths.ContainsKey(module) && !cancellation.IsCancellationRequested)
                {mem.RefreshModules();Log("WAIT module "+module);Thread.Sleep(500);if(WindowsControl.KeyDown(0x78))return 0;}
                if(cancellation.IsCancellationRequested)return 0;
                string actual=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(mem.ModulePaths[module]))).ToLowerInvariant();
                if(actual!=expected)throw new InvalidDataException("Unsupported DLL fingerprint: "+module);
            }
            if(gameCfg==null)
            {
                var directory=new DirectoryInfo(Path.GetDirectoryName(mem.ModulePaths["client.dll"])!);
                gameCfg=Path.Combine(directory.Name.Equals("cl_dlls",StringComparison.OrdinalIgnoreCase)?directory.Parent!.FullName:directory.FullName,"config.cfg");
            }
            var cfg=File.Exists(gameCfg)?GameConfig.Load(gameCfg):null;
            double seed=settings.DegreesPerCount>0?settings.DegreesPerCount:cfg?.DegreesPerCount??0;
            if(execute)
            {
                seed=GameConfig.ParseDpc(seed.ToString("R",CultureInfo.InvariantCulture));
                if(cfg==null)throw new InvalidDataException("Game CFG needed to verify input bindings");
                var binds=new List<(string Key,string Command)>{("w","+forward")};
                if(settings.AutoObjectives=="on")binds.AddRange(new[]{("5","slot5"),("MOUSE1","+attack"),("e","+use")});
                if(settings.EnemyAim=="on" && settings.AutoFire=="on")binds.Add(("MOUSE1","+attack"));
                foreach(var (key,command) in binds)if(cfg.Bindings.GetValueOrDefault(key)!=command)throw new InvalidDataException($"Required binding {key}={command} not confirmed in CFG");
            }
            cfg?.Report(Log);
            int pitchSign=1;
            if(cfg?.Values.TryGetValue("m_pitch",out var pitchValue)==true)
            {
                if(!GameConfig.TryNumber(pitchValue,out double pitch) || pitch==0)throw new InvalidDataException("Invalid/zero m_pitch: objective pitch control unavailable");
                pitchSign=Math.Sign(pitch);Log("CFG m_pitch="+pitchValue+"; pitch direction="+pitchSign);
            }
            else Log("CFG WARNING: m_pitch absent; standard positive pitch direction assumed; feedback failure will pause, never bypass checks");
            var worldReader=new WorldStateReader(mem);var probe=new MovementProbe(mem);var healthReader=new GameReader(mem,_=>{});
            var guard=new LiveSampleGuard();var respawn=new RespawnLifecycle(settings);var postPlant=new PostPlantCoordinator();var objective=new BombObjectives(seed>0?seed:.07106,settings,pitchSign);
            var buy=new BuyCoordinator(settings);buy.Configure(cfg);Log(buy.BindingReady?"BUY READY mode="+settings.BuyMode:"BUY DISABLED: "+buy.BindingIssue);
            var enemyReader=new EnemyReader(mem);var enemyAim=new EnemyAim(seed>0?seed:.07106,settings,pitchSign,cfg?.Bindings.GetValueOrDefault("1")=="slot1" && cfg.Bindings.GetValueOrDefault("2")=="slot2");
            var pacer=new MotionPacer(difficulty);var damage=new DamageAwareness();long lastCombatLog=-10000;var autoStart=new AutoStartGate(settings.AutoResumeMs);
            List<EnemyState> enemies=new();long nextEnemyScan=0,lastEnemyNotice=-10000;
            LoadedMap? asset=null;Task<LoadedMap>? loadTask=null;string loadingMap="",context="",goal="";
            Task<MissionRoute?>? routeTask=null;string routeContext="";ProbeVector routeOrigin=default;
            TravelController? controller=null;MissionRoute? route=null;
            FastNavigator? navigator=null;Task<FastNavigator>? navigatorTask=null;string navigatorMap="";
            long epoch=0,routeEpoch=-1,planStarted=0;
            ProbeVector? avoid=null;long avoidUntil=0;
            bool intent=false;long nextAttempt=0,stableAt=-1,lastState=-10000,lastNotice=-10000;
            ProbeVector stableOrigin=default;string lastMessage="";int attempts=0,adaptiveCap=settings.MouseMaxCounts;
            StepLandingPause? landing=null;
            void Notice(string message)
            {
                long now=Environment.TickCount64;
                if(message!=lastMessage || now-lastNotice>1000){Log(message);lastMessage=message;lastNotice=now;}
            }
            void Neutral()
            {
                if(input==null)return;
                if(input.Fault!=""){input.Dispose();input=null;intent=false;autoStart.Reset();return;}
                input.Heartbeat();input.Apply(new(false,0,false,"",-1,Mode:"supervisor-neutral",Walk:false));
            }
            void Invalidate()
            {
                controller=null;route=null;stableAt=-1;epoch++;planCancel?.Cancel();
            }
            void Pause(string reason,bool revoke=false)
            {
                Neutral();Invalidate();objective.Reset();
                nextAttempt=Environment.TickCount64+settings.AutoRetryMs;
                if(revoke){input?.Dispose();input=null;intent=false;autoStart.Reset();buy.Cancel();enemyAim.Reset();enemies.Clear();guard=new();landing=null;}
                Notice("PAUSE "+reason+(revoke?"; automatic rearm pending after stable focus/pose":"; input neutral, retry pending"));
            }
            Log($"PID={mem.ProcessId}; execute={execute}; AUTO START, no F8/confirmation; F9/Ctrl+C exits. Death releases input and waits. Focus/UI/watchdog release input; stable foreground + live pose enables automatic rearm. No complete chat/menu detection.");
            while(!cancellation.IsCancellationRequested && !mem.HasExited)
            {
                long now=Environment.TickCount64;
                try
                {
                    if(WindowsControl.KeyDown(0x78)){Neutral();Log("STOP USER F9");return 0;}
                    bool focus=WindowsControl.Focused(mem.ProcessId);
                    bool readyToStart=autoStart.Observe(focus,input==null && (WindowsControl.ManualBusy() || WindowsControl.StopHeld()),now);
                    if(input?.Fault is {Length:>0} fault){Pause(fault,true);Thread.Sleep(50);continue;}
                    if(input!=null && !focus){Pause("focus lost",true);Thread.Sleep(50);continue;}
                    input?.Heartbeat();
                    if(!healthReader.TryReadState(out var health))
                    {
                        if(!healthReader.DiscoverLocalPlayer() || !healthReader.TryReadState(out health)){Pause("HUD/health read: "+healthReader.LastFailure);guard=new();Thread.Sleep(100);continue;}
                    }
                    if(!probe.TryRead(out var sample,out string reason)){Pause("movement read: "+reason);guard=new();Thread.Sleep(50);continue;}
                    var lifeStep=respawn.Observe(sample,health.Health,now);
                    if(lifeStep.Waiting)
                    {
                        Neutral();
                        if(lifeStep.Entered){Invalidate();objective.Reset();postPlant.Reset();buy.Cancel(true);enemyAim.Reset();enemies.Clear();damage.Reset();pacer.Reset();guard=new();landing=null;goal="";avoid=null;Log("WAIT RESPAWN: owned input released; prior arm intent retained");}
                        Notice("WAIT RESPAWN: HP/death/spectator or fresh supported-frame warmup");Thread.Sleep(25);continue;
                    }
                    if(lifeStep.Resumed)
                    {Invalidate();objective.Reset();postPlant.Reset();buy.Cancel(true);enemyAim.Reset();enemies.Clear();damage.Reset();pacer.Reset();guard=new();landing=null;goal="";nextAttempt=0;Log("RESPAWN READY: fresh advancing grounded snapshots; rebuilding from actual position; intent="+intent);}
                    if(!worldReader.TryRead(sample.PlayerIndex,out var world,out reason)){Pause("world read: "+reason);guard=new();Thread.Sleep(50);continue;}
                    if(now-lastState>=500)
                    {Log($"WORLD map={world.Map}; team={world.Team}; teamName={world.TeamName}; teamSource={world.TeamSource}; pmIndex={sample.PlayerIndex}; entityIndex={world.LocalEntityIndex}; legacyTeam={world.LegacyTeam}; hp={health.Health}; money={health.Money}; armor={health.Armor}; aimCandidates={enemies.Count}; hasC4={world.HasC4}; canPlant={world.CanPlant}; weapon={world.WeaponId}; plantedHUD={world.BombPlanted}; buyZone={world.InBuyZone}; bomb={world.Bomb}; origin={sample.Origin}; yaw={sample.Angles.Y:F3}; pitch={sample.Angles.X:F3}");lastState=now;}
                    string newContext=world.Map+"/"+world.Team;
                    if(context!=newContext)
                    {
                        Neutral();Log($"CONTEXT map={world.Map}; team={world.Team}; old={context}");context=newContext;goal="";Invalidate();objective.Reset();postPlant.Reset();buy.Cancel(true);enemyAim.Reset();enemies.Clear();damage.Reset();pacer.Reset();guard=new();landing=null;avoid=null;
                        nextAttempt=0;
                    }
                    bool underAttack=damage.Observe(health.Health,health.Armor,now);
                    if(asset?.Name!=world.Map)
                    {
                        Neutral();asset=null;navigator=null;Invalidate();
                        if(loadTask==null && now>=nextAttempt){loadingMap=world.Map;string capturedMap=loadingMap;loadTask=Task.Run(()=>MapCatalog.Load(root,capturedMap));}
                        if(loadTask?.IsCompleted==true)
                        {
                            if(loadTask.IsCompletedSuccessfully && loadTask.Result.Name==world.Map)
                            {asset=loadTask.Result;Log($"MAP LOADED {asset.Name}; nodes={asset.Graph.Nodes.Count}; SHA256={asset.Map.Sha256}");landing=new(asset.Walk.CheckStepLanding,p=>asset.Walk.Supported(p,out _),settings);}
                            else{Notice("WAIT MAP "+(loadTask.Exception?.GetBaseException().Message??"map changed during loading"));nextAttempt=now+settings.RecoveryBackoffMs;}
                            loadTask=null;
                        }
                        if(asset==null){Notice("WAIT matching map assets for "+world.Map);Thread.Sleep(50);continue;}
                    }
                    if(navigator==null)
                    {
                        Neutral();
                        if(navigatorTask==null)
                        {var capturedAsset=asset;navigatorMap=asset.Name;navigatorTask=Task.Run(()=>new FastNavigator(capturedAsset,cancellation.Token));Notice("WARMING checked walk graph once per map; input neutral");}
                        if(navigatorTask.IsCompleted)
                        {
                            if(navigatorTask.IsCompletedSuccessfully && navigatorMap==asset.Name)
                            {navigator=navigatorTask.Result;Log($"NAV CACHE READY edges={navigator.Edges}; coldBuildMs={navigator.BuildMs:F1}");}
                            else if(navigatorTask.IsFaulted)Notice("WAIT NAV CACHE: "+navigatorTask.Exception?.GetBaseException().Message);
                            navigatorTask=null;
                        }
                        if(navigator==null){Thread.Sleep(25);continue;}
                    }
                    landing??=new(asset.Walk.CheckStepLanding,p=>asset.Walk.Supported(p,out _),settings);
                    var landingState=intent?landing.Observe(sample,now):new LandingDecision();
                    string invalid=guard.Observe(sample,health.Health,now,landingState.Waiting,settings.LandingPauseMs);
                    if(invalid!="" || landingState.StopReason!="")
                    {Pause("sample not usable: "+invalid+" "+landingState.StopReason);guard=new();landing=new(asset.Walk.CheckStepLanding,p=>asset.Walk.Supported(p,out _),settings);Thread.Sleep(50);continue;}
                    if(world.Team is not (1 or 2)){Pause($"team not T/CT: entityIndex={world.LocalEntityIndex}; source={world.TeamSource}; name={world.TeamName}; legacy={world.LegacyTeam}");Thread.Sleep(50);continue;}
                    if(!intent && execute && readyToStart)
                    {
                        if(!focus || guard.Advances<3 || sample.Velocity.Length>10 || sample.OnGround<0 || !asset.Walk.Supported(sample.Origin,out _))Notice("AUTO waiting: fresh advancing state, foreground and stationary supported pose required");
                        else
                        {input=new(mem.ProcessId);input.Arm();intent=true;landing.Observe(sample,now);objective.Reset();Log("AUTO ENABLED; no F8; W only; objectives="+settings.AutoObjectives);}
                    }
                    if(!intent){Thread.Sleep(50);continue;}
                    if(landingState.Waiting){Neutral();if(controller!=null || route!=null)Invalidate();Notice("LANDING WAIT input=neutral");Thread.Sleep(settings.LoopMs);continue;}
                    if(landingState.Landed){Pause("landed: rebuild route from grounded position");}
                    if(guard.Advances<3 || now<nextAttempt){Neutral();Thread.Sleep(settings.LoopMs);continue;}
                    postPlant.Observe(world,now,settings);
                    string newGoal=MissionPlanner.GoalKey(world)+(PostPlantCoordinator.Active(world,settings)?"/post:"+postPlant.Revision:"");
                    if(goal!=newGoal){Neutral();goal=newGoal;Invalidate();objective.Reset();Log("GOAL "+goal);}
                    bool inZone=asset.Map.BombZones().Any(z=>asset.Map.InsideZone(sample.Origin,z));
                    var eye=new ProbeVector(sample.Origin.X+sample.ViewOffset.X,sample.Origin.Y+sample.ViewOffset.Y,sample.Origin.Z+sample.ViewOffset.Z);
                    bool line=world.BombPlanted && asset.Map.WorldPointSegmentClear(eye,new(world.Bomb.X,world.Bomb.Y,world.Bomb.Z+4));
                    var action=objective.Tick(world,sample,now,inZone,line);
                    if(action.Error!=""){Pause(action.Error);Thread.Sleep(settings.LoopMs);continue;}
                    // A purchase sequence owns menu input; never let movement, slot5,
                    // enemy aim or a plant command race its numbered menu choices.
                    var purchase=buy.Tick(world,health.Money??-1,now);
                    if(purchase.Busy)
                    {
                        if(controller!=null || route!=null)Invalidate();enemyAim.Reset();objective.Reset();
                        input!.Heartbeat();input.Apply(purchase.Command??new(false,0,false,"",-1,Walk:false));
                        Notice("BUY "+purchase.Mode);Thread.Sleep(settings.LoopMs);continue;
                    }
                    if(purchase.Mode.StartsWith("buy-HUD",StringComparison.Ordinal) || purchase.Mode.StartsWith("buy-not-confirmed",StringComparison.Ordinal))Log("BUY "+purchase.Mode+"; money="+health.Money+"; weapon="+world.WeaponId);
                    if(!action.Navigate)
                    {
                        if(controller!=null || route!=null)Invalidate();enemyAim.Reset();enemies.Clear();input!.Heartbeat();input.Apply(action.Command??new(false,0,false,"",-1));
                        Notice("OBJECTIVE "+action.Mode);Thread.Sleep(settings.LoopMs);continue;
                    }
                    if(settings.EnemyAim=="on")
                    {
                        if(now>=nextEnemyScan)
                        {
                            nextEnemyScan=now+settings.AimScanMs;
                            if(!enemyReader.TryReadPlayers(world,sample,settings,out enemies,out string enemyReason))
                            {enemies.Clear();enemyAim.Reset();if(now-lastEnemyNotice>=1000){Log("AIM sensor unavailable: "+enemyReason+"; navigation continues");lastEnemyNotice=now;}}
                            else enemies=enemies.Select(e=>e with{ObservedAtMs=now}).ToList();
                        }
                        var aim=enemyAim.Tick(world,sample,enemies,now,asset.Walk.Visible,underAttack);
                        if(aim.Error!=""){Pause("enemy aim feedback: "+aim.Error);Thread.Sleep(settings.LoopMs);continue;}
                        if(aim.Active)
                        {
                            objective.Reset();
                            if(controller!=null || route!=null)Invalidate();
                            input!.Heartbeat();input.Apply(aim.Command!);Notice("COMBAT "+aim.Mode);
                            if(now-lastCombatLog>=250){Log($"COMBAT STATE difficulty={difficulty.Name}; target={aim.Target}; point={aim.Part}; error={aim.ErrorDeg:F3}; fireCone={aim.FireConeDeg:F3}; attack={aim.Command!.Attack}; dx={aim.Command.MouseDx}; dy={aim.Command.MouseDy}; damaged={underAttack}");lastCombatLog=now;}
                            Thread.Sleep(settings.LoopMs);continue;
                        }
                    }
                    if(Math.Abs(sample.Angles.X)>20)
                    {
                        var flatten=objective.Flatten(sample,now);
                        if(flatten.Error!="")Pause(flatten.Error);else{input!.Apply(flatten.Command!);Notice("AIM flatten horizon before travel");}
                        Thread.Sleep(settings.LoopMs);continue;
                    }
                    if(controller==null)
                    {
                        Neutral();
                        if(!asset.Walk.Supported(sample.Origin,out _)){stableAt=-1;Thread.Sleep(settings.LoopMs);continue;}
                        if(stableAt<0 || NavGraph.Distance(sample.Origin,stableOrigin)>2){stableAt=now;stableOrigin=sample.Origin;}
                        if(now-stableAt<settings.AutoReplanStableMs){Thread.Sleep(settings.LoopMs);continue;}
                        if(routeTask?.IsCompleted==true && routeEpoch!=epoch)
                        { _=routeTask.Exception;routeTask=null;planCancel?.Dispose();planCancel=null; }
                        if(routeTask==null)
                        {
                            var captured=navigator;var capturedWorld=world;routeOrigin=sample.Origin;routeContext=context+"/"+goal;routeEpoch=epoch;planStarted=now;
                            var capturedOrigin=routeOrigin;double capturedYaw=sample.Angles.Y;var capturedAvoid=now<avoidUntil?avoid:null;var capturedPrevious=postPlant.Previous;
                            planCancel=CancellationTokenSource.CreateLinkedTokenSource(cancellation.Token);var token=planCancel.Token;
                            routeTask=Task.Run(()=>captured.Plan(capturedWorld,capturedOrigin,capturedYaw,settings,capturedAvoid,capturedPrevious,token),token);attempts++;
                            Log($"PLAN BEGIN attempt={attempts}; epoch={routeEpoch}; context={routeContext}; origin={routeOrigin}");
                        }
                        if(!routeTask.IsCompleted){Notice("PLANNING input=neutral");Thread.Sleep(settings.LoopMs);continue;}
                        bool current=PlanAcceptance.Current(routeEpoch,epoch,routeContext,context+"/"+goal,routeOrigin,sample.Origin);
                        route=routeTask.IsCompletedSuccessfully && current?routeTask.Result:null;
                        string planningError=routeTask.Exception?.GetBaseException().Message??(current?"no checked route":"stale plan rejected");routeTask=null;planCancel?.Dispose();planCancel=null;
                        if(route==null || route.Targets.Count==0 || !asset.Walk.Check(sample.Origin,route.Targets[0]).Safe)
                        {Pause("plan unavailable: "+planningError);nextAttempt=now+settings.AutoNoRouteRetryMs;Thread.Sleep(settings.LoopMs);continue;}
                        var runtime=settings.Copy();runtime.MouseMaxCounts=adaptiveCap;
                        controller=new(route.Targets,asset.Walk.Check,seed,TravelOptions.Parse(settings.Motion),asset.Walk.PredictHeading,runtime,adaptiveLookahead:true,noShift:true);
                        File.WriteAllText(jsonPath,JsonSerializer.Serialize(new{controllerVersion="v21-auto",map=world.Map,team=world.Team,difficulty=difficulty.Name,world,settings,adaptiveMouseMaxCounts=adaptiveCap,origin=sample.Origin,route.ComputeMs,route.RawTargets,route.AttachDistance,route.Kind,route.Nodes,route.Targets},new JsonSerializerOptions{WriteIndented=true}));
                        Log($"PLAN READY kind={route.Kind}; targets={route.Targets.Count}; rawTargets={route.RawTargets}; computeMs={route.ComputeMs:F2}; totalPlanMs={Environment.TickCount64-planStarted}; attach={route.AttachDistance:F1}; adaptiveMouseCap={adaptiveCap}");
                    }
                    var command=pacer.Apply(controller.Tick(sample,now,focus) with{Walk=false},now);
                    if(command.StopReason!="")
                    {
                        if(command.StopReason.Contains("changed abruptly",StringComparison.Ordinal))
                        {adaptiveCap=Math.Max(8,Math.Min(64,adaptiveCap/2));Log("RECALIBRATE smaller calibrated pulse cap="+adaptiveCap);}
                        if(route is not null && route.Targets.Count>0)
                        {
                            var failed=route.Targets[Math.Clamp(command.TargetIndex,0,route.Targets.Count-1)];
                            double distance=NavGraph.Distance(sample.Origin,failed),fraction=distance>64?64/distance:1;
                            avoid=new(sample.Origin.X+(float)((failed.X-sample.Origin.X)*fraction),sample.Origin.Y+(float)((failed.Y-sample.Origin.Y)*fraction),sample.Origin.Z+(float)((failed.Z-sample.Origin.Z)*fraction));avoidUntil=now+4000;
                        }
                        Pause(command.StopReason);Thread.Sleep(settings.LoopMs);continue;
                    }
                    input!.Heartbeat();input.Apply(command);
                    if(command.Finished)
                    {
                        if(PostPlantCoordinator.Active(world,settings) && route is not null)
                        {postPlant.Arrived(route.Kind,route.Targets[^1],now,settings);Notice(postPlant.Holding?"POST PLANT COVER: holding static cover, then relocate":"POST PLANT PATROL: select next checked position");}
                        else Notice("AT GOAL; waiting for verified objective state; input released");
                    }
                    else Log($"MOVE origin={sample.Origin}; yaw={sample.Angles.Y:F3}; desired={command.DesiredYaw:F3}; error={command.YawError:F3}; gain={command.MouseGain:F4}; index={command.TargetIndex}; W={command.Forward}; walk={command.Walk}; speed={sample.Velocity.Length:F3}; mouseDx={command.MouseDx}; phase={command.Mode}");
                    Thread.Sleep(settings.LoopMs);
                }
                catch(Exception ex)when(Expected(ex))
                {
                    input?.Dispose();input=null;intent=false;autoStart.Reset();buy.Cancel();enemyAim.Reset();enemies.Clear();Invalidate();guard=new();objective.Reset();landing=null;stableAt=-1;
                    Notice("PAUSE runtime error: "+ex.Message+"; no input; automatic rearm after stable focus/pose");Thread.Sleep(100);
                }
            }
            cancellation.Cancel();
            Log("EXIT user cancellation or game process ended");return 0;
        }
        finally{cancellation.Cancel();planCancel?.Cancel();planCancel?.Dispose();input?.Dispose();mem?.Dispose();Console.CancelKeyPress-=handler;}
    }
}
