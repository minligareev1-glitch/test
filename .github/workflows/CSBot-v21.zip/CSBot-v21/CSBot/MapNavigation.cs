namespace CSBot;

internal sealed record MapRoute(int Anchor, double AnchorDistance, BombZone Zone, NavRoute Route);
internal sealed class MapNavigation
{
    public NavGraph Graph { get; }
    public BspMap Map { get; }
    public HashSet<(int From, int To)> BlockedEdges { get; } = new();
    public int NonEmptyNodes { get; }
    public MapNavigation(NavGraph graph, BspMap map)
    {
        Graph=graph; Map=map;
        NonEmptyNodes=graph.Nodes.Count(n=>map.PointContents(n.Origin)!=-1);
        foreach (var n in graph.Nodes)
            foreach (var edge in n.Links)
                if (map.PointContents(n.Origin)!=-1 || map.PointContents(graph.Nodes[edge.To].Origin)!=-1 ||
                    !map.WorldPointSegmentClear(n.Origin,graph.Nodes[edge.To].Origin))
                    BlockedEdges.Add((n.Id,edge.To));
    }
    public List<int> GoalNodes(BombZone zone) => Graph.Nodes
        .Where(n=>(n.Flags & NavGraph.GoalFlag)!=0 && Map.InsideZone(n.Origin,zone)).Select(n=>n.Id).ToList();

    public MapRoute? Plan(ProbeVector position, string site, string team, WalkGeometry? walk = null)
    {
        if (site is not ("a" or "b") || team is not ("t" or "ct") || !position.IsFinite)
            throw new ArgumentException("Нужны site a|b, team t|ct и конечные XYZ");
        if (Map.PointContents(position)!=-1) throw new ArgumentException("Начальная точка не в CONTENTS_EMPTY мира");
        var zones=Map.BombZones().Where(z=>z.Label==site).ToArray();
        if (zones.Length!=1) throw new InvalidDataException("Нет единственной зоны с меткой " + site);
        return PlanToZone(position,zones[0],team,walk);
    }
    public MapRoute? PlanToZone(ProbeVector position,BombZone zone,string team,WalkGeometry? walk=null)
    {
        // Conservative attachment: max 128 units 3D, max 64 vertical, direct world point visibility.
        // Still not a guarantee of player-sized reachability; no invented graph edges.
        var anchors=Graph.Nodes.Where(n=>Graph.AllowedNode(n.Id,team,false) &&
            Math.Abs(n.Origin.Z-position.Z)<=64 && Map.PointContents(n.Origin)==-1)
            .Select(n=>(Id:n.Id,Distance:NavGraph.Distance(n.Origin,position)))
            .Where(n=>n.Distance<=128).OrderBy(n=>n.Distance).ThenBy(n=>n.Id);
        MapRoute? chosen=null; double chosenCost=double.PositiveInfinity;
        foreach(var anchor in anchors)
        {
            if(!Map.WorldPointSegmentClear(position,Graph.Nodes[anchor.Id].Origin)) continue;
            if(walk!=null && !walk.Check(position,Graph.Nodes[anchor.Id].Origin).Safe) continue;
            NavRoute? best=null;
            foreach(int goal in GoalNodes(zone))
            {
                var route=Graph.FindRoute(anchor.Id,goal,team,false,(from,e)=>!BlockedEdges.Contains((from,e.To)) &&
                    (walk==null || walk.Edge(Graph.Nodes[from],Graph.Nodes[e.To])));
                if(route!=null && (best==null || route.Cost<best.Cost)) best=route;
            }
            if(best!=null && anchor.Distance+best.Cost<chosenCost-0.001)
            { chosen=new(anchor.Id,anchor.Distance,zone,best); chosenCost=anchor.Distance+best.Cost; }
        }
        return chosen;
    }
    public (NavRoute Route,List<ProbeVector> Targets)? PlanToPoint(ProbeVector position,ProbeVector goal,string team,WalkGeometry walk)
    {
        var anchors=Graph.Nodes.Where(n=>Graph.AllowedNode(n.Id,team,false) && NavGraph.Distance(position,n.Origin)<=128 && walk.Check(position,n.Origin).Safe)
            .OrderBy(n=>NavGraph.Distance(position,n.Origin)).Take(12).ToArray();
        var ends=Graph.Nodes.Where(n=>Graph.AllowedNode(n.Id,team,false) && NavGraph.Distance(goal,n.Origin)<=128 && walk.Check(n.Origin,goal).Safe)
            .OrderBy(n=>NavGraph.Distance(goal,n.Origin)).Take(12).ToArray();
        NavRoute? best=null;double cost=double.PositiveInfinity;
        foreach(var a in anchors)foreach(var b in ends)
        {
            var candidate=Graph.FindRoute(a.Id,b.Id,team,false,(from,e)=>!BlockedEdges.Contains((from,e.To)) && walk.Edge(Graph.Nodes[from],Graph.Nodes[e.To]));
            if(candidate==null)continue;
            double total=NavGraph.Distance(position,a.Origin)+candidate.Cost+NavGraph.Distance(goal,b.Origin);
            if(total<cost){cost=total;best=candidate;}
        }
        if(best==null)return null;
        var targets=best.Nodes.Select(id=>Graph.Nodes[id].Origin).ToList();targets.Add(goal);
        return(new(best.Nodes,cost),targets);
    }

}
