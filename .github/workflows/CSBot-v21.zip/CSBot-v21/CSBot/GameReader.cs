namespace CSBot;

// Reading plausible fields does not establish connection/spawn/alive state.
internal enum GameStatus { Unknown }
internal readonly record struct PlayerState(int Health, int? Armor, int? Money, GameStatus Status);

internal sealed class GameReader
{
    private readonly IGameMemory _mem;
    private readonly Action<string> _log;
    private readonly MovementProbe _movement;
    private uint _clientBase;
    private long _lastRefresh;
    private bool _ready;
    public bool ProbeRawXyz { get; set; }
    public bool ProbeView { get; set; }
    public bool ProbeMovement { get; set; }
    public string Source { get; private set; } = "";
    public string LastFailure { get; private set; } = "";

    public GameReader(IGameMemory mem, Action<string> log) { _mem = mem; _log = log; _movement = new MovementProbe(mem); }

    public void Reset()
    {
        _ready = false;
        _clientBase = 0;
        Source = LastFailure = "";
    }

    public bool DiscoverLocalPlayer()
    {
        Reset();
        _mem.RefreshModules();
        _lastRefresh = Environment.TickCount64;
        if (!_mem.Modules.TryGetValue("client.dll", out _clientBase))
        { LastFailure = "client.dll ещё не загружен; ждём загрузку клиента"; return false; }

        foreach (uint rva in new[] { GameOffsets.ClientHealthDirectRva,
                     GameOffsets.ClientMoneyDirectRva, GameOffsets.ClientArmorDirectRva })
            if (!TryModuleAddress("client.dll", rva, 4, out _))
            { LastFailure = $"RVA 0x{rva:X} вне client.dll: профиль может не подходить этой сборке"; return false; }

        if (!ReadField(GameOffsets.ClientHealthDirectRva, 100, "HP", out int hp)) return false;
        _ready = true;
        Source = $"direct-client (КАНДИДАТ): HP client.dll+0x{GameOffsets.ClientHealthDirectRva:X}; " +
            $"Money +0x{GameOffsets.ClientMoneyDirectRva:X}; Armor +0x{GameOffsets.ClientArmorDirectRva:X}";
        return true;
    }

    public bool TryReadState(out PlayerState state)
    {
        state = default;
        if (!_ready) { LastFailure = "Профиль ещё не подключён"; return false; }
        if (Environment.TickCount64 - _lastRefresh >= 2000)
        {
            _mem.RefreshModules();
            _lastRefresh = Environment.TickCount64;
        }
        if (!_mem.Modules.TryGetValue("client.dll", out uint current) || current != _clientBase)
        { LastFailure = "client.dll выгружен или перемещён; требуется повторное подключение"; return false; }
        if (!ReadField(GameOffsets.ClientHealthDirectRva, 100, "HP", out int hp)) return false;

        // Zero is legal. No candidate list and no preference for positive unrelated fields.
        int? money = ReadField(GameOffsets.ClientMoneyDirectRva, 16000, "Money", out int m) ? m : null;
        int? armor = ReadField(GameOffsets.ClientArmorDirectRva, 100, "Armor", out int a) ? a : null;
        state = new PlayerState(hp, armor, money, GameStatus.Unknown);
        if (ProbeRawXyz) DumpRawXyz();
        if (ProbeView) DumpViewCandidates();
        if (ProbeMovement) DumpMovement();
        return true;
    }

    private bool ReadField(uint rva, int max, string label, out int value)
    {
        value = 0;
        if (!TryModuleAddress("client.dll", rva, 4, out uint address))
        { LastFailure = $"{label}: адрес за пределами client.dll"; return false; }
        if (!_mem.ReadInt32(address, out value))
        {
            LastFailure = $"{label} @0x{address:X8}: ? Win32={_mem.LastReadError}, bytes={_mem.LastBytesRead}";
            return false;
        }
        if (value < 0 || value > max)
        { LastFailure = $"{label} @0x{address:X8}: значение {value} вне диапазона 0..{max}"; return false; }
        return true;
    }

    private bool TryModuleAddress(string module, uint rva, uint bytes, out uint address)
    {
        address = 0;
        if (!_mem.Modules.TryGetValue(module, out uint moduleBase) ||
            !_mem.ModuleSizes.TryGetValue(module, out uint size) ||
            (ulong)rva + bytes > size || (ulong)moduleBase + rva + bytes > (ulong)uint.MaxValue + 1)
            return false;
        address = moduleBase + rva;
        return true;
    }

    public void DebugDump()
    {
        _log("--- direct-client: независимые поля, профиль пока не подтверждён HUD ---");
        DumpInt(GameOffsets.ClientHealthDirectRva, "HP direct");
        DumpInt(GameOffsets.ClientMoneyDirectRva, "Money direct");
        DumpInt(GameOffsets.ClientArmorDirectRva, "Armor direct");
        if (TryModuleAddress("client.dll", GameOffsets.ClientCandidatePointerRva, 4, out uint address))
        {
            if (_mem.ReadUInt32(address, out uint pointer))
            {
                _log($"[client.dll+0x{GameOffsets.ClientCandidatePointerRva:X}]=0x{pointer:X8} (только диагностика)");
                if (_mem.Modules.TryGetValue("client.dll", out uint baseAddress))
                {
                    DumpRelationship(pointer, GameOffsets.CandidateHealthOffset, baseAddress, GameOffsets.ClientHealthDirectRva, "HP");
                    DumpRelationship(pointer, GameOffsets.CandidateMoneyOffset, baseAddress, GameOffsets.ClientMoneyDirectRva, "Money");
                    DumpRelationship(pointer, GameOffsets.CandidateArmorOffset, baseAddress, GameOffsets.ClientArmorDirectRva, "Armor");
                }
            }
            else _log($"Указатель-кандидат: ? Win32={_mem.LastReadError}, bytes={_mem.LastBytesRead}");
        }
        DumpRawXyz();
        if (ProbeView) DumpViewCandidates();
        if (ProbeMovement) DumpMovement();
        _log("--- Конец диагностики; состояние подключения/спавна неизвестно ---");
    }

    private void DumpInt(uint rva, string label)
    {
        if (!TryModuleAddress("client.dll", rva, 4, out uint address))
        { _log($"{label}: ? client.dll не загружен или RVA вне модуля"); return; }
        bool ok = _mem.ReadInt32(address, out int value);
        string text = ok ? value.ToString() : $"? Win32={_mem.LastReadError}, bytes={_mem.LastBytesRead}";
        _log($"{label} client.dll+0x{rva:X} @0x{address:X8} = {text}");
    }

    private void DumpRelationship(uint pointer, uint offset, uint moduleBase, uint rva, string label)
    {
        ulong indirect = (ulong)pointer + offset;
        ulong direct = (ulong)moduleBase + rva;
        _log($"{label}: ptr+0x{offset:X}=0x{indirect:X8}; direct=0x{direct:X8}; same-address={indirect == direct}");
        // Equality of addresses is arithmetic, not proof of semantic identity or a real player object.
    }

    private void DumpMovement()
    {
        if (!_movement.TryRead(out var sample, out string reason))
        {
            _log("PMOVE: ? " + reason);
            return;
        }
        _log(FormattableString.Invariant($"PMOVE CodeMatch=True ptr=0x{sample.Pointer:X8} PlayerIndex={sample.PlayerIndex} Server={sample.Server} Time={sample.Time:F3} FrameTime={sample.FrameTime:F4} OriginCandidate={sample.Origin} Angles={sample.Angles} Velocity={sample.Velocity} ViewOfs={sample.ViewOffset} OnGround={sample.OnGround} Dead={sample.Dead} DeadFlag={sample.DeadFlag} Spectator={sample.Spectator} Flags=0x{sample.Flags:X} [ДВИЖЕНИЕ: ТРЕБУЕТ ПРОВЕРКИ В ИГРЕ]"));
    }

    private void DumpViewCandidates()
    {
        foreach (var candidate in ViewProbe.Candidates)
        {
            if (!TryModuleAddress("client.dll", candidate.Rva, ViewProbe.Size, out uint address))
            {
                _log($"VIEW[{candidate.Label}] client.dll+0x{candidate.Rva:X}: ? outside-module / module-unavailable");
                continue;
            }
            var buffer = new byte[ViewProbe.Size];
            if (!_mem.ReadBytes(address, buffer))
            {
                _log($"VIEW[{candidate.Label}] @0x{address:X8}: ? Win32={_mem.LastReadError}, bytes={_mem.LastBytesRead}");
                continue;
            }
            var frame = ViewProbe.Decode(buffer);
            var check = ViewProbe.CheckBasis(frame);
            _log(FormattableString.Invariant(
                $"VIEW[{candidate.Label}] client.dll+0x{candidate.Rva:X}: OriginCandidate={frame.Origin}; Up={frame.Up}; Right={frame.Right}; Forward={frame.Forward}; BasisPlausible={check.Plausible}; Norms=({check.UpLength:F3},{check.RightLength:F3},{check.ForwardLength:F3}); MaxAbsDot={check.MaxAbsDot:F3} [НЕ ПОДТВЕРЖДЕНО КАК КАМЕРА ИЛИ ПОЗИЦИЯ]"));
        }
    }

    private void DumpRawXyz()
    {
        if (!TryModuleAddress("hw.dll", GameOffsets.HwRawXyzRva, 12, out uint address))
        { _log("RAW_XYZ: ? hw.dll недоступен или RVA вне модуля"); return; }
        if (!_mem.ReadVec3(address, out float x, out float y, out float z))
        { _log($"RAW_XYZ @0x{address:X8}: ? Win32={_mem.LastReadError}, bytes={_mem.LastBytesRead}"); return; }
        _log(FormattableString.Invariant($"RAW_XYZ hw.dll+0x{GameOffsets.HwRawXyzRva:X}: ({x:F3}, {y:F3}, {z:F3}) [НЕ ПОДТВЕРЖДЕНО КАК ПОЗИЦИЯ]"));
    }
}
