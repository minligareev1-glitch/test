using System.Security.Cryptography;
using System.Text.Json;
namespace CSBot;
internal sealed record MapAsset(string BspSha256,string GraphSha256);
internal sealed record LoadedMap(string Name,BspMap Map,NavGraph Graph,WalkGeometry Walk,MapNavigation Navigation);
internal sealed record MapRegistration(int Found,int Registered,int Unchanged,int Skipped,int Errors);
internal static class MapCatalog
{
    private static readonly object Gate=new();
    private static bool Expected(Exception ex)=>ex is InvalidDataException or IOException or UnauthorizedAccessException or ArgumentException or InvalidOperationException or JsonException or FormatException or OverflowException or NotSupportedException;
    private static string Hash(string path)=>Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
    private static string Registry(string root)=>Path.Combine(root,"Maps","maps.json");
    private static Dictionary<string,MapAsset> ReadRegistry(string root)
    {
        if(!File.Exists(Registry(root)))return new(StringComparer.OrdinalIgnoreCase);
        var parsed=JsonSerializer.Deserialize<Dictionary<string,MapAsset>>(File.ReadAllText(Registry(root)))??throw new InvalidDataException("Empty/null map registry; existing file was not overwritten");
        var result=new Dictionary<string,MapAsset>(StringComparer.OrdinalIgnoreCase);
        foreach(var pair in parsed)
        {
            string name=WorldStateReader.NormalizeMap(pair.Key);
            if(name!=pair.Key || pair.Value==null || !ValidHash(pair.Value.BspSha256) || !ValidHash(pair.Value.GraphSha256) || !result.TryAdd(name,pair.Value))throw new InvalidDataException("Invalid map registry entry; existing file was not overwritten: "+pair.Key);
        }
        return result;
    }
    private static bool ValidHash(string? hash)=>hash is{Length:64} && hash.All(Uri.IsHexDigit);
    private static void SaveRegistry(string root,Dictionary<string,MapAsset> entries)
    {
        string path=Registry(root),temp=path+"."+Guid.NewGuid().ToString("N")+".tmp";
        try
        {
            File.WriteAllText(temp,JsonSerializer.Serialize(entries.OrderBy(x=>x.Key,StringComparer.Ordinal).ToDictionary(x=>x.Key,x=>x.Value),new JsonSerializerOptions{WriteIndented=true}));
            File.Move(temp,path,true);
        }
        finally{if(File.Exists(temp))File.Delete(temp);}
    }
    private static string Resolve(string folder,string name,string extension)
    {
        if(!Directory.Exists(folder))throw new FileNotFoundException("Asset folder missing: "+folder);
        var files=Directory.EnumerateFiles(folder).Where(p=>Path.GetExtension(p).Equals(extension,StringComparison.OrdinalIgnoreCase) && Path.GetFileNameWithoutExtension(p).Equals(name,StringComparison.OrdinalIgnoreCase)).ToArray();
        if(files.Length==0)throw new FileNotFoundException("Matching asset missing: "+Path.Combine(folder,name+extension));
        if(files.Length!=1)throw new InvalidDataException("Ambiguous case-insensitive assets for "+name+extension);
        return files[0];
    }
    private static (string Bsp,string Graph) Paths(string root,string name)=>(Resolve(Path.Combine(root,"Maps"),name,".bsp"),Resolve(Path.Combine(root,"Navigation"),name,".graph"));
    private static MapAsset Fingerprint((string Bsp,string Graph) paths)=>new(Hash(paths.Bsp),Hash(paths.Graph));
    private static (LoadedMap Loaded,MapAsset Asset) Validate(string root,string name)
    {
        var paths=Paths(root,name);var before=Fingerprint(paths);
        var map=BspMap.Load(paths.Bsp);var graph=NavGraph.Load(paths.Graph);var walk=new WalkGeometry(map);var nav=new MapNavigation(graph,map);
        if(nav.NonEmptyNodes!=0 || map.BombZones().Count==0)throw new InvalidDataException("Graph node centers / brush bomb zones incompatible with BSP");
        if(before!=Fingerprint(paths))throw new IOException("Map assets changed during validation; retry with stable files");
        return(new(name,map,graph,walk,nav),before);
    }
    public static LoadedMap Load(string root,string name)
    {
        name=WorldStateReader.NormalizeMap(name);
        Dictionary<string,MapAsset> entries;lock(Gate)entries=ReadRegistry(root);
        if(!entries.TryGetValue(name,out var entry))throw new InvalidDataException($"Map {name} is not registered. Add Maps/{name}.bsp + Navigation/{name}.graph and restart AUTO or run --register-maps; no fallback map.");
        var paths=Paths(root,name);
        if(Fingerprint(paths)!=entry)throw new InvalidDataException("Map assets changed since registration. Restart AUTO or run --register-maps: "+name);
        var validated=Validate(root,name);
        if(validated.Asset!=entry)throw new InvalidDataException("Map assets changed during load: "+name);
        return validated.Loaded;
    }
    // Source of truth for discovery is Maps/*.bsp, not Navigation/*.graph.
    // Missing/bad pairs do not prevent other maps from registering or weaken loading checks.
    public static MapRegistration RegisterMaps(string root,Action<string>? log=null)
    {
        log??=_=>{};
        lock(Gate)
        {
            int found=0,registered=0,unchanged=0,skipped=0,errors=0;
            try
            {
                string folder=Path.Combine(root,"Maps");
                if(!Directory.Exists(folder)){log("MAP REGISTER no Maps folder; no registration performed");return new(0,0,0,0,0);}
                var files=Directory.EnumerateFiles(folder).Where(p=>Path.GetExtension(p).Equals(".bsp",StringComparison.OrdinalIgnoreCase)).OrderBy(p=>p,StringComparer.Ordinal).ToArray();found=files.Length;
                var entries=ReadRegistry(root);bool changed=false;
                foreach(string file in files)
                {
                    string label=Path.GetFileName(file);
                    try
                    {
                        string name=WorldStateReader.NormalizeMap(Path.GetFileNameWithoutExtension(file));
                        var paths=Paths(root,name);var fingerprint=Fingerprint(paths);
                        if(entries.TryGetValue(name,out var prior) && prior==fingerprint){unchanged++;log("MAP REGISTER unchanged "+name);continue;}
                        var validated=Validate(root,name);entries[name]=validated.Asset;changed=true;registered++;
                        log($"MAP REGISTER validated {name}; nodes={validated.Loaded.Graph.Nodes.Count}; bombZones={validated.Loaded.Map.BombZones().Count}");
                    }
                    catch(Exception ex)when(Expected(ex))
                    {skipped++;if(ex is not FileNotFoundException)errors++;log("MAP REGISTER skip "+JsonSerializer.Serialize(label)+": "+ex.Message);}
                }
                if(changed)SaveRegistry(root,entries);
                log($"MAP REGISTER SUMMARY source=Maps; found={found}; registered={registered}; unchanged={unchanged}; skipped={skipped}; errors={errors}");
                return new(found,registered,unchanged,skipped,errors);
            }
            catch(Exception ex)when(Expected(ex))
            {log("MAP REGISTER registry/scan error: "+ex.Message+"; existing registry is not intentionally replaced on failure");return new(found,0,unchanged,skipped,errors+1);}
        }
    }
    public static bool TryRun(string[] args,out int exit)
    {
        exit=0;if(args.Length==0 || args[0] is not ("--register-map" or "--register-maps"))return false;
        try
        {
            if(args[0]=="--register-maps")
            {
                if(args.Length>2)throw new ArgumentException("--register-maps [ASSET_ROOT]");
                var report=RegisterMaps(Path.GetFullPath(args.Length==2?args[1]:"."),Console.WriteLine);exit=report.Errors>0?2:0;return true;
            }
            if(args.Length is <2 or >3)throw new ArgumentException("--register-map NAME [ASSET_ROOT]");
            string name=WorldStateReader.NormalizeMap(args[1]),root=Path.GetFullPath(args.Length==3?args[2]:".");
            var validated=Validate(root,name);
            lock(Gate){var entries=ReadRegistry(root);entries[name]=validated.Asset;SaveRegistry(root,entries);}
            Console.WriteLine("Registered file pair "+name+". Static compatibility only, not live traversability or graph authorship.");
        }
        catch(Exception ex)when(Expected(ex)){Console.Error.WriteLine(ex.Message);exit=2;}
        return true;
    }
}
