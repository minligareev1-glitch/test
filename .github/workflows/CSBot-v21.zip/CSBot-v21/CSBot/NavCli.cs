using System.Text.Json;

namespace CSBot;

internal static class NavCli
{
    public static bool TryRun(string[] args, out int exit)
    {
        exit = 0;
        if (args.Length == 0 || args[0] is not ("--nav-info" or "--nav-route")) return false;
        try
        {
            if (args.Length < 2) throw new ArgumentException("Укажи путь к .graph");
            var graph = NavGraph.Load(args[1]);
            Console.WriteLine($"YaPB graph v2: {graph.Nodes.Count} nodes; author={graph.Author}; BSP size hint={graph.BspSizeHint}");
            Console.WriteLine("DRY RUN: no keyboard/mouse input. Matching the actual BSP and reachability is NOT verified.");
            if (args[0] == "--nav-info")
            {
                if (args.Length != 2) throw new ArgumentException("Usage: --nav-info FILE.graph");
                foreach (var node in graph.Nodes.Where(n => (n.Flags & NavGraph.GoalFlag) != 0))
                    Console.WriteLine($"GoalCandidate ID={node.Id} Origin={node.Origin} Flags=0x{node.Flags:X}");
                Console.WriteLine("Goal flags are NOT verified A/B labels. Choose node IDs explicitly.");
                return true;
            }
            if (args.Length < 4 || !int.TryParse(args[2], out int start) || !int.TryParse(args[3], out int goal))
                throw new ArgumentException("Usage: --nav-route FILE.graph FROM_ID TO_ID [--team t|ct|any] [--allow-special] [--json FILE]");
            string team = "any"; bool special = false; string? json = null;
            for (int i = 4; i < args.Length; i++)
            {
                switch (args[i])
                {
                    case "--allow-special": special = true; break;
                    case "--team": if (++i >= args.Length) throw new ArgumentException("Missing team"); team = args[i]; break;
                    case "--json": if (++i >= args.Length) throw new ArgumentException("Missing JSON path"); json = args[i]; break;
                    default: throw new ArgumentException("Unknown option: " + args[i]);
                }
            }
            var route = graph.FindRoute(start, goal, team, special);
            if (route == null)
            {
                Console.WriteLine("NO ROUTE under selected restrictions. No links are invented or reversed.");
                exit = 3; return true;
            }
            Console.WriteLine($"A* graph route: from={start}; to={goal}; nodes={route.Nodes.Count}; cost={route.Cost:F2}; team={team}; allowSpecial={special}");
            Console.WriteLine(string.Join(" -> ", route.Nodes));
            if (json != null)
            {
                var artifact = new
                {
                    format = "CSBot.graph-route.v1", graphFile = Path.GetFileName(args[1]),
                    graphSha256 = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(args[1]))).ToLowerInvariant(),
                    graphAuthor = graph.Author, dataLicense = "CC-BY-SA-4.0", mapGeometryVerified = false,
                    dryRunOnly = true, team, allowSpecial = special, route.Cost,
                    nodes = route.Nodes.Select(id => new
                    {
                        id, x = graph.Nodes[id].Origin.X, y = graph.Nodes[id].Origin.Y, z = graph.Nodes[id].Origin.Z,
                        flags = graph.Nodes[id].Flags, radius = graph.Nodes[id].Radius
                    })
                };
                File.WriteAllText(json, JsonSerializer.Serialize(artifact, new JsonSerializerOptions { WriteIndented = true }));
                Console.WriteLine("Saved: " + json);
            }
        }
        catch (Exception ex) when (ex is IOException or InvalidDataException or UnauthorizedAccessException or ArgumentException or OverflowException)
        {
            Console.Error.WriteLine("Navigation error: " + ex.Message); exit = 2;
        }
        return true;
    }
}
