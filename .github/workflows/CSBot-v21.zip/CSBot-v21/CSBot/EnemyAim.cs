namespace CSBot;
internal sealed record EnemyAimStep(bool Active,TravelCommand? Command=null,string Mode="",string Error="")
{
    public int Target {get;init;}=-1;public string Part {get;init;}="";
    public double ErrorDeg {get;init;}public double FireConeDeg {get;init;}
}
// Combat owns input only while a checked visible enemy is selected. Objective/menu
// actions have priority in the supervisor. No remote calls, magic visibility or hit claims.
internal sealed class EnemyAim(double seed,BotSettings settings,int pitchSign,bool canSelectWeapons=false)
{
    private readonly DifficultyProfile _profile=DifficultyProfile.Resolve(settings);
    private readonly FireControl _fire=new();
    private int _target=-1,_selectStep;private PulseSteering? _yaw,_pitch;
    private long _acquired=-1,_aligned=-1,_lastNow=-1,_advancedAt=-1,_selectAt=-1;
    private float? _sampleTime;
    public void Reset()
    {_target=-1;_yaw=_pitch=null;_fire.Reset();_acquired=_aligned=_lastNow=_advancedAt=_selectAt=-1;_sampleTime=null;_selectStep=0;}
    public EnemyAimStep Tick(WorldState world,MoveSample sample,IReadOnlyList<EnemyState> players,long now,Func<ProbeVector,ProbeVector,bool> visible,bool underAttack=false)
    {
        if(settings.EnemyAim!="on" || world.Team is not (1 or 2) || sample.Dead!=0 || sample.DeadFlag!=0 || sample.Spectator!=0 || !sample.Origin.IsFinite || !sample.Angles.IsFinite || !float.IsFinite(sample.Time))
        {Reset();return new(false);}
        if(_lastNow>=0 && (now<_lastNow || _sampleTime.HasValue && sample.Time<_sampleTime.Value))
        {Reset();return new(false,Error:"combat sample/wall time moved backwards");}
        _lastNow=now;if(!_sampleTime.HasValue || sample.Time>_sampleTime.Value)_advancedAt=now;_sampleTime=sample.Time;
        var eye=new ProbeVector(sample.Origin.X+sample.ViewOffset.X,sample.Origin.Y+sample.ViewOffset.Y,sample.Origin.Z+sample.ViewOffset.Z);
        (ProbeVector Point,string Part)? Point(EnemyState e)
        {
            if(_profile.AimPart=="head")return e.HeadPoint is { } h && h.IsFinite && visible(eye,h)?(h,"head"):null;
            bool body=e.AimPoint.IsFinite && visible(eye,e.AimPoint);
            if(_profile.AimPart=="auto" && e.HeadPoint is { } head && head.IsFinite && (NavGraph.Distance(eye,head)<=1400 || !body) && visible(eye,head))return(head,"head");
            return body?(e.AimPoint,"body"):null;
        }
        (double Yaw,double Pitch,double Error,double Distance) Angles(ProbeVector p)
        {
            double x=p.X-eye.X,y=p.Y-eye.Y,z=p.Z-eye.Z;
            double yaw=Math.Atan2(y,x)*180/Math.PI,pitch=-Math.Atan2(z,Math.Sqrt(x*x+y*y))*180/Math.PI;
            double dy=PulseSteering.Normalize(yaw-sample.Angles.Y),dp=pitch-sample.Angles.X;
            return(yaw,pitch,Math.Sqrt(dy*dy+dp*dp),NavGraph.Distance(eye,p));
        }
        double Threat(EnemyState e,double distance,double angle)
        {
            double toward=Math.Atan2(eye.Y-e.Origin.Y,eye.X-e.Origin.X)*180/Math.PI;
            bool facing=double.IsFinite(e.FacingYaw) && Math.Abs(PulseSteering.Normalize(toward-e.FacingYaw))<30;
            double score=_profile.Name=="god"?angle*.08+distance*.03:angle+distance*.008;
            if(e.MuzzleFlash)score-=100;
            if(underAttack && facing)score-=70;
            if(_profile.Name=="god" && distance<512)score-=80;
            if(e.Index==_target)score-=15;return score;
        }
        var candidates=players.Where(e=>e.Index!=world.LocalEntityIndex && e.Team!=world.Team && e.Team is 1 or 2 && e.Origin.IsFinite)
            .Select(e=>(Entity:e,Chosen:Point(e))).Where(x=>x.Chosen.HasValue)
            .Select(x=>(x.Entity,Point:x.Chosen!.Value.Point,Part:x.Chosen.Value.Part,Angle:Angles(x.Chosen.Value.Point)))
            .Where(x=>x.Angle.Distance<=settings.AimMaxDistance && Math.Abs(x.Angle.Pitch)<=80 &&
                (settings.AimFovDeg>=360 || Math.Abs(PulseSteering.Normalize(x.Angle.Yaw-sample.Angles.Y))<=settings.AimFovDeg/2 || settings.RearTurn=="on" && x.Angle.Distance<=_profile.Rear(settings)))
            .OrderBy(x=>Threat(x.Entity,x.Angle.Distance,x.Angle.Error)).ThenBy(x=>x.Entity.Index).ToArray();
        if(candidates.Length==0){Reset();return new(false);}
        var chosen=candidates[0];
        if(chosen.Entity.Index!=_target)
        {
            _fire.Stop(now,_profile.Pause(settings));_target=chosen.Entity.Index;_acquired=now;_aligned=-1;
            if(_yaw==null || _pitch==null)
            {var cfg=settings.Copy();_profile.TuneSteering(cfg);_yaw=new(seed,true,cfg);_pitch=new(seed,true,cfg);}
            else{_yaw.BeginSegment();_pitch.BeginSegment();} // preserves measured/in-flight input feedback
        }
        double yawError=PulseSteering.Normalize(chosen.Angle.Yaw-sample.Angles.Y),pitchError=chosen.Angle.Pitch-sample.Angles.X;
        double radius=chosen.Part=="head"?settings.HeadAimRadius:settings.BodyAimRadius;
        double cone=Math.Min(_profile.FireAngle(settings),Math.Atan2(radius,Math.Max(1,chosen.Angle.Distance))*180/Math.PI);
        bool aligned=chosen.Angle.Error<=cone;
        if(aligned){if(_aligned<0)_aligned=now;}else _aligned=-1;
        EnemyAimStep Result(string phase,int dx=0,int dy=0,bool attack=false,byte tap=0)=>new(true,
            new(false,dx,false,"",-1,Mode:phase,Walk:false,MouseDy:dy,Attack:attack,TapScan:tap),phase)
            {Target=_target,Part=chosen.Part,ErrorDeg=chosen.Angle.Error,FireConeDeg=cone};
        int reaction=_profile.Reaction(settings);
        if(underAttack && _profile.Name=="hard" && settings.CombatReactionMs<0)reaction=Math.Min(reaction,35);
        if(now-_acquired<reaction)return Result($"combat-react:{_target}/{chosen.Part}");
        if(canSelectWeapons && !FireControl.Firearm(world.WeaponId))
        {
            _fire.Stop(now,_profile.Pause(settings));
            if(_selectStep<2 && (_selectAt<0 || now-_selectAt>=650))
            {byte scan=_selectStep++==0?(byte)0x02:(byte)0x03;_selectAt=now;return Result("combat-select-firearm",tap:scan);}
        }
        else if(FireControl.Firearm(world.WeaponId)){_selectStep=0;_selectAt=-1;}
        bool fresh=chosen.Entity.ObservedAtMs>=0 && now>=chosen.Entity.ObservedAtMs && now-chosen.Entity.ObservedAtMs<=_profile.Fresh(settings) && now-_advancedAt<=100;
        bool eligible=settings.AutoFire=="on" && FireControl.Firearm(world.WeaponId) && fresh && aligned &&
            FireControl.CorridorClear(eye,chosen.Point,players,world.LocalEntityIndex,_target);
        // Fire is only started with no in-flight mouse packet. Before correcting
        // recoil/target movement after a burst, release attack and wait the rest.
        if(!_fire.Prepare(now,eligible,_profile.Pause(settings)))return Result($"combat-fire-rest:{_target}/{chosen.Part}");
        double tolerance=Math.Min(settings.YawToleranceDeg,cone*.45);
        var yawStep=_yaw!.Tick(sample.Angles.Y,yawError,now,Math.Abs(yawError)>tolerance);
        var pitchStep=_pitch!.Tick(-sample.Angles.X,-pitchError,now,Math.Abs(pitchError)>tolerance);
        string error=yawStep.StopReason!=""?yawStep.StopReason:pitchStep.StopReason;
        if(error!=""){Reset();return new(false,Error:error);}
        bool ready=eligible && _aligned>=0 && now-_aligned>=_profile.Stable(settings) && !yawStep.Waiting && !pitchStep.Waiting && yawStep.MouseDx==0 && pitchStep.MouseDx==0;
        bool fire=_fire.Tick(now,ready,_profile.Burst(settings,world.WeaponId),_profile.Pause(settings));
        string mode=(fire?"combat-fire:":"combat-aim:")+_target+"/"+chosen.Part;
        return Result(mode,yawStep.MouseDx,pitchStep.MouseDx*pitchSign,fire);
    }
}
