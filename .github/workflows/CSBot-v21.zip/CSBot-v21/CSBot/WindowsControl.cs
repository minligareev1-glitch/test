using System.ComponentModel;
using System.Runtime.InteropServices;

namespace CSBot;

internal interface IControlBackend
{
    bool Focused { get; }
    bool StopPressed { get; }
    bool UserBusy { get; }
    long Now { get; }
    void Keys(bool down,bool walk=true);
    void ReleaseTaps(){}
    void Tap(byte scan){throw new NotSupportedException("Key pulse backend unavailable");}
    void Mouse(int dx);
    void MouseAxes(int dx,int dy){if(dy!=0)throw new NotSupportedException("Pitch input backend unavailable");if(dx!=0)Mouse(dx);}
    void ObjectiveKeys(bool attack,bool use,bool selectC4){if(attack || use || selectC4)throw new NotSupportedException("Objective input backend unavailable");}
}

internal sealed class WindowsControl : IDisposable
{
    [StructLayout(LayoutKind.Sequential)] private struct Mouse { public int X,Y; public uint Data,Flags,Time; public nuint Extra; }
    [StructLayout(LayoutKind.Sequential)] private struct Keyboard { public ushort Key,Scan; public uint Flags,Time; public nuint Extra; }
    [StructLayout(LayoutKind.Explicit)] private struct InputUnion
    { [FieldOffset(0)] public Mouse Mouse; [FieldOffset(0)] public Keyboard Keyboard; }
    [StructLayout(LayoutKind.Sequential)] private struct Input { public uint Type; public InputUnion Data; }
    [DllImport("user32.dll",SetLastError=true)] private static extern uint SendInput(uint count,Input[] inputs,int size);
    [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr window,out uint pid);
    [DllImport("user32.dll")] private static extern short GetAsyncKeyState(int key);
    [DllImport("user32.dll")] [return:MarshalAs(UnmanagedType.Bool)] private static extern bool IsIconic(IntPtr window);
    public static bool KeyDown(int key)=>(GetAsyncKeyState(key)&0x8000)!=0;
    public static bool Focused(int pid)
    { var w=GetForegroundWindow(); if(w==IntPtr.Zero || IsIconic(w)) return false; GetWindowThreadProcessId(w,out uint owner); return owner==pid; }
    public static bool ManualBusy()=>new[]{0x57,0x41,0x53,0x44,0x10,0x11,0x20,0x01,0x02}.Any(KeyDown);
    public static bool StopHeld()=>KeyDown(0x78)||KeyDown(0x1B)||KeyDown(0xC0);
    internal static int InputSize=>Marshal.SizeOf<Input>();
    private readonly object _gate=new();
    private readonly IControlBackend _backend;
    private readonly Timer? _watchdog;
    private bool _objectiveDirty,_attackHeld,_useHeld;
    private bool _held, _walkHeld=true, _disposed, _armed;
    private long _heartbeat;
    private string _fault="";
    public string Fault { get { lock(_gate) return _fault; } }
    private sealed class NativeBackend(int pid) : IControlBackend
    {
        public bool Focused=>WindowsControl.Focused(pid);
        public bool StopPressed=>KeyDown(0x78)||KeyDown(0x1B)||KeyDown(0xC0);
        public bool UserBusy=>ManualBusy();
        public long Now=>Environment.TickCount64;
        private bool _attack,_use,_select;private byte _pendingScan;
        public void Keys(bool down,bool walk=true)
        {
            // v19: W only. Never synthesize Shift down OR up, regardless of legacy Walk hints.
            Send(Scan(0x11,!down));
        }
        public void Tap(byte scan)
        {
            if(!AllowedTap(scan))throw new ArgumentException("Unsupported bot key pulse");
            try{_pendingScan=scan;Send(Scan(scan,false));}finally{ReleaseTaps();}
        }
        public void ReleaseTaps(){if(_pendingScan!=0){Send(Scan(_pendingScan,true));_pendingScan=0;}}
        public void Mouse(int dx)=>Send(new Input { Type=0,Data=new InputUnion { Mouse=new Mouse { X=dx,Flags=1 } } });
        public void MouseAxes(int dx,int dy)=>Send(new Input {Type=0,Data=new InputUnion{Mouse=new Mouse{X=dx,Y=dy,Flags=1}}});
        public void ObjectiveKeys(bool attack,bool use,bool selectC4)
        {
            var events=new List<Input>();
            if(attack!=_attack){_attack=attack;events.Add(new(){Type=0,Data=new(){Mouse=new(){Flags=attack?2u:4u}}});}
            if(use!=_use){_use=use;events.Add(Scan(0x12,!use));}
            if(_select && !selectC4){events.Add(Scan(0x06,true));}
            if(selectC4){_select=true;events.Add(Scan(0x06,false));events.Add(Scan(0x06,true));}
            if(events.Count>0)Send(events.ToArray());
            _select=false;
        }
    }
    public WindowsControl(int pid):this(new NativeBackend(pid),true) { }
    internal WindowsControl(IControlBackend backend,bool watchdog)
    {
        if(InputSize!=40) throw new NotSupportedException("SendInput expects x64 INPUT size 40");
        _backend=backend;
        if(watchdog) _watchdog=new Timer(_=>CheckWatchdog(),null,50,50);
    }
    internal static bool AllowedTap(byte scan)=>scan is 0x30 or 0x02 or 0x03 or 0x04 or 0x05 or 0x07 or 0x09 or 0x0B or 0x3B;
    public void Arm()
    { lock(_gate) { if(_fault!="" || _disposed || !_backend.Focused || _backend.StopPressed || _backend.UserBusy) throw new InvalidOperationException("Cannot arm: missing focus, manual controls held, stop key or latched fault"); _armed=true; _heartbeat=_backend.Now; } }
    public void Heartbeat()
    { lock(_gate) _heartbeat=_backend.Now; }
    private static Input Scan(ushort scan,bool up)=>new() { Type=1,Data=new InputUnion { Keyboard=new Keyboard { Scan=scan,Flags=8u|(up?2u:0u) } } };
    private static void Send(params Input[] inputs)
    { if(SendInput((uint)inputs.Length,inputs,InputSize)!=(uint)inputs.Length) throw new Win32Exception(Marshal.GetLastWin32Error(),"SendInput failed/partial; possible UIPI or game input limitation"); }
    private void ReleaseMovementUnsafe()
    {
        if(!_held)return;
        try{_backend.Keys(false);_held=false;}catch(Exception ex){_fault="key release failed: "+ex.Message;}
    }
    private void ReleaseUnsafe()
    {
        ReleaseMovementUnsafe();
        try{_backend.ReleaseTaps();}catch(Exception ex){_fault="key pulse release failed: "+ex.Message;}
        if(!_objectiveDirty)return;
        try{_backend.ObjectiveKeys(false,false,false);_objectiveDirty=_attackHeld=_useHeld=false;}
        catch(Exception ex){_fault="objective release failed: "+ex.Message;}
    }
    public void Apply(TravelCommand command)
    {
        lock(_gate)
        {
            if(_disposed || !_armed || _fault!="") throw new InvalidOperationException("Input not armed or watchdog stopped it: "+_fault);
            if(!_backend.Focused || _backend.StopPressed)
            { _fault="focus/stop key"; ReleaseUnsafe(); _armed=false; return; }
            if(command.Finished || command.StopReason!="") { ReleaseUnsafe(); return; }
            if(command.Forward)
            {
                if(!_held || _walkHeld!=command.Walk)
                { _held=true; _walkHeld=command.Walk; _backend.Keys(true,command.Walk); } // W with optional owned Shift
            }
            else ReleaseMovementUnsafe();
            if(_fault!="")return;
            if(command.Attack!=_attackHeld || command.Use!=_useHeld || command.SelectC4 || _objectiveDirty && !_attackHeld && !_useHeld)
            {
                _objectiveDirty=true;
                _backend.ObjectiveKeys(command.Attack,command.Use,command.SelectC4);
                _attackHeld=command.Attack;_useHeld=command.Use;_objectiveDirty=_attackHeld || _useHeld;
            }
            if(command.TapScan!=0){if(!AllowedTap(command.TapScan))throw new ArgumentException("Unsupported bot key pulse");_backend.Tap(command.TapScan);}
            if(command.MouseDx!=0 || command.MouseDy!=0)_backend.MouseAxes(command.MouseDx,command.MouseDy);
        }
    }
    internal void CheckWatchdog()
    {
        lock(_gate)
        {
            if(_disposed || !_armed) return;
            try
            {
                if(!_backend.Focused || _backend.StopPressed || _backend.Now-_heartbeat>250)
                { _fault="watchdog: focus/stop key or heartbeat >250ms"; _armed=false; ReleaseUnsafe(); }
            }
            catch(Exception ex) { _fault="watchdog error: "+ex.Message; _armed=false; ReleaseUnsafe(); }
        }
    }
    public void Dispose()
    {
        _watchdog?.Dispose();
        lock(_gate) { _armed=false; ReleaseUnsafe(); _disposed=true; }
    }
}
