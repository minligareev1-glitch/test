using System.Globalization;
using System.Text;

namespace CSBot;

internal sealed class GameConfig
{
    public Dictionary<string,string> Values {get;}=new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string,string> Bindings {get;}=new(StringComparer.OrdinalIgnoreCase);
    public List<string> Files {get;}=new();
    public List<string> Warnings {get;}=new();
    public required string RootFile {get;init;}
    public double DegreesPerCount=>Positive("sensitivity")*Positive("m_yaw");
    public double Positive(string name)
    {
        if(!Values.TryGetValue(name,out string? value) || !TryNumber(value,out double number) || number<=0)
            throw new InvalidDataException($"CFG: {name} отсутствует или не является положительным числом");
        return number;
    }
    public static bool TryNumber(string value,out double number)
    {
        number=0; string text=value.Trim();
        if(text.Contains(',') && text.Contains('.')) return false;
        text=text.Replace(',','.');
        return double.TryParse(text,NumberStyles.Float,CultureInfo.InvariantCulture,out number) && double.IsFinite(number);
    }
    public static double ParseDpc(string value)
    {
        if(!TryNumber(value,out double number) || number is <0.001 or >2)
            throw new ArgumentException("--degrees-per-count: нужно число 0.001..2, например 0.07106 или 0,07106; без подписей и кавычек внутри значения");
        return number;
    }
    public static GameConfig Load(string file)
    {
        string full=Path.GetFullPath(file),root=Path.GetDirectoryName(full)!;
        var config=new GameConfig{RootFile=full};
        var active=new HashSet<string>(OperatingSystem.IsWindows()?StringComparer.OrdinalIgnoreCase:StringComparer.Ordinal);
        int commands=0;
        void Read(string path,int depth)
        {
            path=Path.GetFullPath(path);
            var comparison=OperatingSystem.IsWindows()?StringComparison.OrdinalIgnoreCase:StringComparison.Ordinal;
            if(!path.StartsWith(root+Path.DirectorySeparatorChar,comparison)) throw new InvalidDataException("CFG exec выходит за пределы папки конфигурации");
            if(depth>8 || config.Files.Count>=64) throw new InvalidDataException("CFG exec: превышена глубина/число файлов");
            if(!File.Exists(path)) {config.Warnings.Add("Не найден exec-файл: "+Path.GetFileName(path)+"; его переопределения неизвестны");return;}
            if(!active.Add(path)) throw new InvalidDataException("CFG exec: цикл включений");
            if(new FileInfo(path).Length>1024*1024) throw new InvalidDataException("CFG превышает 1 MiB");
            config.Files.Add(path);
            // Relevant tokens are ASCII. Latin1 preserves legacy byte data without running any script.
            byte[] bytes=File.ReadAllBytes(path);
            int skip=bytes.AsSpan().StartsWith(new byte[]{0xEF,0xBB,0xBF})?3:0;
            foreach(var tokens in Tokenize(Encoding.Latin1.GetString(bytes,skip,bytes.Length-skip)))
            {
                if(++commands>100000) throw new InvalidDataException("Слишком много CFG-команд");
                if(tokens.Count==0) continue;
                string command=tokens[0].ToLowerInvariant();
                if(command=="exec")
                {
                    if(tokens.Count!=2) throw new InvalidDataException("CFG exec: нужен один путь");
                    string relative=tokens[1].Replace('\\',Path.DirectorySeparatorChar).Replace('/',Path.DirectorySeparatorChar);
                    if(Path.IsPathRooted(relative) || relative.Contains(':')) throw new InvalidDataException("CFG exec: абсолютные пути запрещены");
                    if(!Path.HasExtension(relative)) relative+=".cfg";
                    Read(Path.Combine(root,relative),depth+1);
                }
                else if(command=="bind" && tokens.Count==3) config.Bindings[tokens[1]]=tokens[2];
                else if(command=="unbind" && tokens.Count==2) config.Bindings.Remove(tokens[1]);
                else if(command=="unbindall") config.Bindings.Clear();
                else if(command is "sensitivity" or "m_pitch" or "m_yaw" or "m_filter" or "m_rawinput" or "m_customaccel" or "m_mouseaccel1" or "m_mouseaccel2")
                {
                    if(tokens.Count!=2) throw new InvalidDataException("CFG: неверное значение "+command);
                    config.Values[command]=tokens[1];
                }
                else if(command is "alias" or "toggle" or "incrementvar")
                    config.Warnings.Add("Динамическая CFG-команда не исполняется: "+command);
                // Everything else is deliberately ignored, never forwarded to the game or a shell.
            }
            active.Remove(path);
        }
        if(!File.Exists(full)) throw new FileNotFoundException("config.cfg не найден",full);
        Read(full,0);
        _=ParseDpc(config.DegreesPerCount.ToString("R",CultureInfo.InvariantCulture));
        if(config.Bindings.GetValueOrDefault("w")!="+forward")
            config.Warnings.Add("В CFG нужен bind w +forward; текущий бинд не подтверждён");
        foreach(string key in new[]{"m_filter","m_customaccel","m_mouseaccel1","m_mouseaccel2"})
            if(config.Values.TryGetValue(key,out var v) && (!TryNumber(v,out double n) || n!=0))
                config.Warnings.Add(key+" включён/неизвестен; фактический отклик мыши может отличаться от расчётного");
        return config;
    }
    internal static List<List<string>> Tokenize(string text)
    {
        var result=new List<List<string>>();var command=new List<string>();var token=new StringBuilder();
        bool quoted=false,started=false;
        void EndToken(){if(started){command.Add(token.ToString());token.Clear();started=false;}}
        void EndCommand(){EndToken();if(command.Count>0){result.Add(command);command=new();}}
        for(int i=0;i<text.Length;i++)
        {
            char c=text[i];
            if(c=='"'){quoted=!quoted;started=true;continue;}
            if(!quoted && c=='/' && i+1<text.Length && text[i+1]=='/')
            {while(i<text.Length && text[i]!='\n')i++;EndCommand();continue;}
            if(!quoted && (c=='\n'||c=='\r'||c==';')){EndCommand();continue;}
            if(!quoted && char.IsWhiteSpace(c)){EndToken();continue;}
            if(quoted && (c=='\n'||c=='\r')) throw new InvalidDataException("CFG: незакрытая кавычка");
            token.Append(c);started=true;
        }
        if(quoted) throw new InvalidDataException("CFG: незакрытая кавычка");
        EndCommand();return result;
    }
    public void Report(Action<string> log)
    {
        log("CFG: "+RootFile);
        log($"CFG sensitivity={Positive("sensitivity").ToString("R",CultureInfo.InvariantCulture)}; m_yaw={Positive("m_yaw").ToString("R",CultureInfo.InvariantCulture)}; calculated degrees-per-count={DegreesPerCount.ToString("G12",CultureInfo.InvariantCulture)}");
        log("CFG relevant binding: W="+Bindings.GetValueOrDefault("w","?")+"; bot never synthesizes Shift");
        foreach(string warning in Warnings) log("CFG WARNING: "+warning);
        log("CFG is disk state, not a measurement of current in-game cvars. No commands were executed and no settings were changed.");
    }
    public static bool TryRun(string[] args,out int exit)
    {
        exit=0;if(args.Length==0 || args[0]!="--inspect-config")return false;
        try {if(args.Length!=2)throw new ArgumentException("--inspect-config FILE.cfg");Load(args[1]).Report(Console.WriteLine);}
        catch(Exception e) when(e is IOException or UnauthorizedAccessException or ArgumentException)
        {Console.Error.WriteLine("CFG error: "+e.Message);exit=2;}
        return true;
    }
}
