namespace CSBot;
internal sealed record TravelOptions(bool Combined,bool RunOnClear,bool PreferRun=false)
{
    public static TravelOptions Cautious {get;}=new(false,false);
    public static TravelOptions Balanced {get;}=new(true,true);
    public static TravelOptions RunVerified {get;}=new(true,true,true);
    public static TravelOptions CombinedWalk {get;}=new(true,false);
    public static TravelOptions Parse(string name)=>name.ToLowerInvariant() switch
    {"balanced"=>Balanced,"run"=>RunVerified,"walk"=>CombinedWalk,"cautious"=>Cautious,_=>throw new ArgumentException("--motion: balanced | run | walk | cautious")};
}
