using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace CSBot;

internal sealed class ProcessMemory : IDisposable, IGameMemory
{
    private readonly Process _process;
    private bool _disposed;
    public IntPtr Handle { get; }
    public int ProcessId => _process.Id;
    public int LastReadError { get; private set; }
    public nuint LastBytesRead { get; private set; }
    public Dictionary<string, uint> Modules { get; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string, string> ModulePaths { get; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string, uint> ModuleSizes { get; } = new(StringComparer.OrdinalIgnoreCase);

    private ProcessMemory(Process process, IntPtr handle)
    {
        _process = process;
        Handle = handle;
    }

    // null means no process. Access/module errors are exceptions, not "game absent".
    public static ProcessMemory? Attach(string name, int? pid = null)
    {
        Process? process;
        if (pid.HasValue)
        {
            try { process = Process.GetProcessById(pid.Value); }
            catch (ArgumentException) { return null; }
            if (!string.Equals(process.ProcessName, name, StringComparison.OrdinalIgnoreCase))
            {
                process.Dispose();
                throw new InvalidOperationException("Указанный PID не принадлежит процессу " + name);
            }
        }
        else
        {
            var processes = Process.GetProcessesByName(name);
            if (processes.Length == 0) return null;
            if (processes.Length > 1)
            {
                string ids = string.Join(", ", processes.Select(p => p.Id));
                foreach (var p in processes) p.Dispose();
                throw new InvalidOperationException("Найдено несколько процессов. Укажи --pid. PID: " + ids);
            }
            process = processes[0];
        }

        IntPtr handle = NativeMethods.OpenProcess(
            NativeMethods.PROCESS_VM_READ | NativeMethods.PROCESS_QUERY_INFORMATION, false, process.Id);
        if (handle == IntPtr.Zero)
        {
            int error = Marshal.GetLastWin32Error();
            process.Dispose();
            throw new Win32Exception(error, "OpenProcess: не удалось открыть игру для чтения");
        }

        var mem = new ProcessMemory(process, handle);
        try
        {
            if (!NativeMethods.IsWow64Process(handle, out bool wow64))
                throw new Win32Exception(Marshal.GetLastWin32Error(), "IsWow64Process");
            if (Environment.Is64BitOperatingSystem && !wow64)
                throw new NotSupportedException("Этот ридер рассчитан на 32-битный процесс GoldSrc.");
            mem.RefreshModules();
            return mem;
        }
        catch { mem.Dispose(); throw; }
    }

    public bool HasExited
    {
        get { try { return _process.HasExited; } catch { return true; } }
    }

    public void RefreshModules()
    {
        var modules = new IntPtr[1024];
        if (!NativeMethods.EnumProcessModulesEx(Handle, modules, modules.Length * IntPtr.Size,
                out int needed, NativeMethods.LIST_MODULES_ALL))
            throw new Win32Exception(Marshal.GetLastWin32Error(), "EnumProcessModulesEx");
        if (needed > modules.Length * IntPtr.Size)
        {
            modules = new IntPtr[(needed + IntPtr.Size - 1) / IntPtr.Size];
            if (!NativeMethods.EnumProcessModulesEx(Handle, modules, modules.Length * IntPtr.Size,
                    out needed, NativeMethods.LIST_MODULES_ALL))
                throw new Win32Exception(Marshal.GetLastWin32Error(), "EnumProcessModulesEx");
        }

        Modules.Clear();
        ModuleSizes.Clear();
        ModulePaths.Clear();
        int count = Math.Min(modules.Length, needed / IntPtr.Size);
        for (int i = 0; i < count; i++)
        {
            char[] pathBuffer = new char[32768];
            uint length = NativeMethods.GetModuleFileNameEx(Handle, modules[i], pathBuffer, (uint)pathBuffer.Length);
            if (length == 0) continue;
            string path = new string(pathBuffer, 0, (int)length);
            string name = Path.GetFileName(path);
            ulong address = unchecked((ulong)modules[i].ToInt64());
            if (address > uint.MaxValue) continue;
            Modules[name] = (uint)address;
            ModulePaths[name] = path;
            if (NativeMethods.GetModuleInformation(Handle, modules[i], out var info,
                    (uint)Marshal.SizeOf<NativeMethods.ModuleInfo>()))
                ModuleSizes[name] = info.SizeOfImage;
        }
    }

    public bool ReadBytes(uint address, byte[] buffer)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        bool ok = NativeMethods.ReadProcessMemory(Handle, new IntPtr((long)address), buffer,
            (nuint)buffer.Length, out nuint bytesRead);
        LastReadError = ok ? 0 : Marshal.GetLastWin32Error();
        LastBytesRead = bytesRead;
        return ok && bytesRead == (nuint)buffer.Length;
    }

    public bool ReadUInt32(uint address, out uint value)
    {
        var buffer = new byte[4];
        value = 0;
        if (!ReadBytes(address, buffer)) return false;
        value = BitConverter.ToUInt32(buffer, 0);
        return true;
    }

    public bool ReadInt32(uint address, out int value)
    {
        var buffer = new byte[4];
        value = 0;
        if (!ReadBytes(address, buffer)) return false;
        value = BitConverter.ToInt32(buffer, 0);
        return true;
    }

    public bool ReadFloat(uint address, out float value)
    {
        var buffer = new byte[4];
        value = 0;
        if (!ReadBytes(address, buffer)) return false;
        value = BitConverter.ToSingle(buffer, 0);
        return true;
    }

    public bool ReadVec3(uint address, out float x, out float y, out float z)
    {
        var buffer = new byte[12];
        x = y = z = 0;
        if (!ReadBytes(address, buffer)) return false;
        x = BitConverter.ToSingle(buffer, 0);
        y = BitConverter.ToSingle(buffer, 4);
        z = BitConverter.ToSingle(buffer, 8);
        return true;
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        NativeMethods.CloseHandle(Handle);
        _process.Dispose();
    }
}
