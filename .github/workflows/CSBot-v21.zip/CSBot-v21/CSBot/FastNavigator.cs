using System.Diagnostics;
namespace CSBot;
// One worker owns this instance. Immutable directed walk graph is reused per map;
// temporary pose/target checks use its private geometry cache, never the input thread's.
internal sealed class FastNavigator
{
    private readonly LoadedMap _asset;private readonly WalkGeometry _walk;private readonly bool[] _supported;private readonly FastRouteSearch _search;
    private string _coverKey="";private List<(int Id,double Score)> _cover=new();
    public double BuildMs {get;}
    public int Edges {get;}
    public FastNavigator(LoadedMap asset,CancellationToken token=default)
    {
        var timer=Stopwatch.StartNew();_asset=asset;_walk=new(asset.Map);var graph=asset.Graph;
        _supported=new bool[graph.Nodes.Count];var edges=new List<RouteEdge>();
        foreach(var n in graph.Nodes)
        {
            token.ThrowIfCancellationRequested();
            if(!graph.AllowedNode(n.Id,"t",false) && !graph.AllowedNode(n.Id,"ct",false))continue;
            _supported[n.Id]=_walk.Supported(n.Origin,out _);
        }
        foreach(var n in graph.Nodes)
        {
            token.ThrowIfCancellationRequested();if(!_supported[n.Id])continue;
            foreach(var e in n.Links)
            {
                token.ThrowIfCancellationRequested();
                if(e.Flags!=0 || !_supported[e.To] || asset.Navigation.BlockedEdges.Contains((n.Id,e.To)))continue;
                if(_walk.Edge(n,graph.Nodes[e.To]))edges.Add(new(n.Id,e.To,Math.Max(.001,Math.Max(e.StoredDistance,NavGraph.Distance(n.Origin,graph.Nodes[e.To].Origin)))));
            }
        }
        Edges=edges.Count;_search=new(graph.Nodes.Count,edges);BuildMs=timer.Elapsed.TotalMilliseconds;
    }
    private List<(int Id,double Score)> Cover(WorldState world,BotSettings s,CancellationToken token)
    {
        string key=MissionPlanner.GoalKey(world)+FormattableString.Invariant($"/{s.PostPlantMinDistance}/{s.PostPlantMaxDistance}");
        if(key==_coverKey)return _cover;
        var nodes=_asset.Graph.Nodes;var bomb=world.Bomb;
        // Representative CT approach points, one per bearing sector. Static BSP
        // occlusion is only a heuristic: no enemy visibility/combat information.
        var approaches=nodes.Where(n=>_supported[n.Id] && _asset.Graph.AllowedNode(n.Id,"ct",false) && NavGraph.Distance(n.Origin,bomb) is >=320 and <=1000)
            .GroupBy(n=>(int)((Math.Atan2(n.Origin.Y-bomb.Y,n.Origin.X-bomb.X)+Math.PI)*4/Math.PI)%8)
            .Select(g=>g.OrderBy(n=>Math.Abs(NavGraph.Distance(n.Origin,bomb)-600)).First().Origin).ToArray();
        var result=new List<(int,double)>();
        foreach(var n in nodes)
        {
            token.ThrowIfCancellationRequested();double d=NavGraph.Distance(n.Origin,bomb);
            if(!_supported[n.Id] || !_asset.Graph.AllowedNode(n.Id,"t",false) || d<s.PostPlantMinDistance || d>s.PostPlantMaxDistance)continue;
            var eye=new ProbeVector(n.Origin.X,n.Origin.Y,n.Origin.Z+17);int walls=0,hidden=0;
            for(int i=0;i<8;i++)
            {
                double angle=i*Math.PI/4;
                var end=new ProbeVector(eye.X+(float)(Math.Cos(angle)*96),eye.Y+(float)(Math.Sin(angle)*96),eye.Z);
                if(!_asset.Map.WorldPointSegmentClear(eye,end))walls++;
            }
            foreach(var a in approaches)if(!_asset.Map.WorldPointSegmentClear(eye,new(a.X,a.Y,a.Z+17)))hidden++;
            if(walls==0 || hidden==0)continue;
            bool bombVisible=_asset.Map.WorldPointSegmentClear(eye,new(bomb.X,bomb.Y,bomb.Z+4));
            result.Add((n.Id,hidden*100+walls*25+(bombVisible?30:0)-Math.Abs(d-320)*.05));
        }
        _coverKey=key;_cover=result;return result;
    }
    public MissionRoute? Plan(WorldState world,ProbeVector origin,double yaw,BotSettings s,ProbeVector? avoid=null,ProbeVector? previous=null,CancellationToken token=default)
    {
        var timer=Stopwatch.StartNew();string team=world.Team==1?"t":"ct";
        if(world.Team is not (1 or 2) || !origin.IsFinite || !double.IsFinite(yaw))return null;
        var nodes=_asset.Graph.Nodes;
        bool Allowed(int id)=>_supported[id] && _asset.Graph.AllowedNode(id,team,false);
        double Penalty(int id)=>avoid is { } bad?Math.Max(0,1-NavGraph.Distance(nodes[id].Origin,bad)/96)*300:0;
        MissionRoute? Build(List<(int Id,double Cost)> goals,string kind,ProbeVector? exact=null)
        {
            token.ThrowIfCancellationRequested();var field=_search.Compute(goals,Allowed,Penalty,token);
            double Rank(NavNode n)
            {
                double d=NavGraph.Distance(origin,n.Origin);
                double heading=Math.Abs(PulseSteering.Normalize(Math.Atan2(n.Origin.Y-origin.Y,n.Origin.X-origin.X)*180/Math.PI-yaw));
                return d+field.Distance[n.Id]+s.NavHeadingPenalty*heading/180+Math.Max(0,s.NavPreferredAdvance-d)*1.5;
            }
            var anchors=nodes.Where(n=>Allowed(n.Id) && double.IsFinite(field.Distance[n.Id]) && Math.Abs(n.Origin.Z-origin.Z)<=64 && NavGraph.Distance(origin,n.Origin)<=s.NavAttachRadius)
                .OrderBy(Rank).ThenBy(n=>n.Id).Take(s.NavAttachCandidates*4);
            foreach(var a in anchors)
            {
                token.ThrowIfCancellationRequested();if(!_walk.Check(origin,a.Origin).Safe)continue;
                var path=field.Path(a.Id);if(path==null)continue;
                var raw=path.Select(id=>nodes[id].Origin).ToList();if(exact.HasValue)raw.Add(exact.Value);
                var targets=RouteLookahead.Simplify(origin,raw,s,_walk.Check,token);
                return new(kind,path,targets){ComputeMs=timer.Elapsed.TotalMilliseconds,RawTargets=raw.Count,AttachDistance=NavGraph.Distance(origin,a.Origin)};
            }
            return null;
        }
        if(world.Team==2 && world.BombPlanted && s.AutoObjectives=="on")
        {
            if(!_walk.SnapToFloor(new(world.Bomb.X,world.Bomb.Y,world.Bomb.Z+72),108,out var exact))return null;
            var goals=new List<(int,double)>();int inspected=0;
            foreach(var n in nodes.Where(n=>Allowed(n.Id) && NavGraph.Distance(n.Origin,exact)<=s.NavAttachRadius).OrderBy(n=>NavGraph.Distance(n.Origin,exact)))
            {
                token.ThrowIfCancellationRequested();if(inspected++>=s.NavAttachCandidates*4 || goals.Count>=s.NavAttachCandidates)break;
                if(_walk.Check(n.Origin,exact).Safe)goals.Add((n.Id,NavGraph.Distance(n.Origin,exact)));
            }
            return Build(goals,"defuse-approach",exact);
        }
        if(PostPlantCoordinator.Active(world,s))
        {
            bool Relocated(int id)=>previous is not { } p || NavGraph.Distance(nodes[id].Origin,p)>=s.PostPlantRelocateDistance;
            if(s.PostPlantMode=="cover")
            {
                var choices=Cover(world,s,token).Where(c=>Relocated(c.Id) && NavGraph.Distance(origin,nodes[c.Id].Origin)>=s.NavPreferredAdvance).ToArray();
                if(choices.Length>0)
                {
                    double best=choices.Max(c=>c.Score);
                    var covered=Build(choices.Select(c=>(c.Id,(best-c.Score)*2)).ToList(),"post-plant-cover");
                    if(covered!=null)return covered;
                }
            }
            var patrol=nodes.Where(n=>Allowed(n.Id) && Relocated(n.Id) && NavGraph.Distance(n.Origin,origin)>=s.NavPreferredAdvance && NavGraph.Distance(n.Origin,world.Bomb)>=s.PostPlantMinDistance && NavGraph.Distance(n.Origin,world.Bomb)<=s.PostPlantMaxDistance)
                .Select(n=>(n.Id,Math.Abs(NavGraph.Distance(n.Origin,world.Bomb)-320)*.2)).ToList();
            return Build(patrol,"post-plant-patrol");
        }
        return Build(_asset.Navigation.GoalNodes(MissionPlanner.Site(_asset,s.ObjectiveSite)).Select(id=>(id,0d)).ToList(),"site-approach");
    }
}
