namespace CSBot;

internal sealed record WalkCheck(bool Safe,string Reason,ProbeVector End);
internal sealed class WalkGeometry
{
    public const float StepHeight=18, MaxDrop=18;
    private readonly BspMap _map;
    private readonly List<int> _solidModels=new(){0};
    public IReadOnlyList<int> SolidModels=>_solidModels;
    public WalkGeometry(BspMap map)
    {
        _map=map;
        if(!map.HasClipHulls) throw new InvalidDataException("Нет clip hulls для проверки габаритов");
        string[] blockers={"func_wall","func_breakable","func_door","func_door_rotating","func_train","func_plat","func_conveyor","func_wall_toggle","func_rotating"};
        foreach(var e in map.Entities.Where(e=>blockers.Contains(e.GetValueOrDefault("classname"))))
        {
            string cls=e.GetValueOrDefault("classname","");
            if(cls is not ("func_wall" or "func_breakable"))
                throw new InvalidDataException("Динамическая brush-сущность не поддерживается для движения: "+cls);
            foreach(string key in new[]{"origin","angles"})
                if(e.TryGetValue(key,out var value) && (!BspMap.TryVector(value,out var v) || v!=default))
                    throw new InvalidDataException("Преобразованная brush-сущность не поддерживается: "+cls);
            string model=e.GetValueOrDefault("model","");
            if(!model.StartsWith('*') || !int.TryParse(model.AsSpan(1),out int id) || id<=0 || id>=map.Models.Count)
                throw new InvalidDataException("Некорректная solid brush model");
            _solidModels.Add(id);
        }
        // Unknown brush classes must not silently become passable.
        string[] nonSolid={"func_illusionary","func_bomb_target","func_buyzone","func_ladder","func_water"};
        foreach(var e in map.Entities.Where(e=>e.GetValueOrDefault("model","").StartsWith('*')))
            if(!blockers.Contains(e.GetValueOrDefault("classname")) && !nonSolid.Contains(e.GetValueOrDefault("classname")) &&
                !e.GetValueOrDefault("classname","").StartsWith("trigger_",StringComparison.Ordinal))
                throw new InvalidDataException("Неизвестная brush-сущность: "+e.GetValueOrDefault("classname"));
    }
    public bool Visible(ProbeVector eye,ProbeVector target)=>_solidModels.All(model=>_map.PointSegmentClear(eye,target,model));
    public HullTrace Trace(ProbeVector a,ProbeVector b)
    {
        HullTrace best=new(true,false,1,b,default);
        foreach(int model in _solidModels)
        {
            var hit=_map.TraceHull(a,b,model,1);
            if(hit.StartSolid || (!hit.Clear && (best.Clear || hit.Fraction<best.Fraction))) best=hit;
        }
        return best;
    }
    public bool Supported(ProbeVector p,out ProbeVector grounded)
    {
        grounded=p;
        var down=Trace(p,new(p.X,p.Y,p.Z-2));
        if(down.StartSolid || down.Clear || down.Contents!=-2 || down.Normal.Z<0.7) return false;
        grounded=down.End; return true;
    }
    public bool SnapToFloor(ProbeVector p,float maximum,out ProbeVector grounded)
    {
        grounded=p;
        var down=Trace(p,new(p.X,p.Y,p.Z-maximum));
        if(down.StartSolid || down.Clear || down.Contents!=-2 || down.Normal.Z<0.7) return false;
        grounded=down.End; return true;
    }
    private readonly Dictionary<(int,int),bool> _edges=new();
    public bool Edge(NavNode a,NavNode b)
    {
        if(!_edges.TryGetValue((a.Id,b.Id),out bool safe))
        { safe=Check(a.Origin,b.Origin).Safe; _edges[(a.Id,b.Id)]=safe; }
        return safe;
    }
    public WalkCheck PredictHeading(ProbeVector from,double yaw,double distance)
    {
        if(!double.IsFinite(yaw) || !double.IsFinite(distance) || distance is <0 or >160)
            return new(false,"invalid heading prediction",from);
        double r=yaw*Math.PI/180;
        var raised=new ProbeVector(from.X,from.Y,from.Z+StepHeight);
        if(!Trace(from,raised).Clear) return new(false,"no overhead clearance for prediction",from);
        var end=new ProbeVector((float)(from.X+Math.Cos(r)*distance),(float)(from.Y+Math.Sin(r)*distance),raised.Z);
        if(!SnapToFloor(end,StepHeight+MaxDrop+.1f,out var floor))
            return new(false,"predicted heading has no safe floor",from);
        return Check(from,floor);
    }
    public WalkCheck CheckStepLanding(ProbeVector from,ProbeVector velocity,float takeoffZ)
    {
        if(!from.IsFinite || !velocity.IsFinite || !float.IsFinite(takeoffZ))return new(false,"invalid landing pose",from);
        // Check current support and a short momentum corridor; no air input is used.
        double speed=Math.Sqrt((double)velocity.X*velocity.X+(double)velocity.Y*velocity.Y);
        double distance=speed*.25;
        if(distance>72.5)return new(false,"landing forecast too fast",from);
        var end=new ProbeVector(from.X+velocity.X*.25f,from.Y+velocity.Y*.25f,from.Z);
        if(!Trace(from,end).Clear)return new(false,"landing momentum corridor blocked",from);
        int steps=Math.Max(1,(int)Math.Ceiling(distance/4));ProbeVector at=from;
        for(int i=0;i<=steps;i++)
        {
            var p=new ProbeVector(from.X+(end.X-from.X)*i/steps,from.Y+(end.Y-from.Y)*i/steps,from.Z);
            if(!SnapToFloor(p,MaxDrop+.1f,out var floor))return new(false,"no floor within 18 units along landing forecast",p);
            if(takeoffZ-floor.Z>MaxDrop+.1f || floor.Z>takeoffZ+2)
                return new(false,"landing floor outside takeoff height/drop bound",floor);
            if(i>0 && !Check(at,floor).Safe)return new(false,"landing floor corridor not walkable",floor);
            at=floor;
        }
        return new(true,"bounded step landing corridor checked",at);
    }
    public WalkCheck Check(ProbeVector from,ProbeVector target)
    {
        if(!from.IsFinite || !target.IsFinite || NavGraph.Distance(from,target)>1024)
            return new(false,"invalid/overlong walking segment",from);
        if(!Supported(from,out var at)) return new(false,"no standing hull clearance or floor support at start",from);
        double horizontal=Math.Sqrt(Math.Pow(target.X-from.X,2)+Math.Pow(target.Y-from.Y,2));
        int steps=Math.Max(1,(int)Math.Ceiling(horizontal/4));
        for(int i=1;i<=steps;i++)
        {
            float x=(float)(from.X+(target.X-from.X)*(double)i/steps), y=(float)(from.Y+(target.Y-from.Y)*(double)i/steps);
            var next=new ProbeVector(x,y,at.Z);
            var lateral=Trace(at,next);
            ProbeVector floor=default;
            bool found=!lateral.StartSolid && lateral.Clear && SnapToFloor(next,MaxDrop+0.1f,out floor);
            if(!found)
            {
                var up=new ProbeVector(at.X,at.Y,at.Z+StepHeight);
                var across=new ProbeVector(x,y,up.Z);
                if(!Trace(at,up).Clear || !Trace(up,across).Clear ||
                    !SnapToFloor(across,StepHeight+MaxDrop+0.1f,out floor))
                    return new(false,"blocked hull, missing floor, steep slope or excessive step/drop",at);
            }
            if(floor.Z-at.Z>StepHeight+0.1f || at.Z-floor.Z>MaxDrop+0.1f)
                return new(false,"step/drop exceeds 18 units",at);
            at=floor;
        }
        if(Math.Abs(at.Z-target.Z)>3) return new(false,"target height differs from reachable floor",at);
        return new(true,"standing hull + sampled support/step checks passed",at);
    }
}
