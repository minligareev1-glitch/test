namespace CSBot;
internal readonly record struct RouteEdge(int From,int To,double Cost);
internal sealed record RouteField(double[] Distance,int[] Next,int[] Goal)
{
    public List<int>? Path(int start)
    {
        if(start<0 || start>=Next.Length || !double.IsFinite(Distance[start]))return null;
        var result=new List<int>();int id=start;
        for(int i=0;i<=Next.Length;i++)
        {
            result.Add(id);if(Next[id]<0)return result;
            id=Next[id];if(id>=Next.Length)throw new InvalidDataException("Invalid route field");
        }
        throw new InvalidDataException("Route field cycle");
    }
}
internal sealed class FastRouteSearch
{
    private readonly List<RouteEdge>[] _reverse;
    public FastRouteSearch(int count,IEnumerable<RouteEdge> edges)
    {
        if(count<1)throw new ArgumentException("Empty graph");
        _reverse=Enumerable.Range(0,count).Select(_=>new List<RouteEdge>()).ToArray();
        foreach(var e in edges)
        {
            if(e.From<0 || e.From>=count || e.To<0 || e.To>=count || !double.IsFinite(e.Cost) || e.Cost<=0)throw new ArgumentException("Invalid graph edge");
            _reverse[e.To].Add(e);
        }
    }
    public RouteField Compute(IEnumerable<(int Id,double Cost)> goals,Func<int,bool> allowed,Func<int,double>? penalty=null,CancellationToken token=default)
    {
        int count=_reverse.Length;var distance=Enumerable.Repeat(double.PositiveInfinity,count).ToArray();var next=Enumerable.Repeat(-1,count).ToArray();var goal=Enumerable.Repeat(-1,count).ToArray();
        var queue=new PriorityQueue<int,double>();
        foreach(var g in goals)
        {
            if(g.Id<0 || g.Id>=count || !double.IsFinite(g.Cost) || g.Cost<0)throw new ArgumentException("Invalid goal");
            if(allowed(g.Id) && g.Cost<distance[g.Id]){distance[g.Id]=g.Cost;goal[g.Id]=g.Id;queue.Enqueue(g.Id,g.Cost);}
        }
        while(queue.TryDequeue(out int id,out double cost))
        {
            token.ThrowIfCancellationRequested();if(cost>distance[id])continue;
            double extra=penalty?.Invoke(id)??0;if(!double.IsFinite(extra)||extra<0)throw new ArgumentException("Invalid penalty");
            foreach(var e in _reverse[id])
            {
                if(!allowed(e.From))continue;
                double candidate=cost+e.Cost+extra;
                if(candidate>=distance[e.From])continue;
                distance[e.From]=candidate;next[e.From]=id;goal[e.From]=goal[id];queue.Enqueue(e.From,candidate);
            }
        }
        return new(distance,next,goal);
    }
}
