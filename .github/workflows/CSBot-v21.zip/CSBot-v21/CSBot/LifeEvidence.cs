namespace CSBot;
// Avoid treating stale HUD zeroes / a level transition as a confirmed death.
internal sealed class LifeEvidence
{
    private string _context="";
    private bool _alive;
    private (float Time,long Wall)? _dead;
    public bool Observe(string context,MoveSample sample,int hp,long now)
    {
        string key=$"{context}/{sample.Pointer:X}/{sample.PlayerIndex}";
        if(key!=_context){_context=key;_alive=false;_dead=null;}
        if(sample.Server!=0 || sample.Spectator!=0 || !float.IsFinite(sample.Time) || sample.FrameTime<=0 || sample.FrameTime>.2f)
        {_dead=null;return false;}
        if(hp>0 && hp<=500 && sample.Dead==0 && sample.DeadFlag==0){_alive=true;_dead=null;return false;}
        if(!_alive || !(hp==0 || sample.Dead!=0 || sample.DeadFlag!=0)){_dead=null;return false;}
        bool confirmed=_dead.HasValue && now>_dead.Value.Wall && now-_dead.Value.Wall<=250 && sample.Time>_dead.Value.Time;
        if(!_dead.HasValue || sample.Time!=_dead.Value.Time || now-_dead.Value.Wall>250)_dead=(sample.Time,now);
        return confirmed;
    }
}
