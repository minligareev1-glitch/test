namespace CSBot;
internal static class PlanAcceptance
{
    public static bool Current(long plannedEpoch,long currentEpoch,string plannedContext,string currentContext,ProbeVector plannedOrigin,ProbeVector currentOrigin)=>
        plannedEpoch==currentEpoch && plannedContext==currentContext && plannedOrigin.IsFinite && currentOrigin.IsFinite && NavGraph.Distance(plannedOrigin,currentOrigin)<=64;
}
