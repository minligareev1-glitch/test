namespace CSBot;
internal sealed record RespawnStep(bool Waiting,bool Entered=false,bool Resumed=false);
// Does not own authorization. Death releases keys but retains prior intent;
// focus, UI and watchdog still revoke it in the supervisor.
internal sealed class RespawnLifecycle(BotSettings settings)
{
    private bool _waiting;private MoveSample? _last;private long _since=-1,_wall,_changed;private int _advances;
    public RespawnStep Observe(MoveSample s,int hp,long now)
    {
        if(hp<=0 || s.Dead!=0 || s.DeadFlag!=0 || s.Spectator!=0)
        {bool entered=!_waiting;_waiting=true;_last=null;_since=-1;_advances=0;return new(true,entered);}
        if(!_waiting)return new(false);
        bool valid=hp<=500 && s.Server==0 && s.OnGround>=0 && s.FrameTime>0 && s.FrameTime<=.2f &&
            (s.Flags&((1<<14)|(1<<12)))==0 && float.IsFinite(s.Time) && s.Origin.IsFinite && s.Angles.IsFinite && s.Velocity.IsFinite;
        if(!valid){_last=null;_since=-1;_advances=0;return new(true);}
        if(_last is not { } old || old.Pointer!=s.Pointer || old.PlayerIndex!=s.PlayerIndex || s.Time<old.Time || now<=_wall || now-_wall>250 || now-_changed>250 || NavGraph.Distance(old.Origin,s.Origin)>64)
        {_since=now;_changed=now;_advances=0;}
        else if(s.Time>old.Time){_advances++;_changed=now;}
        _last=s;_wall=now;
        if(now-_since<settings.RespawnWarmupMs || _advances<3)return new(true);
        _waiting=false;_last=null;return new(false,Resumed:true);
    }
}
