namespace CSBot;

internal readonly record struct MoveSample(uint Pointer, int PlayerIndex, int Server,
    float Time, float FrameTime, ProbeVector Origin, ProbeVector Angles, ProbeVector Velocity,
    ProbeVector ViewOffset, int Flags, int Dead, int DeadFlag, int Spectator, int OnGround);

internal sealed class MovementProbe
{
    // Derived from the supplied PE, not from version strings or random memory scans.
    public const uint PointerRva = 0x1329A8;
    public const uint MoveCodeRva = 0x63710;
    public const uint InitCodeRva = 0x637E0;
    public const int HeaderSize = 0xEC;
    private readonly IGameMemory _mem;
    public MovementProbe(IGameMemory mem) => _mem = mem;

    // PM_Move: mov edx,[esp+8]; mov eax,[esp+4]; xor ecx,ecx; mov [global],eax; test edx,edx.
    public static byte[] ExpectedMoveCode(uint global)
    {
        byte[] code = { 0x8B,0x54,0x24,0x08,0x8B,0x44,0x24,0x04,0x33,0xC9,0xA3,0,0,0,0,0x85,0xD2 };
        BitConverter.GetBytes(global).CopyTo(code, 11);
        return code;
    }
    // PM_Init: mov eax,[esp+4]; mov [global],eax.
    public static byte[] ExpectedInitCode(uint global)
    {
        byte[] code = { 0x8B,0x44,0x24,0x04,0xA3,0,0,0,0 };
        BitConverter.GetBytes(global).CopyTo(code, 5);
        return code;
    }

    public bool TryRead(out MoveSample sample, out string reason)
    {
        sample = default;
        reason = "";
        if (!_mem.Modules.TryGetValue("client.dll", out uint baseAddress) ||
            !_mem.ModuleSizes.TryGetValue("client.dll", out uint size))
        { reason = "client.dll недоступен"; return false; }
        if ((ulong)PointerRva + 4 > size || (ulong)InitCodeRva + 9 > size ||
            (ulong)MoveCodeRva + 17 > size || (ulong)baseAddress + size > (ulong)uint.MaxValue + 1)
        { reason = "профиль выходит за пределы 32-битного модуля"; return false; }
        uint pointerAddress = baseAddress + PointerRva;
        if (!MatchCode(baseAddress + MoveCodeRva, ExpectedMoveCode(pointerAddress), "PM_Move", out reason) ||
            !MatchCode(baseAddress + InitCodeRva, ExpectedInitCode(pointerAddress), "PM_Init", out reason)) return false;
        if (!_mem.ReadUInt32(pointerAddress, out uint pointer))
        { reason = ReadError("pmove pointer"); return false; }
        if (pointer < 0x10000 || (pointer & 3) != 0 ||
            (ulong)pointer + HeaderSize > (ulong)uint.MaxValue + 1)
        { reason = $"pmove=0x{pointer:X8}: не готов или невалиден"; return false; }
        var buffer = new byte[HeaderSize];
        if (!_mem.ReadBytes(pointer, buffer)) { reason = ReadError("pmove header"); return false; }
        if (!_mem.ReadUInt32(pointerAddress, out uint second))
        { reason = ReadError("pmove recheck"); return false; }
        if (second != pointer) { reason = "указатель pmove изменился во время чтения"; return false; }
        return TryDecode(pointer, buffer, out sample, out reason);
    }

    private bool MatchCode(uint address, byte[] expected, string label, out string reason)
    {
        var actual = new byte[expected.Length];
        if (!_mem.ReadBytes(address, actual)) { reason = ReadError(label); return false; }
        if (!actual.AsSpan().SequenceEqual(expected))
        {
            reason = $"{label}: инструкции не совпадают с исследованным профилем; адреса не используются";
            return false;
        }
        reason = "";
        return true;
    }
    private string ReadError(string label) => $"{label}: Win32={_mem.LastReadError}, bytes={_mem.LastBytesRead}";

    public static bool TryDecode(uint pointer, byte[] data, out MoveSample sample, out string reason)
    {
        sample = default;
        reason = "";
        if (data.Length != HeaderSize) { reason = "неполный заголовок playermove"; return false; }
        int I(int offset) => BitConverter.ToInt32(data, offset);
        float F(int offset) => BitConverter.ToSingle(data, offset);
        ProbeVector V(int offset) => new(F(offset), F(offset + 4), F(offset + 8));
        var value = new MoveSample(pointer, I(0), I(4), F(0x0C), F(0x10), V(0x38), V(0x44),
            V(0x5C), V(0x80), I(0xB8), I(0xD0), I(0xD4), I(0xD8), I(0xE0));
        if (value.PlayerIndex < 0 || value.PlayerIndex >= 32 || value.Server != 0 ||
            I(8) is < 0 or > 1 || value.Dead is < 0 or > 1 || value.DeadFlag is < 0 or > 4 ||
            value.OnGround is < -1 or >= 600)
        { reason = "поля заголовка не соответствуют ожидаемому клиентскому playermove"; return false; }
        if (!float.IsFinite(value.Time) || value.Time < 0 || !float.IsFinite(value.FrameTime) ||
            value.FrameTime < 0 || value.FrameTime > 1 ||
            !FiniteBounded(value.Origin, 131072) || !FiniteBounded(value.Angles, 36000) ||
            !FiniteBounded(value.Velocity, 1_000_000) || !FiniteBounded(value.ViewOffset, 4096))
        { reason = "неправдоподобные или нечисловые поля движения"; return false; }
        sample = value;
        return true;
    }

    private static bool FiniteBounded(ProbeVector v, float limit) => v.IsFinite &&
        Math.Abs(v.X) <= limit && Math.Abs(v.Y) <= limit && Math.Abs(v.Z) <= limit;
}
