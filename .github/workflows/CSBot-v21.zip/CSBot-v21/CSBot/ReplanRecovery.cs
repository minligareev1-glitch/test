namespace CSBot;

internal sealed record RecoveryStep(string Mode,string StopReason="",MapRoute? Route=null);

// No process access or input in this state machine. Caller keeps read/focus/death/
// watchdog guards active and sends neutral input on every recovery update.
internal sealed class ReplanRecovery(Func<ProbeVector,Task<MapRoute?>> planner,int maxAttempts=3,BotSettings? settings=null)
{
    private readonly BotSettings _s=settings??new();
    public bool Active {get;private set;}
    public int Attempts {get;private set;}
    private long _started,_stableSince=-1,_notBefore;
    private ProbeVector _stableOrigin,_plannedOrigin;
    private Task<MapRoute?>? _task;
    public static bool CanRecover(string reason)=>
        reason.StartsWith("live path rejected:",StringComparison.Ordinal) ||
        reason.StartsWith("heading clearance blocked",StringComparison.Ordinal) ||
        reason.StartsWith("stuck:",StringComparison.Ordinal) ||
        reason.StartsWith("mouse input has no yaw response",StringComparison.Ordinal) ||
        reason.StartsWith("mouse pulse budget exhausted for current waypoint",StringComparison.Ordinal) ||
        reason.StartsWith("turn timeout:",StringComparison.Ordinal);
    public string Begin(string reason,long now)
    {
        if(!CanRecover(reason))return reason;
        if(Active)return "recovery already active";
        if(maxAttempts>0 && Attempts>=maxAttempts)return $"recovery exhausted: maximum {maxAttempts} replans per run; last failure: "+reason;
        Attempts++;Active=true;_started=now;_notBefore=now+(maxAttempts==0 && Attempts>1?_s.RecoveryBackoffMs:0);_stableSince=-1;_task=null;
        return "";
    }
    private RecoveryStep Stop(string reason)
    {Active=false;return new("recovery-stop",reason);}
    private RecoveryStep Retry(long now,string reason)
    {
        Active=false;
        string stop=Begin("live path rejected: "+reason,now);
        return stop==""?new("recovery-retry: "+reason):Stop(stop);
    }
    public RecoveryStep Tick(MoveSample sample,long now,bool supported)
    {
        if(!Active)return new("idle");
        if(now-_started>_s.RecoveryTimeoutMs)return Stop($"recovery timeout >{_s.RecoveryTimeoutMs}ms; no safe resume");
        if(now<_notBefore)return new("recovery-backoff");
        if(!supported || sample.OnGround<0 || sample.Velocity.Length>10)
        { _stableSince=-1;return new("recovery-brake"); }
        if(_stableSince<0 || NavGraph.Distance(sample.Origin,_stableOrigin)>2)
        { _stableSince=now;_stableOrigin=sample.Origin;return new("recovery-stabilize"); }
        if(now-_stableSince<_s.RecoveryStableMs)return new("recovery-stabilize");
        if(_task==null)
        {
            _plannedOrigin=sample.Origin;
            try { _task=planner(_plannedOrigin); }
            catch(Exception ex) {return Stop("recovery planner failed: "+ex.Message);}
            return new("recovery-planning");
        }
        if(!_task.IsCompleted)return new("recovery-planning");
        if(_task.IsFaulted || _task.IsCanceled)
            return Stop("recovery planner failed: "+(_task.Exception?.GetBaseException().Message??"cancelled"));
        if(NavGraph.Distance(sample.Origin,_plannedOrigin)>2)return Retry(now,"pose moved during planning");
        var route=_task.GetAwaiter().GetResult();
        if(route==null || route.Route.Nodes.Count==0)return Retry(now,"no checked route from current position");
        Active=false;return new("recovery-ready",Route:route);
    }
}
