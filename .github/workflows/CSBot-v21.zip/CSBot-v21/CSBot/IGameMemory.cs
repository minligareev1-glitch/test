namespace CSBot;

// Kept small so reader behaviour can be tested without a live Windows game.
internal interface IGameMemory
{
    Dictionary<string, uint> Modules { get; }
    Dictionary<string, uint> ModuleSizes { get; }
    int LastReadError { get; }
    nuint LastBytesRead { get; }
    void RefreshModules();
    bool ReadBytes(uint address, byte[] buffer);
    bool ReadInt32(uint address, out int value);
    bool ReadUInt32(uint address, out uint value);
    bool ReadVec3(uint address, out float x, out float y, out float z);
}
