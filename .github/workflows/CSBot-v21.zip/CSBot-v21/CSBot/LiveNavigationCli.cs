using System.ComponentModel;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace CSBot;

internal static class LiveNavigationCli
{
    private const string ClientHash="b474ecfbb6f2fc6c4aa48fceb0b5735dfe2cb23ce06ba0a1008137cd228c714a";
    private const string HwHash="319fd65a9151d42c451c9821a78a031d20da51fcc5db2f555de1651416469c3c";
    private static string Hash(string path)=>Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant();
    public static bool TryRun(string[] args,out int exit)
    {
        exit=0;
        if(args.Length==0 || args[0]!="--live-nav") return false;
        try { exit=Run(args); }
        catch(Exception ex) when(ex is IOException or UnauthorizedAccessException or ArgumentException or InvalidOperationException or Win32Exception or NotSupportedException or FormatException or OverflowException)
        { Console.Error.WriteLine("Live navigation stopped: "+ex.Message); exit=2; }
        return true;
    }
    private static int Run(string[] args)
    {
        if(args.Length<3) throw new ArgumentException("--live-nav GRAPH BSP --site a|b --team t|ct [--config FILE] [--settings FILE] [--recovery stop|replan] [--recovery-limit N] [--execute --confirm-local-dust2] [--degrees-per-count N] [--pid N]");
        string settingsPath=Path.GetFullPath("config.txt");bool explicitSettings=false;
        for(int j=3;j<args.Length;j++)if(args[j]=="--settings")
        {if(++j>=args.Length)throw new ArgumentException("--settings FILE");settingsPath=Path.GetFullPath(args[j]);explicitSettings=true;}
        if(explicitSettings && !File.Exists(settingsPath))throw new FileNotFoundException("Bot settings file not found",settingsPath);
        bool settingsLoaded=File.Exists(settingsPath);
        var settings=settingsLoaded?BotSettings.Load(settingsPath):new BotSettings();
        string motion=settings.Motion,recoveryMode="stop";
        string site="a",team="t",logPath="live-nav.log",jsonPath="live-plan.json";
        bool execute=false,confirm=false; double dpc=settings.DegreesPerCount; int recoveryLimit=settings.RecoveryLimit; int? pid=null; string? configPath=null; bool manualDpc=dpc>0;
        for(int i=3;i<args.Length;i++)
        {
            string Value() { if(++i>=args.Length) throw new ArgumentException("Missing option value"); return args[i]; }
            switch(args[i])
            {
                case "--settings":_=Value();break;
                case "--recovery-limit":
                    if(!int.TryParse(Value(),NumberStyles.None,CultureInfo.InvariantCulture,out recoveryLimit) || recoveryLimit<0 || recoveryLimit>1000)throw new ArgumentException("--recovery-limit: 0 (continuous) or 1..1000");
                    break;
                case "--recovery":recoveryMode=Value().ToLowerInvariant();break;
                case "--motion":motion=Value().ToLowerInvariant();break;
                case "--site":site=Value().ToLowerInvariant();break;
                case "--team":team=Value().ToLowerInvariant();break;
                case "--log":logPath=Value();break;
                case "--json":jsonPath=Value();break;
                case "--pid":
                    if(!int.TryParse(Value(),NumberStyles.None,CultureInfo.InvariantCulture,out int id) || id<=0) throw new ArgumentException("--pid: нужен положительный PID процесса hl.exe");
                    pid=id;break;
                case "--config":configPath=Value();break;
                case "--execute":execute=true;break;
                case "--confirm-local-dust2":confirm=true;break;
                case "--degrees-per-count":dpc=GameConfig.ParseDpc(Value());manualDpc=true;break;
                default:throw new ArgumentException("Unknown live option: "+args[i]);
            }
        }
        if(recoveryMode is not ("stop" or "replan"))throw new ArgumentException("--recovery: stop | replan");
        var travelOptions=TravelOptions.Parse(motion);
        if(site is not ("a" or "b") || team is not ("t" or "ct")) throw new ArgumentException("site=a|b, team=t|ct");
        if(execute && !confirm)
            throw new ArgumentException("Execute requires --confirm-local-dust2");
        if(!OperatingSystem.IsWindows()) throw new NotSupportedException("Live process/input available only on Windows x64");
        using var file=new StreamWriter(logPath,false,new UTF8Encoding(false)) {AutoFlush=true};
        void Log(string s) { var line=$"[{DateTimeOffset.Now:O}] {s}"; Console.WriteLine(line); file.WriteLine(line); }
        Log("CSBot v14: config.txt tuning, segment-scoped steering budget, verified running");
        Log(settingsLoaded?"SETTINGS FILE "+settingsPath:"SETTINGS: config.txt not found; built-in conservative defaults");
        settings.Report(Log);Log($"EFFECTIVE motion={motion}; recoveryLimit={recoveryLimit}; degreesPerCountOverride={dpc}");
        var map=BspMap.Load(args[2]); var graph=NavGraph.Load(args[1]);
        if(!map.MatchesSuppliedDust2) throw new InvalidDataException("Live mode supports only the supplied de_dust2 BSP SHA256");
        if(Hash(args[1])!="215f7fa0a08c55c95ad68a74d4c17f92960960fab4315598db84482e65a49a18")
            throw new InvalidDataException("Live mode requires the checked de_dust2 graph fingerprint");
        var walk=new WalkGeometry(map); var nav=new MapNavigation(graph,map);
        using var mem=ProcessMemory.Attach("hl",pid) ?? throw new InvalidOperationException("hl.exe not found. Load local de_dust2 and spawn first.");
        foreach(var (name,expected) in new[]{("client.dll",ClientHash),("hw.dll",HwHash)})
        {
            if(!mem.ModulePaths.TryGetValue(name,out string? path) || Hash(path)!=expected)
                throw new InvalidDataException(name+" disk fingerprint differs from supplied DLL; live mode refused");
            Log(name+" disk SHA256 matches supplied profile");
        }
        if(configPath==null && mem.ModulePaths.TryGetValue("client.dll",out var clientPath))
        {
            var directory=new DirectoryInfo(Path.GetDirectoryName(clientPath)!);
            // GoldSrc mod/cl_dlls/client.dll -> mod/config.cfg. No machine-wide scanning.
            string candidate=Path.Combine(directory.Name.Equals("cl_dlls",StringComparison.OrdinalIgnoreCase)?directory.Parent!.FullName:directory.FullName,"config.cfg");
            if(File.Exists(candidate)) configPath=candidate;
        }
        GameConfig? config=null;
        if(configPath!=null) {config=GameConfig.Load(configPath);config.Report(Log);}
        if(!manualDpc && config!=null) dpc=GameConfig.ParseDpc(config.DegreesPerCount.ToString("R",CultureInfo.InvariantCulture));
        if(execute && dpc==0) throw new ArgumentException("Не найден config.cfg. Укажи --config PATH либо --degrees-per-count, например 0.07106");
        if(execute && config!=null && config.Bindings.GetValueOrDefault("w")!="+forward")
            throw new InvalidDataException("В CFG не подтверждены W=+forward; управление не включено");
        Log($"Mouse calibration source={(manualDpc?"CLI/config.txt override":config!=null?"CFG sensitivity*m_yaw":"not configured (preview only)")}; degrees-per-count={dpc.ToString("G12",CultureInfo.InvariantCulture)}");
        var probe=new MovementProbe(mem); var reader=new GameReader(mem,_=>{});
        if(!reader.DiscoverLocalPlayer()) throw new InvalidOperationException("HUD profile unavailable: "+reader.LastFailure);
        using var input=execute?new WindowsControl(mem.ProcessId):null;
        Log($"PID={mem.ProcessId}; mode={(execute?"EXECUTE waiting for F8":"PREVIEW read-only")}; team={team}; site={site}; motion={motion}; recovery={recoveryMode}; recoveryLimit={recoveryLimit}; static solid models={walk.SolidModels.Count}");
        Log("No automatic live map/team/menu detection. User must confirm local de_dust2, correct team, standard W/+forward (Shift is never synthesized). Do not touch movement/mouse while armed.");
        Log("F8 arm once while game focused; F9 stop; Escape/console/focus loss stop after arming. Safety stops never auto-resume. Selected route failures can replan only in recovery mode. Keep pitch near horizon.");
        using var cancellation=new CancellationTokenSource();
        bool armed=false,lastF8=WindowsControl.KeyDown(0x77);
        ConsoleCancelEventHandler handler=(_,e)=>{ e.Cancel=true; cancellation.Cancel(); };
        Console.CancelKeyPress+=handler;
        try
        {
            var guard=new LiveSampleGuard(); TravelController? controller=null; MapRoute? plan=null;
            long lastPlan=-10000,lastLog=-10000; ProbeVector planPosition=default;
            // Separate geometry/cache instances: no concurrent mutation of live walk/nav caches.
            var recovery=new ReplanRecovery(origin=>Task.Run(()=>
                new MapNavigation(graph,map).Plan(origin,site,team,new WalkGeometry(map))),recoveryLimit,settings);
            long lastRecoveryLog=-10000,lastLandingLog=-10000;string recoveryPhase="";
            var landing=new StepLandingPause(walk.CheckStepLanding,p=>walk.Supported(p,out _),settings);
            while(!cancellation.IsCancellationRequested && !mem.HasExited)
            {
                long now=Environment.TickCount64;
                if(WindowsControl.KeyDown(0x78)) { Log("STOP F9"); return 0; }
                bool focused=WindowsControl.Focused(mem.ProcessId),f8=WindowsControl.KeyDown(0x77),pressF8=f8&&!lastF8; lastF8=f8;
                if(input?.Fault is {Length:>0} fault) { Log("STOP "+fault); return 4; }
                if(armed && !focused) { Log("STOP focus lost"); return 4; }
                if(!probe.TryRead(out var sample,out string reason) || !reader.TryReadState(out var health))
                {
                    if(armed) { Log("STOP read failure: "+reason+" "+reader.LastFailure); return 4; }
                    Log("WAIT read: "+reason+" "+reader.LastFailure); guard=new(); Thread.Sleep(100); continue;
                }
                // A second independently validated header checks context, not atomicity of all fields.
                if(!probe.TryRead(out var check,out reason) || check.Pointer!=sample.Pointer || check.PlayerIndex!=sample.PlayerIndex ||
                    check.Dead!=sample.Dead || check.DeadFlag!=sample.DeadFlag || check.Spectator!=sample.Spectator)
                {
                    if(armed) { Log("STOP inconsistent movement context: "+reason); return 4; }
                    guard=new(); Thread.Sleep(50); continue;
                }
                sample=check;
                bool checkedLanding=execute && travelOptions.Combined && recoveryMode=="replan";
                var landingState=armed && checkedLanding?landing.Observe(sample,now):new LandingDecision();
                bool supportedAir=landingState.Waiting || (armed && travelOptions.Combined && sample.OnGround<0 && Math.Abs(sample.Velocity.Z)<=100 &&
                    walk.SnapToFloor(sample.Origin,8,out _));
                string invalid=guard.Observe(sample,health.Health,now,supportedAir,landingState.Waiting?settings.LandingPauseMs:120);
                if(landingState.StopReason!="")invalid=(invalid==""?"":invalid+"; ")+landingState.StopReason;
                if(invalid!="")
                {
                    if(armed) { Log($"STOP sample guard: {invalid}; frameTime={sample.FrameTime:R}; onGround={sample.OnGround}; velocity={sample.Velocity}; origin={sample.Origin}"); return 4; }
                    if(now-lastLog>1000) { Log("WAIT "+invalid); lastLog=now; }
                    guard=new(); plan=null; Thread.Sleep(50); continue;
                }
                if(!armed && guard.Advances>=3 && now-lastPlan>2000)
                {
                    plan=nav.Plan(sample.Origin,site,team,walk); planPosition=sample.Origin;
                    lastPlan=Environment.TickCount64;
                    if(plan==null) Log("NO WALK ROUTE from live origin "+sample.Origin);
                    else
                    {
                        var report=new { format="CSBot.live-plan.v1", controllerVersion="v14-settings", motion, recoveryMode, settingsFile=settingsLoaded?settingsPath:null,settings, anchorSelection="min attachment distance plus graph cost", capturedAt=DateTimeOffset.Now,
                            pid=mem.ProcessId, origin=sample.Origin, angles=sample.Angles, sample.Time,
                            mapSha256=map.Sha256, liveMapVerified=false, manualMapConfirmation=confirm,
                            executeRequested=execute, armed=false, standingHullChecked=true, sampledSupportAndStepsChecked=true,
                            liveBrushStateVerified=false, team, site, plan.Anchor, plan.AnchorDistance,
                            plan.Route.Cost, nodes=plan.Route.Nodes.Select(id=>new{id,origin=graph.Nodes[id].Origin}) };
                        File.WriteAllText(jsonPath,JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}));
                        Log($"LIVE PLAN origin={sample.Origin}; yaw={sample.Angles.Y:F3}; anchor={plan.Anchor}; goal={plan.Route.Nodes[^1]}; nodes={plan.Route.Nodes.Count}; saved={jsonPath}");
                    }
                    // Planning can take longer than sample freshness window. Warm up again before arming.
                    guard=new(); Thread.Sleep(50); continue;
                }
                if(execute && !armed && pressF8)
                {
                    if(!focused || guard.Advances<3 || plan==null || now-lastPlan>1800 || NavGraph.Distance(sample.Origin,planPosition)>2 || sample.Velocity.Length>10)
                        Log("ARM refused: need foreground, fresh advancing samples, recent plan and stationary pose. Release F8, wait, try again.");
                    else if(!walk.Supported(sample.Origin,out _)) Log("ARM refused: no standing hull floor support");
                    else
                    {
                        controller=new(plan.Route.Nodes.Select(id=>graph.Nodes[id].Origin).ToArray(),walk.Check,dpc,travelOptions,walk.PredictHeading,settings);
                        input!.Arm(); armed=true;
                        if(checkedLanding)landing.Observe(sample,now); // seed only from the verified arming pose
                        Log("ARMED: movement enabled, F9 to stop");
                    }
                }
                if(armed)
                {
                    if(landingState.Waiting)
                    {
                        input!.Heartbeat();input.Apply(new(false,0,false,"",-1,Mode:"step-landing-wait"));
                        if(now-lastLandingLog>=100)
                        {Log($"LANDING WAIT origin={sample.Origin}; velocity={sample.Velocity}; onGround={sample.OnGround}; input=neutral; maxPauseMs={settings.LandingPauseMs}");lastLandingLog=now;}
                        Thread.Sleep(settings.LoopMs);continue;
                    }
                    if(landingState.Landed)
                    {
                        input!.Heartbeat();input.Apply(new(false,0,false,"",-1));
                        if(!recovery.Active)
                        {
                            string rejected=recovery.Begin("live path rejected: landed after checked step descent",now);
                            if(rejected!=""){Log("STOP "+rejected);return 4;}
                        }
                        Log($"LANDED origin={sample.Origin}; velocity={sample.Velocity}; replanning from grounded pose");
                    }
                    if(recovery.Active)
                    {
                        input!.Heartbeat();input.Apply(new(false,0,false,"",-1,Mode:"recovery-neutral"));
                        var step=recovery.Tick(sample,now,walk.Supported(sample.Origin,out _));
                        if(step.StopReason!="") {Log("STOP "+step.StopReason);return 4;}
                        if(step.Mode!=recoveryPhase || now-lastRecoveryLog>500)
                        {Log($"RECOVER attempt={recovery.Attempts}; limit={recoveryLimit}; phase={step.Mode}; origin={sample.Origin}; speed={sample.Velocity.Length:F3}");recoveryPhase=step.Mode;lastRecoveryLog=now;}
                        if(step.Route is {} renewed)
                        {
                            // Revalidate attachment on main loop using the latest live pose.
                            var first=graph.Nodes[renewed.Route.Nodes[0]].Origin;
                            if(!walk.Check(sample.Origin,first).Safe)
                            {
                                string rejected=recovery.Begin("live path rejected: renewed attachment failed",now);
                                if(rejected!=""){Log("STOP "+rejected);return 4;}
                            }
                            else
                            {
                                plan=renewed;
                                controller=new(plan.Route.Nodes.Select(id=>graph.Nodes[id].Origin).ToArray(),walk.Check,dpc,travelOptions,walk.PredictHeading,settings);
                                var resumedReport=new {format="CSBot.live-plan.v1",controllerVersion="v14-settings",motion,recoveryMode,recoveryLimit,settingsFile=settingsLoaded?settingsPath:null,settings,
                                    capturedAt=DateTimeOffset.Now,pid=mem.ProcessId,origin=sample.Origin,angles=sample.Angles,sample.Time,
                                    mapSha256=map.Sha256,liveMapVerified=false,manualMapConfirmation=confirm,executeRequested=execute,armed=true,
                                    standingHullChecked=true,sampledSupportAndStepsChecked=true,liveBrushStateVerified=false,
                                    recovered=true,recoveryAttempts=recovery.Attempts,team,site,plan.Anchor,plan.AnchorDistance,plan.Route.Cost,
                                    nodes=plan.Route.Nodes.Select(id=>new{id,origin=graph.Nodes[id].Origin})};
                                File.WriteAllText(jsonPath,JsonSerializer.Serialize(resumedReport,new JsonSerializerOptions{WriteIndented=true}));
                                Log($"RECOVER RESUMED origin={sample.Origin}; anchor={plan.Anchor}; nodes={plan.Route.Nodes.Count}; goal={plan.Route.Nodes[^1]}");
                            }
                        }
                        Thread.Sleep(settings.LoopMs);continue;
                    }
                    var command=supportedAir?new TravelCommand(false,0,false,"",-1,Mode:"supported-air-wait"):controller!.Tick(sample,now,focused);
                    if(command.StopReason!="")
                    {
                        // Release immediately before doing anything potentially expensive.
                        input!.Heartbeat();input.Apply(new(false,0,false,"",-1));
                        string rejected=recoveryMode=="replan"?recovery.Begin(command.StopReason,now):command.StopReason;
                        if(rejected!="") {Log("STOP "+rejected);return 4;}
                        Log($"RECOVER BEGIN attempt={recovery.Attempts}; limit={recoveryLimit}; reason={command.StopReason}; origin={sample.Origin}; yaw={sample.Angles.Y:F4}");
                        Thread.Sleep(settings.LoopMs);continue;
                    }
                    if(command.Finished && !map.InsideZone(sample.Origin,plan!.Zone)) { Log("STOP near final waypoint but outside bomb zone"); return 4; }
                    if(command.Finished) { Log("ARRIVED at planned waypoint in bomb zone. No planting/defusing implemented."); return 0; }
                    input!.Heartbeat(); input.Apply(command);
                    Log($"MOVE pmTime={sample.Time:F3}; origin={sample.Origin}; yaw={sample.Angles.Y:F4}; desiredYaw={command.DesiredYaw:F4}; error={command.YawError:F4}; gain={command.MouseGain:F6}; targetIndex={command.TargetIndex}; W={command.Forward}; walk={command.Walk}; speed={sample.Velocity.Length:F3}; onGround={sample.OnGround}; frameTime={sample.FrameTime:F5}; mouseDx={command.MouseDx}; phase={command.Mode}");
                }
                Thread.Sleep(travelOptions.Combined?settings.LoopMs:settings.CautiousLoopMs);
            }
            Log("STOP Ctrl+C or process exited"); return 0;
        }
        finally { Console.CancelKeyPress-=handler; /* using input releases owned W/Shift on every managed exit */ }
    }
}
