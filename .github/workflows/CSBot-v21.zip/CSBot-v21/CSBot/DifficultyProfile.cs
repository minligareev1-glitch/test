namespace CSBot;
internal sealed record DifficultyProfile(string Name,int ReactionMs,int ScanMs,double Range,double Fov,double RearRange,
    int MouseCounts,double TurnDeg,double NearDeg,int SettleMs,int QuietMs,double Fraction,int LoopMs,double MoveDuty,
    string AimPart,double FireDegrees,int BurstMs,int PauseMs,int StableMs,int FreshMs)
{
    public static DifficultyProfile Resolve(BotSettings s)=>s.Difficulty switch
    {
        "easy"=>new("easy",700,100,1600,90,1200,32,4,1.5,120,50,.35,35,.55,"body",2,180,350,150,220),
        "medium"=>new("medium",250,40,2400,120,1800,96,10,3,60,20,.65,20,.8,"body",1.4,260,160,70,120),
        "hard"=>new("hard",70,20,4096,180,4096,192,20,6,30,10,.85,10,1,"auto",.8,350,100,30,80),
        "god"=>new("god",0,10,8192,360,8192,256,20,8,20,10,.9,10,1,"head",.35,450,70,0,60),
        _=>throw new FormatException("Unknown difficulty")
    };
    public void Apply(BotSettings s)
    {
        if(s.DifficultyTuning!="on")return;
        TuneSteering(s);s.LoopMs=LoopMs;s.AimScanMs=ScanMs;s.AimMaxDistance=Range;s.AimFovDeg=Fov;
        s.NavAttachRadius=Name is "hard" or "god"?512:384;
        s.NavPathLookahead=Name is "hard" or "god"?512:384;
    }
    public void TuneSteering(BotSettings s)
    {
        if(s.DifficultyTuning!="on")return;
        s.MouseMaxCounts=MouseCounts;s.MouseTurnMaxDeg=TurnDeg;s.MouseNearTurnMaxDeg=NearDeg;
        s.MouseFastFraction=Fraction;s.MouseSettleMs=SettleMs;s.MouseQuietMs=QuietMs;
        // An uncalibrated input path always starts with a small probe.
        s.MouseFirstMaxCounts=Math.Min(s.MouseFirstMaxCounts,8);
        s.MouseInitialSettleMs=120;s.MouseInitialQuietMs=80;
    }
    public int Reaction(BotSettings s)=>s.CombatReactionMs>=0?s.CombatReactionMs:ReactionMs;
    public int Stable(BotSettings s)=>s.FireStableMs>=0?s.FireStableMs:StableMs;
    public int Fresh(BotSettings s)=>s.FireFreshMs>0?s.FireFreshMs:FreshMs;
    public double Rear(BotSettings s)=>s.RearAwarenessRadius>0?s.RearAwarenessRadius:RearRange;
    public double FireAngle(BotSettings s)=>s.FireToleranceDeg>0?s.FireToleranceDeg:FireDegrees;
    public int Burst(BotSettings s,int weapon)=>FireControl.SemiAutomatic(weapon)?Math.Min(90,s.FireBurstMs>0?s.FireBurstMs:BurstMs):s.FireBurstMs>0?s.FireBurstMs:BurstMs;
    public int Pause(BotSettings s)=>s.FirePauseMs>0?s.FirePauseMs:PauseMs;
}
// Same W-only game speed; easy/medium reduce duty, not game physics or Shift.
internal sealed class MotionPacer(DifficultyProfile profile)
{
    private long _since=-1;
    public void Reset()=>_since=-1;
    public TravelCommand Apply(TravelCommand c,long now)
    {
        if(!c.Forward){Reset();return c;}
        if(profile.MoveDuty>=1)return c;
        if(_since<0 || now<_since)_since=now;
        bool on=(now-_since)%240<240*profile.MoveDuty;
        return on?c:c with{Forward=false,Mode="difficulty-paced-rest+"+c.Mode};
    }
}
internal sealed class DamageAwareness
{
    private int? _hp,_armor;private long _urgentUntil;
    public void Reset(){_hp=_armor=null;_urgentUntil=0;}
    public bool Observe(int hp,int? armor,long now)
    {
        if(hp<=0){Reset();return false;}
        if(_hp.HasValue && hp<_hp || armor.HasValue && _armor.HasValue && armor<_armor)_urgentUntil=now+1200;
        _hp=hp;_armor=armor;return now<_urgentUntil;
    }
}
