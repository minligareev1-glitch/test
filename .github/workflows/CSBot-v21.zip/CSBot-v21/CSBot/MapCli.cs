using System.Text.Json;
using System.Globalization;
using System.Security.Cryptography;

namespace CSBot;

internal static class MapCli
{
    public static bool TryRun(string[] args,out int exit)
    {
        exit=0;
        if(args.Length==0 || args[0] is not ("--map-check" or "--map-route" or "--walk-plan")) return false;
        try
        {
            if(args.Length<3) throw new ArgumentException("Usage: --map-check FILE.graph FILE.bsp [--json report.json]");
            var graph=NavGraph.Load(args[1]); var map=BspMap.Load(args[2]); var nav=new MapNavigation(graph,map);
            var zones=map.BombZones();
            Console.WriteLine($"GoldSrc BSP v30: bytes={map.FileSize}; SHA256={map.Sha256}");
            Console.WriteLine($"MatchesSuppliedDust2={map.MatchesSuppliedDust2}; graphBspSizeHintMatches={graph.BspSizeHint==map.FileSize}");
            Console.WriteLine($"Graph nodes={graph.Nodes.Count}; nonEmptyWorldNodes={nav.NonEmptyNodes}; blockedWorldPointEdges={nav.BlockedEdges.Count}");
            Console.WriteLine("DRY RUN. Static world point checks ONLY; player hull, floor/steps, brush entities and live state are NOT verified.");
            foreach(var edge in nav.BlockedEdges.OrderBy(e=>e.From).ThenBy(e=>e.To))
                Console.WriteLine($"ExcludedWorldPointEdge: {edge.From} -> {edge.To}");
            foreach(var zone in zones)
                Console.WriteLine($"BombZone={zone.Label}; target={zone.Target}; model=*{zone.Model}; min={zone.Min}; max={zone.Max}; goalNodes={string.Join(",",nav.GoalNodes(zone))}");
            Console.WriteLine($"Spawn entities: T={map.Entities.Count(e=>e.GetValueOrDefault("classname")=="info_player_deathmatch")}; CT={map.Entities.Count(e=>e.GetValueOrDefault("classname")=="info_player_start")}");
            string? json=null; string team="t"; MapRoute? plan=null; ProbeVector? position=null;
            int optionsStart=3;
            if(args[0]!="--map-check")
            {
                if(args.Length<7 || !BspMap.TryVector(string.Join(" ",args.Skip(3).Take(3)),out var p))
                    throw new ArgumentException("Usage: --map-route FILE.graph FILE.bsp X Y Z a|b [--team t|ct] [--json FILE]");
                position=p; optionsStart=7;
            }
            for(int i=optionsStart;i<args.Length;i++)
            {
                if(args[i]=="--json" && ++i<args.Length) json=args[i];
                else if(args[i]=="--team" && args[0]!="--map-check" && ++i<args.Length) team=args[i];
                else throw new ArgumentException("Неизвестный/неполный параметр карты");
            }
            if(position.HasValue)
            {
                plan=nav.Plan(position.Value,args[6].ToLowerInvariant(),team.ToLowerInvariant(),
                    args[0]=="--walk-plan"?new WalkGeometry(map):null);
                if(plan==null) { Console.WriteLine("NO ROUTE: no nearby visible anchor with allowed route to the selected site."); exit=3; return true; }
                Console.WriteLine($"Map route: site={plan.Zone.Label}; anchor={plan.Anchor}; attachmentDistance={plan.AnchorDistance:F3}; goal={plan.Route.Nodes[^1]}; nodes={plan.Route.Nodes.Count}; graphCost={plan.Route.Cost:F3}");
                Console.WriteLine(string.Join(" -> ",plan.Route.Nodes));
            }
            if(json!=null)
            {
                object? route=plan==null?null:new {
                    inputPosition=position, team=team.ToLowerInvariant(), site=plan.Zone.Label, anchor=plan.Anchor,
                    attachmentDistance=plan.AnchorDistance, graphCost=plan.Route.Cost,
                    nodes=plan.Route.Nodes.Select(id=>new { id, origin=graph.Nodes[id].Origin, flags=graph.Nodes[id].Flags })
                };
                var artifact=new {
                    format="CSBot.map-plan.v1", dryRunOnly=true, gameInputSent=false,
                    checks=new { standingHullChecked=args[0]=="--walk-plan", sampledSupportAndStepsChecked=args[0]=="--walk-plan", staticWorldPointSegments=true, playerHullVerified=false, floorAndStepsVerified=false,
                        brushEntityCollisionsVerified=false, livePositionVerified=false, liveMapVerified=false },
                    mapFile=Path.GetFileName(args[2]),map.Sha256,map.FileSize,map.MatchesSuppliedDust2,
                    graphFile=Path.GetFileName(args[1]), graphSha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[1]))).ToLowerInvariant(),
                    graphAuthor=graph.Author, dataLicense="CC-BY-SA-4.0", graphBspSizeHintMatches=graph.BspSizeHint==map.FileSize,
                    nonEmptyWorldNodes=nav.NonEmptyNodes,
                    excludedEdges=nav.BlockedEdges.OrderBy(e=>e.From).ThenBy(e=>e.To).Select(e=>new{from=e.From,to=e.To}),
                    zones=zones.Select(z=>new{z.Label,z.Target,z.Model,z.Min,z.Max,goalNodes=nav.GoalNodes(z)}),route
                };
                File.WriteAllText(json,JsonSerializer.Serialize(artifact,new JsonSerializerOptions{WriteIndented=true}));
                Console.WriteLine("Saved: "+json);
            }
        }
        catch(Exception ex) when(ex is IOException or InvalidDataException or UnauthorizedAccessException or ArgumentException or OverflowException)
        { Console.Error.WriteLine("Map navigation error: "+ex.Message); exit=2; }
        return true;
    }
}
